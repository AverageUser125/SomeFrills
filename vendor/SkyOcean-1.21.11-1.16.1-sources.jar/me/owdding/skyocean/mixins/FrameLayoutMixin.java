package me.owdding.skyocean.mixins;

import me.owdding.skyocean.accessors.ClearableLayout;
import net.minecraft.class_7843;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;

@Mixin(class_7843.class)
public class FrameLayoutMixin implements ClearableLayout {
    @Shadow
    @Final
    private List<class_7843.class_7844> children;

    @Override
    public void skyocean$clear() {
        this.children.clear();
    }
}
