package me.owdding.skyocean.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_10439;
import net.minecraft.class_1092;
import net.minecraft.class_2960;

@Mixin(class_1092.class)
public interface ModelManagerAccessor {

    @Accessor("bakedItemStackModels")
    Map<class_2960, class_10439> bakedItemModels();

}
