package me.owdding.skyocean.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.utils.rendering.PostEffectApplicator;
import net.minecraft.class_11228;
import net.minecraft.class_11246;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9960;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_11228.class)
public class GuiRendererMixin {

    @Unique
    private class_2960 skyocean$currentEffect = null;

    @Shadow
    @Final
    class_11246 renderState;

    @Inject(method = "prepare", at = @At("TAIL"))
    private void skyocean$resetPostEffect(CallbackInfo ci) {
        this.skyocean$currentEffect = this.renderState instanceof PostEffectApplicator applicator ? applicator.skyocean$getPostEffect() : null;
    }

    @WrapOperation(method = "draw", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;processBlurEffect()V"))
    private void skyocean$applyPostEffectIf(class_757 instance, Operation<Void> original) {
        if (this.skyocean$currentEffect != null && instance instanceof GameRendererAccessor accessor) {
            var mc = class_310.method_1551();
            var chain = mc.method_62887().method_62941(this.skyocean$currentEffect, class_9960.field_53902);
            if (chain != null) {
                chain.method_1258(mc.method_1522(), accessor.getResourcePool());
                return;
            }
        }
        original.call(instance);
    }
}
