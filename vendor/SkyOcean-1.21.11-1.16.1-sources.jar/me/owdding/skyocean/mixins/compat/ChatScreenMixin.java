package me.owdding.skyocean.mixins.compat;

import me.owdding.skyocean.features.hotkeys.IgnoreHotkeyInputs;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_408.class)
public class ChatScreenMixin implements IgnoreHotkeyInputs {
}
