package me.owdding.skyocean.mixins;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import kotlin.time.Instant;
import me.owdding.skyocean.accessors.AvatarRenderStateAccessor;
import me.owdding.skyocean.accessors.WalkAnimationStateAccessor;
import me.owdding.skyocean.features.misc.fun.animal.PlayerAnimals;
import me.owdding.skyocean.utils.PlayerUtils;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_12075;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin extends class_897<class_1309, class_10042> {

    @Shadow
    public abstract void extractRenderState(class_1309 par1, class_10042 par2, float par3);

    protected LivingEntityRendererMixin(class_5617.class_5618 context) {
        super(context);
    }

    //~ if >= 26.1 'CameraRenderState' -> 'level/CameraRenderState'
    @WrapMethod(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V")
    protected <S extends class_10042> void submit(
        S renderState,
        class_4587 poseStack,
        class_11659 nodeCollector,
        class_12075 cameraRenderState,
        Operation<Void> original
    ) {
        original.call(renderState, poseStack, nodeCollector, cameraRenderState);
    }

    @Mixin(class_1007.class)
    private static abstract class AvatarRendererMixin extends LivingEntityRendererMixin {

        protected AvatarRendererMixin(class_5617.class_5618 context) {
            super(context);
        }

        @WrapMethod(method = "getRenderOffset(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)Lnet/minecraft/world/phys/Vec3;")
        public class_243 getRenderOffset(class_10055 avatarRenderState, Operation<class_243> original) {
            if (PlayerAnimals.shouldPlayerBeAnimal(avatarRenderState)) {
                return super.method_23169(avatarRenderState);
            }
            return original.call(avatarRenderState);
        }

        @WrapMethod(method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V")
        public <AvatarlikeEntity extends class_11890> void extractRenderState(
            AvatarlikeEntity avatar,
            class_10055 state,
            float partialTick,
            Operation<Void> original
        ) {
            original.call(avatar, state, partialTick);
            AvatarRenderStateAccessor.setUUID(state, avatar.method_5667());
            AvatarRenderStateAccessor.setSelf(state, avatar instanceof class_746);
            AvatarRenderStateAccessor.setNpc(state, avatar.method_5667().version() != 4);
            AvatarRenderStateAccessor.setAnimalState(state, null);
            if (!PlayerAnimals.shouldPlayerBeAnimal(state)) {
                return;
            }
            AvatarRenderStateAccessor.setHeldItemStack(state, avatar.method_6047());

            if (avatar instanceof class_742) {
                Instant lastMoveTime = PlayerUtils.INSTANCE.getLastMoveTime(avatar.method_5667());
                AvatarRenderStateAccessor.setLastMoveTime(state, lastMoveTime);
            }
            AvatarRenderStateAccessor.setMoveStartTime(state, WalkAnimationStateAccessor.getMoveStartTime(avatar.field_42108));

            var type = PlayerAnimals.getEntityType();
            var renderer = class_310.method_1551().method_1561().field_4696.get(type);
            var renderState = renderer.method_55269();

            if (!(renderState instanceof class_10042 livingState)) {
                return;
            }

            PlayerAnimals.INSTANCE.getRenderer().extractRenderState(avatar, livingState, partialTick);
            livingState.field_61822 = state.field_61822;
            livingState.field_61823.clear();
            livingState.field_61823.addAll(state.field_61823);

            livingState.field_58171 = type;
            PlayerAnimals.apply(avatar, state, livingState, partialTick);

            AvatarRenderStateAccessor.setAnimalState(state, livingState);
        }

        @Override
        protected <S extends class_10042> void submit(
            S avatarState,
            class_4587 poseStack,
            class_11659 nodeCollector,
            class_12075 cameraRenderState,
            Operation<Void> original
        ) {
            var otherState = AvatarRenderStateAccessor.getAnimalState(avatarState);
            if (otherState != null) {
                class_310.method_1551().method_1561().method_68832(otherState).method_3936(otherState, poseStack, nodeCollector, cameraRenderState);
            } else {
                original.call(avatarState, poseStack, nodeCollector, cameraRenderState);
            }
        }
    }

}
