package me.owdding.skyocean.mixins;

import net.minecraft.class_2960;
import net.minecraft.class_757;
import net.minecraft.class_9920;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_757.class)
public interface GameRendererAccessor {

    @Accessor("resourcePool")
    class_9920 getResourcePool();

    @Invoker("setPostEffect")
    void invokeSetPostEffect(class_2960 identifier);
}
