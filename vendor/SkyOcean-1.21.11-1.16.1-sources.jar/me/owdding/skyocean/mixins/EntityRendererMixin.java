package me.owdding.skyocean.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.helpers.EntityAccessor;
import me.owdding.skyocean.helpers.EntityRenderStateAccessor;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public class EntityRendererMixin<T extends class_1297, S extends class_10017> {

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    public void extractRenderState(T entity, S reusedState, float partialTick, CallbackInfo ci) {
        if (reusedState instanceof EntityRenderStateAccessor stateAccessor && entity instanceof EntityAccessor entityAccessor) {
            stateAccessor.ocean$setNameTagScale(entityAccessor.ocean$getNameTagScale());
        }
    }


    @WrapOperation(
        //~ if >= 26.1 'submitNameTag' -> 'submitNameDisplay(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;I)V'
        method = "submitNameTag",
        at = @At(
            //~ if >= 26.1 'CameraRenderState' -> 'level/CameraRenderState'
            value = "INVOKE", target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitNameTag(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/phys/Vec3;ILnet/minecraft/network/chat/Component;ZIDLnet/minecraft/client/renderer/state/CameraRenderState;)V"
        )
    )
    public void scaleNameTag(
        class_11659 instance,
        class_4587 poseStack,
        class_243 vec3,
        int i,
        class_2561 component,
        boolean b,
        int i2,
        double v,
        class_12075 cameraRenderState,
        Operation<Void> original,
        @Local(argsOnly = true) class_10017 state
    ) {
        float scale = 1f;
        if (state instanceof EntityRenderStateAccessor stateAccessor) {
            scale = stateAccessor.ocean$getNameTagScale();
        }
        if (scale != 1f) {
            poseStack.method_22903();
            poseStack.method_22904(0, -0.7 * (scale / 5), 0);
            poseStack.method_22905(scale, scale, scale);
        }
        original.call(instance, poseStack, vec3, i, component, b, i2, v, cameraRenderState);
        if (scale != 1f) {
            poseStack.method_22909();
        }
    }
}
