package me.owdding.skyocean.mixins;

import net.minecraft.class_10260;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10260.class)
public interface AbstractRecipeBookScreenAccessor {

    @Accessor("recipeBookComponent")
    class_507<?> skyocean$getRecipeBookComponent();
}
