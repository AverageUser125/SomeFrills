package me.owdding.skyocean.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_7843;

@Mixin(class_7843.class)
public interface FrameLayoutAccessor {

    @Accessor("children")
    List<?> children();

}
