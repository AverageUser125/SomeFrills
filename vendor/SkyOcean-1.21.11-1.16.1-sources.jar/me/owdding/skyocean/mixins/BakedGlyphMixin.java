package me.owdding.skyocean.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.config.features.misc.MiscConfig;
import net.minecraft.class_382;
import net.minecraft.class_4588;
//~ if >= 26.1 'Matrix4f' -> 'Matrix4fc'
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_382.class)
public abstract class BakedGlyphMixin {
    @WrapOperation(
        method = "renderChar",
        //~ if >= 26.1 'Matrix4f' -> 'Matrix4fc'
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/glyphs/BakedSheetGlyph;render(ZFFFLorg/joml/Matrix4f;Lcom/mojang/blaze3d/vertex/VertexConsumer;IZI)V", ordinal = 0)
    )
    public void onRenderShadow(
        class_382 instance,
        boolean italic,
        float x,
        float y,
        float z,
        //~ if >= 26.1 'Matrix4f' -> 'Matrix4fc'
        Matrix4f pose,
        class_4588 builder,
        int color,
        boolean bold,
        int packedLightCoords,
        Operation<Void> original,
        @Local(argsOnly = true) class_382.class_10364 glyph
    ) {
        if (MiscConfig.INSTANCE.getFullTextShadow()) {
            for (int j = -1; j <= 1; ++j) {
                for (int k = -1; k <= 1; ++k) {
                    if (j != 0 || k != 0) {
                        float xShadowOffset = glyph.comp_3339() * j;
                        float yShadowOffset = glyph.comp_3339() * k;
                        original.call(instance, italic, glyph.comp_3313() + xShadowOffset, glyph.comp_3314() + yShadowOffset, z, pose, builder, color, bold, packedLightCoords);
                    }
                }
            }
        } else {
            original.call(instance, italic, x, y, z, pose, builder, color, bold, packedLightCoords);
        }
    }

    @WrapOperation(
        method = "renderChar",
        //~ if >= 26.1 'Matrix4f' -> 'Matrix4fc'
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/font/glyphs/BakedSheetGlyph;render(ZFFFLorg/joml/Matrix4f;Lcom/mojang/blaze3d/vertex/VertexConsumer;IZI)V", ordinal = 1)
    )
    public void onRenderShadowBold(
        class_382 instance,
        boolean italic,
        float x,
        float y,
        float z,
        //~ if >= 26.1 'Matrix4f' -> 'Matrix4fc'
        Matrix4f pose,
        class_4588 buffer,
        int color,
        boolean bold,
        int packedLight,
        Operation<Void> original,
        @Local(argsOnly = true) class_382.class_10364 glyph
    ) {
        if (MiscConfig.INSTANCE.getFullTextShadow()) {
            for (int j = -1; j <= 1; ++j) {
                for (int k = -1; k <= 1; ++k) {
                    if (j != 0 || k != 0) {
                        float xShadowOffset = glyph.comp_3339() * j;
                        float yShadowOffset = glyph.comp_3339() * k;
                        original.call(
                            instance,
                            italic,
                            glyph.comp_3313() + glyph.comp_3318() + xShadowOffset,
                            glyph.comp_3314() + yShadowOffset,
                            z,
                            pose,
                            buffer,
                            color,
                            bold,
                            packedLight);
                    }
                }
            }
        } else {
            original.call(instance, italic, x, y, z, pose, buffer, color, bold, packedLight);
        }
    }
}
