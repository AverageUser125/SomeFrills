//~ gui_graphics
package me.owdding.skyocean.mixins;

import me.owdding.skyocean.features.inventory.buttons.InvButtons;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class AbstractContainerScreenMixin {
    //? >= 26.1 {
    /*@Inject(
        method = "extractContents",
        at = @At("TAIL")
    )
    *///? } else {
    @Inject(
        method = "renderBackground",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderBg(Lnet/minecraft/client/gui/GuiGraphics;FII)V")
    )
    //? }
    public void onBackgroundDrawEnd(class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        InvButtons.INSTANCE.onScreenBackgroundAfter((class_465<?>) (Object) this, graphics);
    }
}
