package me.owdding.skyocean.mixins;

import me.owdding.skyocean.helpers.EntityRenderStateAccessor;
import net.minecraft.class_10017;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10017.class)
public class EntityRenderStateMixin implements EntityRenderStateAccessor {

    @Unique private float ocean$nameTagScale = 1f;

    @Override
    public float ocean$getNameTagScale() {
        return this.ocean$nameTagScale;
    }

    @Override
    public void ocean$setNameTagScale(float scale) {
        this.ocean$nameTagScale = scale;
    }
}
