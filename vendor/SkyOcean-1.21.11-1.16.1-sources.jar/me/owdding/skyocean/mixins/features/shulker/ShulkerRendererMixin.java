package me.owdding.skyocean.mixins.features.shulker;

import me.owdding.skyocean.config.features.foraging.GalateaConfig;
import net.minecraft.class_10065;
import net.minecraft.class_1606;
import net.minecraft.class_943;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import tech.thatgravyboat.skyblockapi.api.location.SkyBlockIsland;

@Mixin(class_943.class)
public class ShulkerRendererMixin {

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/monster/Shulker;Lnet/minecraft/client/renderer/entity/state/ShulkerRenderState;F)V", at = @At("TAIL"))
    public void setShulkerRenderState(class_1606 shulker, class_10065 shulkerRenderState, float f, CallbackInfo ci) {
        if (!SkyBlockIsland.GALATEA.inIsland()) {
            return;
        }
        if (GalateaConfig.INSTANCE.getShulkerOverwrite().getDye() == shulker.method_7121()) {
            return;
        }
        shulkerRenderState.field_53567 = GalateaConfig.INSTANCE.getShulkerOverwrite().getDye();
    }

}
