package me.owdding.skyocean.mixins.features.moongladebeacon;

import me.owdding.skyocean.features.foraging.galatea.MoongladeBeacon;
import net.minecraft.class_10633;
import net.minecraft.class_2338;
import net.minecraft.class_2580;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_2580.class)
public abstract class BeaconBlockEntityMixin extends class_2586 {

    public BeaconBlockEntityMixin(class_2591<?> blockEntityType, class_2338 blockPos, class_2680 blockState) {
        super(blockEntityType, blockPos, blockState);
    }

    @Inject(method = "getBeamSections", at = @At("HEAD"), cancellable = true)
    public void getBeamSections(CallbackInfoReturnable<List<class_10633.class_2581>> cir) {
        if (!MoongladeBeacon.isBlockPos(field_11867)) return;
        cir.setReturnValue(MoongladeBeacon.getSection());
    }

}
