package me.owdding.skyocean.mixins.features;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import me.owdding.skyocean.config.features.misc.MiscConfig;
import net.minecraft.class_315;
import net.minecraft.class_4063;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_315.class)
public class OptionsMixin {

    //~ if >= 26.1 'getCloudsType' -> 'getCloudStatus'
    @WrapMethod(method = "getCloudsType")
    private class_4063 modifyCloudsType(Operation<class_4063> original) {
        if (MiscConfig.INSTANCE.getShouldHideClouds()) {
            return class_4063.field_18162;
        }
        return original.call();
    }

}
