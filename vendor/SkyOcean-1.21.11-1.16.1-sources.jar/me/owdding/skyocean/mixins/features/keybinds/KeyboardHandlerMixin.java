package me.owdding.skyocean.mixins.features.keybinds;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.features.hotkeys.system.HotkeyManager;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {

    @Definition(id = "screen", local = @Local(type = class_437.class))
    @Expression("screen != null")
    @Inject(method = "keyPress", at = @At(value = "MIXINEXTRAS:EXPRESSION",
        //? >= 26.1
        //ordinal = 0
        //? = 1.21.11
        ordinal = 3
    ), cancellable = true)
    public void meow(long window, int action, class_11908 event, CallbackInfo ci) {
        if (HotkeyManager.handle(event, action)) {
            ci.cancel();
        }
    }

}
