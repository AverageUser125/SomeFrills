//TODO
//? < 26.1 {
package me.owdding.skyocean.mixins.features.hidearmour;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.helpers.HeadLayerAlphaHolder;
import net.minecraft.class_10444;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_777;
import net.minecraft.class_811;
import net.minecraft.class_918;
import net.minecraft.class_9848;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

@Mixin(class_918.class)
public class ItemRendererMixin {

    @WrapMethod(method = "renderItem")
    private static void renderItem(
        class_811 displayContext,
        class_4587 poseStack,
        class_4597 bufferSource,
        int packedLight,
        int packedOverlay,
        int[] tintLayers,
        List<class_777> quads,
        class_1921 renderType,
        class_10444.class_10445 foilType,
        Operation<Void> original
    ) {
        if (HeadLayerAlphaHolder.alpha != null) {
            renderType = class_4722.method_29382();
        }
        original.call(displayContext, poseStack, bufferSource, packedLight, packedOverlay, tintLayers, quads, renderType, foilType);
    }

    @WrapOperation(
        method = "renderQuadList",
        at = @At(
            value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/VertexConsumer;putBulkData(Lcom/mojang/blaze3d/vertex/PoseStack$Pose;Lnet/minecraft/client/renderer/block/model/BakedQuad;FFFFII)V"
        )
    )
    private static void renderQuadList(
        class_4588 instance,
        class_4587.class_4665 pose,
        class_777 quad,
        float red,
        float green,
        float blue,
        float alpha,
        int packedLight,
        int packedOverlay,
        Operation<Void> original
    ) {
        if (HeadLayerAlphaHolder.alpha != null) {
            original.call(
                instance,
                pose,
                quad,
                red,
                green,
                blue,
                class_9848.method_65103(HeadLayerAlphaHolder.alpha),
                packedLight,
                packedOverlay);
            return;
        }

        original.call(instance, pose, quad, red, green, blue, alpha, packedLight, packedOverlay);
    }

}
//? }
