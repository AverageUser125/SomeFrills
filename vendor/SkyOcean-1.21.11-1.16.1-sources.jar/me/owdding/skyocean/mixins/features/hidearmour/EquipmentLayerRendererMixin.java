package me.owdding.skyocean.mixins.features.hidearmour;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import me.owdding.skyocean.accessors.hidearmour.ItemStackAccessor;
import net.minecraft.class_10186;
import net.minecraft.class_10197;
import net.minecraft.class_1058;
import net.minecraft.class_11683;
import net.minecraft.class_11785;
import net.minecraft.class_12249;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4722;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_10197.class)
public class EquipmentLayerRendererMixin {

    @Unique
    private static final class_1921 TRANSPARENT_TRIMS_TYPE = class_12249.method_75978(class_4722.field_42071);



    @WrapOperation(
        method = "renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/resources/Identifier;II)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/rendertype/RenderTypes;armorCutoutNoCull(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/client/renderer/rendertype/RenderType;"
        )
    )
    public class_1921 modifyRenderType(
        class_2960 location,
        Operation<class_1921> original,
        @Share(value = "translucent", namespace = "skyocean") LocalRef<Boolean> renderTranslucent
    ) {
        if (renderTranslucent.get() != null && renderTranslucent.get()) {
            return class_12249.method_75978(location);
        }
        return original.call(location);
    }

    @WrapOperation(
        method = "renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/resources/Identifier;II)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/Sheets;armorTrimsSheet(Z)Lnet/minecraft/client/renderer/rendertype/RenderType;"
        )
    )
    public class_1921 modifyTrimsRenderType(
        boolean decal,
        Operation<class_1921> original,
        @Share(value = "translucent", namespace = "skyocean") LocalRef<Boolean> renderTranslucent
    ) {
        if (renderTranslucent.get() != null && renderTranslucent.get()) {
            return TRANSPARENT_TRIMS_TYPE;
        }
        return original.call(decal);
    }

    @WrapOperation(
        method = "renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/resources/Identifier;II)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/entity/layers/EquipmentLayerRenderer;getColorForLayer(Lnet/minecraft/client/resources/model/EquipmentClientInfo$Layer;I)I"
        )
    )
    public int renderLayers(
        class_10186.class_10189 layer,
        int defaultColor,
        Operation<Integer> original,
        @Local(argsOnly = true) class_1799 stack,
        @Share(value = "translucent", namespace = "skyocean") LocalRef<Boolean> renderTranslucent
    ) {
        var color = original.call(layer, defaultColor);
        var alpha = ItemStackAccessor.getAlpha(stack);
        if (alpha != null && color != null && alpha < 253) {
            renderTranslucent.set(true);
            return (alpha << 24) | (color & 0xFFFFFF);
        }

        return color != null ? color : -1;
    }

    @WrapOperation(
        method = "renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/resources/Identifier;II)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/OrderedSubmitNodeCollector;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/texture/TextureAtlasSprite;ILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V",
            ordinal = 2
        )
    )
    public <S> void renderTrimToBuffer(
        class_11785 instance,
        class_3879<? super S> model,
        S s,
        class_4587 poseStack,
        class_1921 renderType,
        int i,
        int i2,
        int i3,
        class_1058 textureAtlasSprite,
        int i4,
        class_11683.class_11792 crumblingOverlay,
        Operation<Void> original,
        @Local(argsOnly = true) class_1799 stack
    ) {
        var alpha = ItemStackAccessor.getAlpha(stack);
        if (alpha != null) {
            original.call(instance, model, s, poseStack, renderType, i, i2, (alpha << 24) | i3, textureAtlasSprite, i4, crumblingOverlay);
        } else {
            original.call(instance, model, s, poseStack, renderType, i, i2, i3, textureAtlasSprite, i4, crumblingOverlay);
        }
    }
}
