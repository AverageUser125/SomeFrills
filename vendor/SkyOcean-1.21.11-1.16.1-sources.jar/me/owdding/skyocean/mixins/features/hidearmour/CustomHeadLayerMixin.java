package me.owdding.skyocean.mixins.features.hidearmour;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.accessors.AvatarRenderStateAccessor;
import me.owdding.skyocean.config.features.misc.MiscConfig;
import me.owdding.skyocean.helpers.HeadLayerAlphaHolder;
import net.minecraft.class_10042;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_5598;
import net.minecraft.class_976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_976.class)
public class CustomHeadLayerMixin {

    @WrapOperation(
        method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;FF)V",
        at = @At(
            value = "INVOKE",
            //? >= 26.1 {
            /*target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;submitSkull(FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/model/object/skull/SkullModelBase;Lnet/minecraft/client/renderer/rendertype/RenderType;ILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V"
            *///? } else
            target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;submitSkull(Lnet/minecraft/core/Direction;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/model/object/skull/SkullModelBase;Lnet/minecraft/client/renderer/rendertype/RenderType;ILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V"
            )
    )
    public <S extends class_10042> void render(
        //? < 26.1
        class_2350 direction,
        float v,
        //? < 26.1
        float v2,
        class_4587 poseStack,
        class_11659 submitNodeCollector,
        int i,
        class_5598 skullModelBase,
        class_1921 renderType,
        int i2,
        class_11683.class_11792 crumblingOverlay,
        Operation<Void> original,
        @Local(argsOnly = true) S renderState
    ) {
        if (renderState instanceof AvatarRenderStateAccessor accessor && !accessor.skyocean$isNpc()) {
            if (accessor.skyocean$isSelf()) {
                HeadLayerAlphaHolder.alpha = MiscConfig.INSTANCE.getTransparentArmorSelf();
            } else {
                HeadLayerAlphaHolder.alpha = MiscConfig.INSTANCE.getTransparentArmorOthers();
            }
        }
        original.call(
            //? < 26.1
            direction,
            v,
            //? < 26.1
            v2,
            poseStack, submitNodeCollector, i, skullModelBase, renderType, i2, crumblingOverlay);
        HeadLayerAlphaHolder.alpha = null;
    }

    @WrapOperation(
        method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;FF)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/item/ItemStackRenderState;submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;III)V"
        )
    )
    public <S extends class_10042> void render(
        class_10444 instance,
        class_4587 poseStack,
        class_11659 submitNodeCollector,
        int packedLight,
        int packedOverlay,
        int outlineColor,
        Operation<Void> original,
        @Local(argsOnly = true) S renderState
    ) {
        if (renderState instanceof AvatarRenderStateAccessor accessor && !accessor.skyocean$isNpc()) {
            if (accessor.skyocean$isSelf()) {
                HeadLayerAlphaHolder.alpha = MiscConfig.INSTANCE.getTransparentArmorSelf();
            } else {
                HeadLayerAlphaHolder.alpha = MiscConfig.INSTANCE.getTransparentArmorOthers();
            }
        }
        original.call(instance, poseStack, submitNodeCollector, packedLight, packedOverlay, outlineColor);
        HeadLayerAlphaHolder.alpha = null;
    }
}
