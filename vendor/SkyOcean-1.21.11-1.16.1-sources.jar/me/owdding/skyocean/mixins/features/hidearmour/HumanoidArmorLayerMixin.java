package me.owdding.skyocean.mixins.features.hidearmour;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.accessors.AvatarRenderStateAccessor;
import me.owdding.skyocean.accessors.hidearmour.ItemStackAccessor;
import me.owdding.skyocean.config.features.misc.MiscConfig;
import net.minecraft.class_10034;
import net.minecraft.class_11659;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_970.class)
public class HumanoidArmorLayerMixin {

    @WrapOperation(
        method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V")
    )
    public <S extends class_10034> void render(
        class_970<S, ?, ?> instance,
        class_4587 poseStack,
        class_11659 submitNodeCollector,
        class_1799 armorItem,
        class_1304 equipmentSlot,
        int i,
        class_10034 humanoidRenderState,
        Operation<Void> original,
        @Local(argsOnly = true) S renderState
    ) {
        if (renderState instanceof AvatarRenderStateAccessor accessor && !accessor.skyocean$isNpc()) {
            if (accessor.skyocean$isSelf()) {
                ItemStackAccessor.setAlpha(armorItem, MiscConfig.INSTANCE.getTransparentArmorSelf());
            } else {
                ItemStackAccessor.setAlpha(armorItem, MiscConfig.INSTANCE.getTransparentArmorOthers());
            }
        }

        original.call(instance, poseStack, submitNodeCollector, armorItem, equipmentSlot, i, humanoidRenderState);
    }

}
