package me.owdding.skyocean.mixins.features.hidearmour;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.helpers.HeadLayerAlphaHolder;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_1921;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_836;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_836.class)
public class SkullBlockRendererMixin {

    @WrapOperation(
        method = "submitSkull",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V"
        )
    )
    private static <S> void renderSkull(
        class_11659 instance,
        class_3879<S> model,
        S o,
        class_4587 poseStack,
        class_1921 renderType,
        int packedLight,
        int packedOverlay,
        int outlineColor,
        class_11683.class_11792 crumblingOverlay,
        Operation<Void> original
    ) {
        if (HeadLayerAlphaHolder.alpha != null) {
            instance.method_73490(
                model,
                o,
                poseStack,
                renderType,
                packedLight,
                packedOverlay,
                (HeadLayerAlphaHolder.alpha << 24) | 0xFFFFFF,
                null,
                outlineColor,
                crumblingOverlay);
            return;
        }

        original.call(instance, model, o, poseStack, renderType, packedLight, packedOverlay, outlineColor, crumblingOverlay);
    }

}
