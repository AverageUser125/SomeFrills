package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import me.owdding.skyocean.utils.Utils;
import net.minecraft.class_10430;
import net.minecraft.class_10455;
import net.minecraft.class_1799;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

//~ if >= 26.1 'BlockModelWrapper' -> 'CuboidItemModelWrapper'
@Mixin(value = {class_10430.class, class_10455.class})
public class ItemEnchantmentGlintMixin {

    @WrapOperation(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;hasFoil()Z"))
    public boolean update(class_1799 instance, Operation<Boolean> original) {
        return Boolean.TRUE.equals(Utils.nonNullElseGet(
            CustomItemsHelper.getData(instance, class_9334.field_49641),
            () -> original.call(instance)));
    }

}
