package me.owdding.skyocean.mixins.features.customize;

import me.owdding.skyocean.compat.CatharsisSupport;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import me.owdding.skyocean.features.item.custom.data.CustomItemDataComponents;
import net.minecraft.class_10034;
import net.minecraft.class_10442;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_811;
import net.minecraft.class_909;
import net.minecraft.class_9334;
import net.minecraft.class_970;
import net.minecraft.class_9990;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

@Mixin(class_909.class)
public abstract class LivingEntityRendererMixin<T extends class_1308, S extends class_10034, M extends class_572<S>> extends class_9990<T, S, M> {
    public LivingEntityRendererMixin(
        class_5617.class_5618 context,
        M adultModel,
        M babyModel,
        float scale
    ) {
        super(context, adultModel, babyModel, scale);
    }

    @Inject(
        method = "extractHumanoidRenderState",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/entity/state/ArmedEntityRenderState;extractArmedEntityRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/ArmedEntityRenderState;Lnet/minecraft/client/renderer/item/ItemModelResolver;F)V",
            shift = At.Shift.AFTER
        )
    )
    private static void replaceSkull(class_1309 entity, class_10034 state, float partialTick, class_10442 itemModelResolver, CallbackInfo ci) {
        var item = entity.method_6118(class_1304.field_6169);
        var profile = CustomItemsHelper.getData(item, class_9334.field_49617);
        var model = CustomItemsHelper.getCustomData(item, CustomItemDataComponents.model());

        if (profile == null && model == null) return;
        var itemModel = model == null ? item.method_7909() : Objects.requireNonNullElse(model.resolveToItem(), item.method_7909());

        state.field_55316 = profile;
        if (itemModel instanceof class_1747 blockItem && blockItem.method_7711() instanceof class_2190 abstractSkullBlock) {
            state.field_55315 = abstractSkullBlock.method_9327();
            state.field_53467.method_65605();
            state.field_55309 = class_1799.field_8037;
        } else {
            state.field_55309 = item;
            var defaultInstance = itemModel.getDefaultInstance();
            if (!class_970.method_64081(defaultInstance, class_1304.field_6169)) {
                itemModelResolver.method_65597(state.field_53467, defaultInstance, class_811.field_4316, entity);
            } else {
                state.field_53467.method_65605();
            }
            state.field_55315 = null;
            state.field_55316 = null;
        }

        CatharsisSupport.INSTANCE.disableCatharsisModifications(item);
    }
}
