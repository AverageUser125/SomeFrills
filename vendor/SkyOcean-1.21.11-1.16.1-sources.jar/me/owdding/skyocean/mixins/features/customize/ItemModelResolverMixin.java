package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import net.minecraft.class_10442;
import net.minecraft.class_1799;
import net.minecraft.class_9331;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_10442.class)
public class ItemModelResolverMixin {

    @WrapOperation(method = {"shouldPlaySwapAnimation", "appendItemLayers"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;"))
    public <T> T modify(class_1799 instance, class_9331<T> dataComponentType, Operation<T> original) {
        return CustomItemsHelper.replace(instance, dataComponentType, original);
    }

}
