package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import me.owdding.skyocean.utils.Utils;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_970.class)
public class HumanoidArmorLayerMixin {

    @WrapOperation(
        method = {
            "shouldRender(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;)Z",
            "renderArmorPiece"
        },
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;")
    )
    private static <T> T get(class_1799 instance, class_9331<T> dataComponentType, Operation<T> original) {
        return Utils.nonNullElseGet(CustomItemsHelper.getData(instance, dataComponentType), () -> original.call(instance, dataComponentType));
    }

    @WrapOperation(
        method = "shouldRender(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;)Z",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;shouldRender(Lnet/minecraft/world/item/equipment/Equippable;Lnet/minecraft/world/entity/EquipmentSlot;)Z")
    )
    private static boolean replaceArmorTrim(class_10192 equippable, class_1304 slot, Operation<Boolean> original, @Local(argsOnly = true) class_1799 stack) {
        var state = CustomItemsHelper.getEquippableState(stack);
        return switch (state.getState()) {
            case DEFAULT -> original.call(equippable, slot) && CustomItemsHelper.getData(stack, class_9334.field_49617) == null;
            case TRUE -> original.call(state.getEquippable(), slot);
            case FALSE -> false;
        };
    }
}
