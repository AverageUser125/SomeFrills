package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.accessors.customize.ItemStackAccessor;
import me.owdding.skyocean.features.item.custom.CustomItems;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import me.owdding.skyocean.features.item.custom.data.ItemKey;
import me.owdding.skyocean.helpers.MixinHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_9334;
import net.minecraft.class_9335;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

@Mixin(class_1799.class)
public class ItemStackMixin implements ItemStackAccessor {
    @Unique
    private final static ThreadLocal<Boolean> COPYING = ThreadLocal.withInitial(() -> false);

    @Unique
    private ItemKey key;

    //~ if >= 26.1 'world/level/ItemLike' -> 'core/Holder'
    @Inject(method = "<init>(Lnet/minecraft/world/level/ItemLike;ILnet/minecraft/core/component/PatchedDataComponentMap;)V", at = @At("RETURN"), order = 1200)
    //~ if >= 26.1 'ItemLike' -> 'Holder<Item>'
    public void init(class_1935 itemLike, int count, class_9335 patches, CallbackInfo ci) {
        if (!MixinHelper.isStarted() || COPYING.get()) {
            return;
        }
        key = CustomItems.INSTANCE.createKey(self());
        CustomItems.INSTANCE.loadVanilla(self(), key);
    }

    @ModifyReturnValue(method = "getStyledHoverName", at = @At("RETURN"))
    public class_2561 getStylizedHoverName(class_2561 original) {
        return Objects.requireNonNullElse(CustomItemsHelper.getData(self(), class_9334.field_49631), original);
    }

    //~ if >= 26.1 'world/level/ItemLike' -> 'core/Holder'
    @WrapOperation(method = "copy", at = @At(value = "NEW", target = "(Lnet/minecraft/world/level/ItemLike;ILnet/minecraft/core/component/PatchedDataComponentMap;)Lnet/minecraft/world/item/ItemStack;"))
    //~ if >= 26.1 'ItemLike' -> 'Holder<Item>'
    private class_1799 copy(class_1935 item, int count, class_9335 patches, Operation<class_1799> original) {
        COPYING.set(true);
        var other = original.call(item, count, patches);
        ((ItemStackMixin) (Object) other).key = key;
        COPYING.set(false);
        return other;
    }


    @Unique
    private class_1799 self() {
        return (class_1799) (Object) this;
    }

    @Override
    public @Nullable ItemKey skyocean$getItemKey() {
        return key;
    }
}
