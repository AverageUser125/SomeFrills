package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.config.features.misc.MiscConfig;
import net.minecraft.class_1309;
import net.minecraft.class_746;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
/*? if >=26.1 {*/
/*?} else {*/
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
 /*?}*/
import tech.thatgravyboat.skyblockapi.api.location.SkyBlockIsland;

@Mixin(class_758.class)
public class NetherFogColorMixin {

    @WrapOperation(
        method = "computeFogColor",
        at = @At(
            value = "INVOKE",
            //~ if >= 26.2 'getNightVisionScale' -> 'nightVisionScale'
            target = "Lnet/minecraft/client/renderer/GameRenderer;getNightVisionScale(Lnet/minecraft/world/entity/LivingEntity;F)F"
        )
    )
    private float skyocean$darkenNetherFog(
        class_1309 livingEntity,
        @SuppressWarnings("NameDoesntMatchTargetClass") float partialTicks,
        Operation<Float> original
    ) {
        if (!MiscConfig.INSTANCE.getNetherFogDarkening()
            || !SkyBlockIsland.CRIMSON_ISLE.inIsland()
            || !(livingEntity instanceof class_746)) {
            return original.call(livingEntity, partialTicks);
        }

        return MiscConfig.INSTANCE.getNetherFogScale();
    }
}
