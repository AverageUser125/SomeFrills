package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Objects;

@Mixin(class_329.class)
public class GuiMixin {

    //~ if >= 26.1 'renderSelectedItemName' -> 'extractSelectedItemName'
    @WrapOperation(method = {"renderSelectedItemName", "tick()V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getHoverName()Lnet/minecraft/network/chat/Component;"))
    public class_2561 renderSelectedItemName(class_1799 instance, Operation<class_2561> original) {
        return Objects.requireNonNullElseGet(CustomItemsHelper.getData(instance, class_9334.field_49631), () -> original.call(instance));
    }

}
