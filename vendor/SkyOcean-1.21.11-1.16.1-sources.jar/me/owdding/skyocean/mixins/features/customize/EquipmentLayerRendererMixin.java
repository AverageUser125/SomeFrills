package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import net.minecraft.class_10186;
import net.minecraft.class_10197;
import net.minecraft.class_10394;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_5321;
import net.minecraft.class_8144;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_10197.class)
public class EquipmentLayerRendererMixin {

    @WrapOperation(
        method = "renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/resources/Identifier;II)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;"
        )
    )
    public <T> T replaceArmorTrim(class_1799 instance, class_9331<T> type, Operation<T> original) {
        return CustomItemsHelper.replace(instance, type, original);
    }

    @WrapMethod(
        method = "renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/resources/Identifier;II)V"
    )
    public void replaceArmorTrim(
        class_10186.class_10190 $$0,
        class_5321<class_10394> asset,
        class_3879<?> $$2,
        Object $$3,
        class_1799 stack,
        class_4587 $$5,
        class_11659 $$6,
        int $$7,
        class_2960 $$8,
        int $$9,
        int $$10,
        Operation<Void> original
    ) {
        var equippable = class_8144.method_49077(
            CustomItemsHelper.getData(stack, class_9334.field_54196),
            it -> it.assetId().orElse(null)
        );
        original.call($$0, equippable != null ? equippable : asset, $$2, $$3, stack, $$5, $$6, $$7, $$8, $$9, $$10);
    }

}
