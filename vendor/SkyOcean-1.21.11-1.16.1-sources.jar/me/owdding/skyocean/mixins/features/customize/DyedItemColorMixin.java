package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import net.minecraft.class_1799;
import net.minecraft.class_9282;
import net.minecraft.class_9331;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_9282.class)
public class DyedItemColorMixin {

    @WrapOperation(method = "getOrDefault", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;"))
    private static <T> T replaceDyeColor(class_1799 instance, class_9331<T> type, Operation<T> original) {
        return CustomItemsHelper.replace(instance, type, original);
    }

}
