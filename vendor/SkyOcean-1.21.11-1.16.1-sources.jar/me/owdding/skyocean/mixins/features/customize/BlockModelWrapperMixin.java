package me.owdding.skyocean.mixins.features.customize;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import me.owdding.skyocean.features.item.custom.CustomItemsHelper;
import me.owdding.skyocean.features.item.custom.data.CustomItemDataComponents;
import net.minecraft.class_10396;
import net.minecraft.class_10401;
import net.minecraft.class_10430;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_638;
import net.minecraft.class_9848;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

//~ if >= 26.1 'BlockModelWrapper' -> 'CuboidItemModelWrapper'
@Mixin(class_10430.class)
public class BlockModelWrapperMixin {

    @WrapOperation(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/color/item/ItemTintSource;calculate(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/world/entity/LivingEntity;)I"))
    public int modifyColor(
        class_10401 instance,
        class_1799 itemStack,
        class_638 clientLevel,
        class_1309 livingEntity,
        Operation<Integer> original,
        @Share("foundFirst") LocalBooleanRef foundFirst,
        @Local(argsOnly = true) LocalRef<class_1799> itemStackRef
        ) {
        var customColor = CustomItemsHelper.getColor(itemStack);
        var model = CustomItemsHelper.getCustomData(itemStack, CustomItemDataComponents.model());
        if (model != null) {
            var resolved = model.resolveToItem();
            if (resolved != null) itemStackRef.set(resolved.getDefaultInstance());
        }

        if (instance instanceof class_10396 || customColor == null || foundFirst.get()) {
            return original.call(instance, itemStack, clientLevel, livingEntity);
        }

        foundFirst.set(true);
        return class_9848.method_61334(customColor);
    }

    //? if = 1.21.11 {
    @WrapOperation(method = "method_76557", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getItem()Lnet/minecraft/world/item/Item;"))
    private static class_1792 wrap(class_1799 instance, Operation<class_1792> original) {
        var model = CustomItemsHelper.getCustomData(instance, CustomItemDataComponents.model());
        if (model != null) {
            return model.resolveToItem();
        }

        return original.call(instance);
    }
    //?}

}
