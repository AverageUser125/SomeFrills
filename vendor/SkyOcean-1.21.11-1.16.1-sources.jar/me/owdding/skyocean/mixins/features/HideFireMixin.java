package me.owdding.skyocean.mixins.features;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.config.features.misc.MiscConfig;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_898;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_898.class)
public class HideFireMixin {

    @WrapOperation(method = "submit", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitFlame(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lorg/joml/Quaternionf;)V"))
    public void renderFlame(
        class_11659 instance,
        class_4587 poseStack,
        class_10017 entityRenderState,
        Quaternionf quaternionf,
        Operation<Void> original
    ) {
        if (!MiscConfig.INSTANCE.getHideEntityFire()) {
            original.call(instance, poseStack, entityRenderState, quaternionf);
        }
    }

}
