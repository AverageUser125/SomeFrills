package me.owdding.skyocean.mixins.features.fishing;

import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.config.features.fishing.FishingConfig;
import net.minecraft.class_1536;
import net.minecraft.class_746;
import net.minecraft.class_906;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tech.thatgravyboat.skyblockapi.api.location.LocationAPI;

@Mixin(class_906.class)
public class FishingHookRendererMixin {

    @Unique
    private static boolean isEnabled() {
        return LocationAPI.INSTANCE.isOnSkyBlock() && FishingConfig.INSTANCE.getHideOtherBobbers();
    }

    @Inject(
        method = "shouldRender(Lnet/minecraft/world/entity/projectile/FishingHook;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",
        at = @At("HEAD"),
        cancellable = true
    )
    private void skyocean$hideOtherBobbers(CallbackInfoReturnable<Boolean> cir, @Local(argsOnly = true) class_1536 fishingHook) {
        if (isEnabled() && !(fishingHook.method_6947() instanceof class_746)) {
            cir.setReturnValue(false);
        }
    }

}
