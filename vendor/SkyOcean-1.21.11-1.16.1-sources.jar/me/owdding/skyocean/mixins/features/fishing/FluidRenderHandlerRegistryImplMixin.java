package me.owdding.skyocean.mixins.features.fishing;

import me.owdding.skyocean.config.features.fishing.FishingConfig;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
//~ if >= 26.1 'FluidRenderHandlerRegistryImpl' -> 'FluidRenderingRegistryImpl'
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderHandlerRegistryImpl;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tech.thatgravyboat.skyblockapi.api.location.SkyBlockIsland;

import java.util.Map;

@SuppressWarnings("UnstableApiUsage")
//~ if >= 26.1 'FluidRenderHandlerRegistryImpl' -> 'FluidRenderingRegistryImpl'
@Mixin(value = FluidRenderHandlerRegistryImpl.class, remap = false)
public class FluidRenderHandlerRegistryImplMixin {

    @Shadow
    @Final
    //~ if >= 26.1 'handlers' -> 'HANDLERS' {
    //~ if >= 26.1 'private' -> 'private static' {
    private Map<class_3611, FluidRenderHandler> handlers;

    @Inject(method = "get", at = @At("HEAD"), cancellable = true)
    private void skyocean$redirectLavaRendering(class_3611 fluid, CallbackInfoReturnable<FluidRenderHandler> cir) {
        if (!SkyBlockIsland.CRIMSON_ISLE.inIsland()) {
            return;
        }
        if (!FishingConfig.INSTANCE.getLavaReplacement()) return;
        if (fluid == class_3612.field_15908) cir.setReturnValue(handlers.get(class_3612.field_15910));
        else if (fluid == class_3612.field_15907) cir.setReturnValue(handlers.get(class_3612.field_15909));
    }
    //~ }
    //~ }

}
