package me.owdding.skyocean.mixins.features.fishing;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import me.owdding.skyocean.config.features.fishing.FishingConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1531;
import net.minecraft.class_1536;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import tech.thatgravyboat.skyblockapi.api.location.LocationAPI;

@Mixin(class_1536.class)
public abstract class FishingHookMixin extends class_1676 {

    public FishingHookMixin(class_1299<? extends class_1676> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Unique
    private static boolean isEnabled() {
        return LocationAPI.INSTANCE.isOnSkyBlock() && FishingConfig.INSTANCE.getFixBobber();
    }

    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/material/FluidState;is(Lnet/minecraft/tags/TagKey;)Z"))
    private boolean skyocean$fixLavaBobber(class_3610 instance, class_6862<class_3611> tag, Operation<Boolean> original) {
        return original.call(instance, tag) || (isEnabled() && instance.method_15767(class_3486.field_15518));
    }

    @Unique
    private boolean shouldBlockHook(@Nullable class_1297 entity) {
        if (entity == null || !isEnabled()) return false;
        return (entity instanceof class_1531 armorStand) && armorStand.method_5628() == method_5628() + 1;
    }

    @WrapOperation(method = "onSyncedDataUpdated", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;getEntity(I)Lnet/minecraft/world/entity/Entity;"))
    private class_1297 skyocean$fixBobberHook(class_1937 instance, int id, Operation<class_1297> original) {
        class_1297 entity = original.call(instance, id);
        return shouldBlockHook(entity) ? null : entity;
    }

}
