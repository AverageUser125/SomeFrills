package me.owdding.skyocean.mixins;

import me.owdding.skyocean.accessors.ClearableLayout;
import net.minecraft.class_7845;
import net.minecraft.class_8667;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_8667.class)
public class LinearLayoutMixin implements ClearableLayout {
    @Shadow
    @Final
    private class_7845 wrapped;

    @Override
    public void skyocean$clear() {
        if (wrapped instanceof ClearableLayout clearableLayout) {
            clearableLayout.skyocean$clear();
        }
    }
}
