package me.owdding.skyocean.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import me.owdding.skyocean.features.garden.cropfever.CropFeverEffects;
import net.minecraft.class_310;
import net.minecraft.class_757;

@Mixin(class_310.class)
public abstract class MinecraftPerspectiveMixin {

    @Redirect(
        method = "handleKeybinds",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;checkEntityPostEffect(Lnet/minecraft/world/entity/Entity;)V")
    )
    private void redirectCheckEntityPostEffect(class_757 instance, net.minecraft.class_1297 entity) {
        if (CropFeverEffects.isFeverActive()) {
            return;
        }
        instance.method_3167(entity);
    }
}
