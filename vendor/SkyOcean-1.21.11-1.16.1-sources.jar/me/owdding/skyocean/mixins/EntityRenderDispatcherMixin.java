package me.owdding.skyocean.mixins;

import com.llamalad7.mixinextras.sugar.Local;
import me.owdding.skyocean.features.misc.fun.animal.PlayerAnimals;
import net.minecraft.class_3300;
import net.minecraft.class_5617;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public class EntityRenderDispatcherMixin {

    @Inject(method = "onResourceManagerReload", at = @At("TAIL"))
    public void onReload(class_3300 resourceManager, CallbackInfo ci, @Local class_5617.class_5618 context) {
        PlayerAnimals.INSTANCE.createRenderer(context);
    }

}
