package me.owdding.skyocean.mixins;

import me.owdding.skyocean.accessors.SafeMutableComponentAccessor;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7417;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

import java.util.ArrayList;
import java.util.List;

@Mixin(class_5250.class)
public abstract class MutableComponentMixin implements SafeMutableComponentAccessor {

    @Shadow
    @Final
    @Mutable
    private List<class_2561> siblings;

    @Shadow
    public abstract class_5250 append(class_2561 $$0);

    @Mutable
    @Shadow
    @Final
    private class_7417 contents;

    @Override
    public class_5250 skyocean$appendSafe(class_2561 component) {
        skyocean$mutableSiblings();
        return append(component);
    }

    @Override
    public List<class_2561> skyocean$mutableSiblings() {
        try {
            siblings.addLast(null);
            siblings.removeLast();
            return siblings;
        } catch (UnsupportedOperationException ignored) {
            siblings = new ArrayList<>(siblings);
            return siblings;
        }
    }

    @Override
    public void skyocean$setContents(class_7417 contents) {
        this.contents = contents;
    }
}
