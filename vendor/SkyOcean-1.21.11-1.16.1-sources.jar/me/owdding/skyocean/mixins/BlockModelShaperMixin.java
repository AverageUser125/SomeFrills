package me.owdding.skyocean.mixins;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import me.owdding.skyocean.events.BlockModelEvent;
import net.minecraft.class_2680;
import net.minecraft.class_773;
import net.minecraft.class_793;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tech.thatgravyboat.skyblockapi.api.SkyBlockAPI;

@Mixin(class_773.class)
//~ }
public class BlockModelShaperMixin {

    //~ if >= 26.1 'getBlockModel' -> 'get'
    @Inject(method = "getBlockModel", at = @At("HEAD"))
    private void getBlockModel(CallbackInfoReturnable<class_793> cir, @Local(argsOnly = true) LocalRef<class_2680> blockState) {
        final BlockModelEvent blockModelEvent = new BlockModelEvent(blockState.get());
        blockModelEvent.post(SkyBlockAPI.getEventBus());
        final class_2680 state = blockModelEvent.getState();
        if (state != blockState.get()) {
            blockState.set(state);
        }
    }

}
