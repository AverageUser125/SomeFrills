package me.owdding.skyocean.mixins;

import kotlin.time.Instant;
import me.owdding.skyocean.accessors.AvatarRenderStateAccessor;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.UUID;

@Mixin(class_10055.class)
public class AvatarRenderStateMixin implements AvatarRenderStateAccessor {
    @Unique
    private UUID ocean$uuid;
    @Unique
    private boolean skyocean$isSelf;
    @Unique
    private boolean skyocean$isNpc;
    @Unique
    private class_10042 skyocean$animalState;
    @Unique
    private class_1799 skyocean$heldItemStack;
    @Unique
    private Instant skyocean$lastMoveTime;
    @Unique
    private Integer skyocean$startMoveTime;

    @Override
    public Integer ocean$getStartMoveTime() {
        return this.skyocean$startMoveTime;
    }

    @Override
    public void ocean$setStartMoveTime(Integer startMoveTime) {
        this.skyocean$startMoveTime = startMoveTime;
    }

    @Override
    public UUID ocean$getUUID() {
        return this.ocean$uuid;
    }

    @Override
    public void ocean$setUUID(UUID uuid) {
        this.ocean$uuid = uuid;
    }

    @Override
    public void skyocean$setSelf(boolean isSelf) {
        this.skyocean$isSelf = isSelf;
    }

    @Override
    public boolean skyocean$isSelf() {
        return this.skyocean$isSelf;
    }

    @Override
    public void skyocean$setNpc(boolean isNpc) {
        this.skyocean$isNpc = isNpc;
    }

    @Override
    public boolean skyocean$isNpc() {
        return this.skyocean$isNpc;
    }

    @Override
    public class_10042 skyocean$getAnimalState() {
        return skyocean$animalState;
    }

    @Override
    public void skyocean$setAnimalState(class_10042 state) {
        this.skyocean$animalState = state;
    }

    @Override
    public void ocean$setHeldItemStack(class_1799 stack) {
        this.skyocean$heldItemStack = stack;
    }

    @Override
    public class_1799 ocean$getHeldItemStack() {
        return this.skyocean$heldItemStack;
    }

    @Override
    public Instant ocean$getLastMoveTime() {
        return this.skyocean$lastMoveTime;
    }

    @Override
    public void ocean$setLastMoveTime(Instant time) {
        this.skyocean$lastMoveTime = time;
    }
}
