package me.owdding.skyocean.mixins;

import me.owdding.skyocean.accessors.ClearableLayout;
import net.minecraft.class_7845;
import net.minecraft.class_8021;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;

@Mixin(class_7845.class)
public class GridLayoutMixin implements ClearableLayout {
    @Shadow
    @Final
    private List<class_8021> children;

    @Override
    public void skyocean$clear() {
        children.clear();
    }
}
