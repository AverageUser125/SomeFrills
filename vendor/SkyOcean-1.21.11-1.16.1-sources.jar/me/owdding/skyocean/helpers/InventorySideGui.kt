package me.owdding.skyocean.helpers

import earth.terrarium.olympus.client.components.compound.LayoutWidget
import me.owdding.lib.compat.REIRenderOverlayEvent
import me.owdding.lib.layouts.BackgroundWidget
import me.owdding.skyocean.SkyOcean
import me.owdding.skyocean.helpers.InventorySideGui.Alignment
import me.owdding.skyocean.mixins.ScreenAccessor
import net.minecraft.client.gui.components.AbstractWidget
import net.minecraft.client.gui.layouts.Layout
import net.minecraft.client.gui.screens.Screen
import org.intellij.lang.annotations.Language
import tech.thatgravyboat.skyblockapi.api.events.base.Subscription
import tech.thatgravyboat.skyblockapi.api.events.screen.ContainerCloseEvent
import tech.thatgravyboat.skyblockapi.api.events.screen.ContainerInitializedEvent
import tech.thatgravyboat.skyblockapi.api.events.screen.ScreenMouseClickEvent
import tech.thatgravyboat.skyblockapi.api.events.screen.ScreenInitializedEvent
import tech.thatgravyboat.skyblockapi.utils.extentions.left
import tech.thatgravyboat.skyblockapi.utils.extentions.right
import tech.thatgravyboat.skyblockapi.utils.extentions.toFormattedName
import tech.thatgravyboat.skyblockapi.utils.extentions.top
import tech.thatgravyboat.skyblockapi.utils.text.TextProperties.stripped

abstract class InventorySideGui(@Language("RegExp") titleRegex: String, val alignment: () -> Alignment = { Alignment.RIGHT_OF_INVENTORY }) {

    private val regex = titleRegex.toRegex()
    var oldList: LayoutWidget<*>? = null
    var oldWidget: AbstractWidget? = null

    private var lastEvent: ContainerInitializedEvent? = null
    private var isBeingShown: Boolean = false

    abstract val enabled: Boolean

    protected abstract fun ContainerInitializedEvent.getLayout(): Layout?

    fun refresh() {
        val event = lastEvent ?: return
        val screen = event.screen

        isBeingShown = enabled && regex.matches(screen.title.stripped)
        if (!isBeingShown) return

        val layout = event.getLayout() ?: return

        val widget = BackgroundWidget(SkyOcean.id("blank"), layout, 5).apply {
            val x = when (alignment()) {
                Alignment.LEFT_OF_INVENTORY -> screen.left - 5 - this.width
                Alignment.RIGHT_OF_INVENTORY -> screen.right + 5
            }
            this.setPosition(x, screen.top)
        }
        screen.addWidget(widget)
    }

    // Used so that when Hypixel resends the entire screen we can
    // show the list before the items are resent so it doesn't
    // fall in and out.
    @Subscription(inherited = true, priority = Subscription.LOW)
    fun onInvChange(event: ContainerInitializedEvent) {
        this.lastEvent = event
        refresh()
    }

    @Subscription(inherited = true)
    fun onScreenInit(event: ScreenInitializedEvent) {
        isBeingShown = enabled && regex.matches(event.screen.title.stripped)
        if (!isBeingShown) return

        val widget = this.oldWidget ?: return

        event.screen.addWidget(widget)
    }

    private fun Screen.addWidget(widget: AbstractWidget) {
        val accessor = this as ScreenAccessor
        oldWidget?.let { accessor.`skyocean$removeWidget`(it) }
        oldWidget = widget
        this.`skyocean$addRenderableWidget`(widget)
    }

    @Subscription(inherited = true)
    fun onReiRender(event: REIRenderOverlayEvent) {
        if (!isBeingShown) return

        oldWidget?.let {
            event.register(it.x, it.y, it.width, it.height)
        }
    }

    @Subscription(ContainerCloseEvent::class, inherited = true)
    fun onContainerClose() {
        isBeingShown = false
        oldList = null
        lastEvent = null
    }

    enum class Alignment {
        LEFT_OF_INVENTORY,
        RIGHT_OF_INVENTORY;

        private val formattedName = toFormattedName()
        override fun toString() = formattedName
    }

}
