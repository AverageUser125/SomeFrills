package me.owdding.skyocean.utils.rendering

import earth.terrarium.olympus.client.utils.Orientation
import me.owdding.lib.displays.Display
import net.minecraft.client.gui.GuiGraphics as GuiGraphicsExtractor
import net.minecraft.util.ARGB
import tech.thatgravyboat.skyblockapi.platform.drawFilledBox

object ExtraDisplays {

    fun inventorySlot(display: Display, color: Int = -1) = inventoryBackground(1, Orientation.HORIZONTAL, display, color)

    fun inventoryBackground(size: Int, orientation: Orientation, display: Display, color: Int = -1): Display {
        return object : Display {
            override fun getWidth() = display.getWidth()
            override fun getHeight() = display.getHeight()

            override fun extract(graphics: GuiGraphicsExtractor) {
                InventoryRenderer.renderMonoInventory(graphics, 0, 0, display.getWidth(), display.getHeight(), size, orientation, color)
                display.extract(graphics)
            }
        }
    }

    fun inventoryBackground(columns: Int, rows: Int, display: Display, color: Int = -1): Display {
        if (rows == 1) {
            return inventoryBackground(columns, Orientation.HORIZONTAL, display, color)
        }
        if (columns == 1) {
            return inventoryBackground(rows, Orientation.VERTICAL, display, color)
        }

        return object : Display {
            override fun getWidth() = display.getWidth()
            override fun getHeight() = display.getHeight()

            override fun extract(graphics: GuiGraphicsExtractor) {
                InventoryRenderer.renderNormalInventory(graphics, 0, 0, display.getWidth(), display.getHeight(), columns, rows, color)
                display.extract(graphics)
            }
        }
    }

    fun passthrough(width: Int, height: Int, draw: GuiGraphicsExtractor.() -> Unit) = object : Display {
        override fun getWidth() = width
        override fun getHeight() = height

        override fun extract(graphics: GuiGraphicsExtractor) {
            graphics.draw()
        }
    }

    fun solid(color: Number, width: Int, height: Int) = object : Display {
        val color = ARGB.opaque(color.toInt())
        override fun getWidth() = width
        override fun getHeight() = height

        override fun extract(graphics: GuiGraphicsExtractor) {
            graphics.drawFilledBox(
                0, 0,
                getWidth(), getHeight(),
                this.color,
            )
        }
    }
}
