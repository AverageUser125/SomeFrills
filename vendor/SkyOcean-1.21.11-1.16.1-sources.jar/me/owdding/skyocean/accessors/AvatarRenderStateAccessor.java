package me.owdding.skyocean.accessors;

import kotlin.time.Instant;
import net.minecraft.class_10042;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public interface AvatarRenderStateAccessor {

    static void setUUID(Object renderState, UUID uuid) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.ocean$setUUID(uuid);
        }
    }

    static UUID getUUID(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.ocean$getUUID();
        }
        return null;
    }

    static boolean isSelf(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.skyocean$isSelf();
        }
        return false;
    }

    static void setSelf(Object renderState, boolean isSelf) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.skyocean$setSelf(isSelf);
        }
    }

    static boolean isNpc(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.skyocean$isNpc();
        }
        return false;
    }

    static void setNpc(Object renderState, boolean isNpc) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.skyocean$setNpc(isNpc);
        }
    }

    @Nullable
    static class_10042 getAnimalState(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.skyocean$getAnimalState();
        }
        return null;
    }

    static void setAnimalState(Object renderState, class_10042 state) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.skyocean$setAnimalState(state);
        }
    }

    static class_1799 getHeldItemStack(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.ocean$getHeldItemStack();
        }
        return class_1799.field_8037;
    }

    static void setHeldItemStack(Object renderState, class_1799 stack) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.ocean$setHeldItemStack(stack);
        }
    }

    static Integer getMoveStartTime(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.ocean$getStartMoveTime();
        }
        return null;
    }

    static void setMoveStartTime(Object renderState, Integer time) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.ocean$setStartMoveTime(time);
        }
    }

    static Instant getLastMoveTime(Object renderState) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            return accessor.ocean$getLastMoveTime();
        }
        return null;
    }

    static void setLastMoveTime(Object renderState, Instant time) {
        if (renderState instanceof AvatarRenderStateAccessor accessor) {
            accessor.ocean$setLastMoveTime(time);
        }
    }

    Integer ocean$getStartMoveTime();

    void ocean$setStartMoveTime(Integer startMoveTime);

    void ocean$setUUID(UUID uuid);

    UUID ocean$getUUID();

    void skyocean$setSelf(boolean isSelf);

    boolean skyocean$isSelf();

    void skyocean$setNpc(boolean isNpc);

    boolean skyocean$isNpc();

    class_10042 skyocean$getAnimalState();

    void skyocean$setAnimalState(class_10042 state);

    class_1799 ocean$getHeldItemStack();

    void ocean$setHeldItemStack(class_1799 stack);

    Instant ocean$getLastMoveTime();

    void ocean$setLastMoveTime(Instant time);

}
