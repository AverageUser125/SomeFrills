package me.owdding.skyocean.accessors.customize;

import me.owdding.skyocean.features.item.custom.data.ItemKey;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public interface ItemStackAccessor {

    @Nullable
    static ItemKey getItemKey(class_1799 stack) {
        if (((Object) stack) instanceof ItemStackAccessor accessor) {
            return accessor.skyocean$getItemKey();
        }
        return null;
    }

    @Nullable
    ItemKey skyocean$getItemKey();

}
