package me.owdding.skyocean.accessors.hidearmour;

import net.minecraft.class_1799;

public interface ItemStackAccessor {

    static Integer getAlpha(class_1799 itemStack) {
        if (((Object) itemStack) instanceof ItemStackAccessor accessor) {
            return accessor.skyocean$getAlpha();
        }
        return null;
    }

    static void setAlpha(class_1799 itemStack, Integer alpha) {
        if (((Object) itemStack) instanceof ItemStackAccessor accessor) {
            accessor.skyocean$setAlpha(alpha);
        }
    }

    void skyocean$setAlpha(Integer alpha);

    Integer skyocean$getAlpha();

}
