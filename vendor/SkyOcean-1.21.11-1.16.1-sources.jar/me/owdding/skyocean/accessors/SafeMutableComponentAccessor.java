package me.owdding.skyocean.accessors;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7417;

public interface SafeMutableComponentAccessor {

    class_5250 skyocean$appendSafe(class_2561 component);

    List<class_2561> skyocean$mutableSiblings();

    void skyocean$setContents(class_7417 contents);

}
