package me.owdding.skyocean.generated

internal object CodecUtils {

    val UUID_CODEC = com.mojang.serialization.Codec.STRING.xmap(
        { java.util.UUID.fromString(it) },
        { it.toString() }
    )

    val JSON_ELEMENT_CODEC = com.mojang.serialization.Codec.PASSTHROUGH.xmap(
        { it.convert(com.mojang.serialization.JsonOps.INSTANCE).value },
        { com.mojang.serialization.Dynamic(com.mojang.serialization.JsonOps.INSTANCE, it) }
    )


    fun <T> compact(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<List<T>> =
        com.mojang.serialization.Codec.either(codec.listOf(), codec).xmap(
            { it.map({ it }, { listOf<T>(it) }) },
            { if (it.size == 1) com.mojang.datafixers.util.Either.right(it[0]) else com.mojang.datafixers.util.Either.left(it) }
        )

    fun <T> compactMutableSet(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<MutableSet<T>> =
        compact(codec).xmap({ it.toMutableSet() }, { it.toList() })

    fun <T> mutableSet(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<MutableSet<T>> =
        codec.listOf().xmap({ it.toMutableSet() }, { it.toList() })

    fun <T> compactSet(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<Set<T>> =
        compact(codec).xmap({ it.toSet() }, { it.toList() })

    fun <T> set(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<Set<T>> =
        codec.listOf().xmap({ it.toSet() }, { it.toList() })

    inline fun <reified E : Enum<E>> compactEnumSet(codec: com.mojang.serialization.Codec<E>): com.mojang.serialization.Codec<java.util.EnumSet<E>> =
        compactEnumSet(E::class.java, codec)

    fun <E : Enum<E>> compactEnumSet(clazz: Class<E>, codec: com.mojang.serialization.Codec<E>): com.mojang.serialization.Codec<java.util.EnumSet<E>> =
        compact(codec).xmap({ java.util.EnumSet.noneOf(clazz).apply { addAll(it) } }, { it.toList() })

    inline fun <reified E : Enum<E>> enumSet(codec: com.mojang.serialization.Codec<E>): com.mojang.serialization.Codec<java.util.EnumSet<E>> =
        enumSet(E::class.java, codec)

    fun <E : Enum<E>> enumSet(clazz: Class<E>, codec: com.mojang.serialization.Codec<E>): com.mojang.serialization.Codec<java.util.EnumSet<E>> =
        codec.listOf().xmap({ java.util.EnumSet.noneOf(clazz).apply { addAll(it) } }, { it.toList() })


    fun <T> compactList(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<List<T>> =
        compact(codec).xmap({ it.toMutableList() }, { it })

    fun <T> list(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<List<T>> =
        codec.listOf().xmap({ it.toMutableList() }, { it })

    fun <T> compactMutableList(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<MutableList<T>> =
        compact(codec).xmap({ it.toMutableList() }, { it })

    fun <T> mutableList(codec: com.mojang.serialization.Codec<T>): com.mojang.serialization.Codec<MutableList<T>> =
        codec.listOf().xmap({ it.toMutableList() }, { it })

    fun <A, B> map(
        key: com.mojang.serialization.Codec<A>,
        value: com.mojang.serialization.Codec<B>
    ): com.mojang.serialization.Codec<MutableMap<A, B>> =
        com.mojang.serialization.Codec.unboundedMap(key, value).xmap({ it.toMutableMap() }, { it })


    inline fun <reified E : Enum<E>, B> enumMap(
        key: com.mojang.serialization.Codec<E>,
        value: com.mojang.serialization.Codec<B>,
    ): com.mojang.serialization.Codec<java.util.EnumMap<E, B>> = enumMap(E::class.java, key, value)

    fun <E : Enum<E>, B> enumMap(
        clazz: Class<E>,
        key: com.mojang.serialization.Codec<E>,
        value: com.mojang.serialization.Codec<B>,
    ): com.mojang.serialization.Codec<java.util.EnumMap<E, B>> {
        return com.mojang.serialization.Codec.unboundedMap(key, value).xmap({ java.util.EnumMap<E, B>(clazz).apply { putAll(it) } }, { it })
    }

    fun <T> lazyMapCodec(init: () -> com.mojang.serialization.MapCodec<T>): com.mojang.serialization.MapCodec<T> {
        return com.mojang.serialization.MapCodec.recursive(init.toString()) { init() }
    }

    fun <T> toLazy(codec: com.mojang.serialization.MapCodec<T>): com.mojang.serialization.MapCodec<Lazy<T>> {
        return codec.xmap({ lazyOf(it) }, { it.value })
    }
    
    fun longRange(min: Long, max: Long): com.mojang.serialization.Codec<Long> {
       var checker = com.mojang.serialization.Codec.checkRange(min, max)
       return com.mojang.serialization.Codec.LONG.flatXmap(checker, checker)
    }

}