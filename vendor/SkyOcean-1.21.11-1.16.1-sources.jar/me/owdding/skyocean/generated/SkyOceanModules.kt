package me.owdding.skyocean.generated

import kotlin.Any
import kotlin.Unit

internal object SkyOceanApiDebug {
    public val collected = listOf(
                me.owdding.skyocean.SkyOcean::debug,
                me.owdding.skyocean.api.FishingCatchApi::debug,
                me.owdding.skyocean.compat.CatharsisSupport::debug,
                me.owdding.skyocean.features.fishing.TrophyFishingNumbers::debug,
                me.owdding.skyocean.features.recipe.crafthelper.CraftHelperManager::debug
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanItemModifiers {
    public val collected = listOf(
                me.owdding.skyocean.features.gambling.dungeons.CroesusImpl,
                me.owdding.skyocean.features.inventory.SalvagingHelper,
                me.owdding.skyocean.features.inventory.museum.MuseumDonationHelper,
                me.owdding.skyocean.features.item.lore.ArmadilloBlocksWalkedModifier,
                me.owdding.skyocean.features.item.lore.CompactLevelBarsModifier,
                me.owdding.skyocean.features.item.lore.DrillLoreModifier,
                me.owdding.skyocean.features.item.lore.DungeonQualityLoreModifier,
                me.owdding.skyocean.features.item.lore.DyeHexLoreModifier,
                me.owdding.skyocean.features.item.lore.MidasPaidBreakdownModifier,
                me.owdding.skyocean.features.item.lore.MuseumDonationLoreModifier,
                me.owdding.skyocean.features.item.lore.PetCandy,
                me.owdding.skyocean.features.item.lore.StoragePreview,
                me.owdding.skyocean.features.mining.hollows.MetalDetectorSolver.MetalDetectorLoreModifier,
                me.owdding.skyocean.features.misc.StarStackSizeModifier,
                me.owdding.skyocean.features.misc.RevertMasterStarModifier
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanAnimalModifiers {
    public val collected = listOf(
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.ArmorStandModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.AxolotlModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.BoggedModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.CatModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.ChickenModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.CopperGolemModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.CowModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.CreakingModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.FoxModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.FrogModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.HappyGhastModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.HorseModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.IronGolemModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.LlamaModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.MushroomCowModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.PandaModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.ParrotModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.PigModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.RabbitModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.SalmonModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.SheepModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.ShulkerModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.SnowGolemModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.TropicalFishModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.VillagerModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.WolfModifier,
                me.owdding.skyocean.features.misc.`fun`.animal.modifiers.ZombieVillagerModifier
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanCraftHelperModifiers {
    public val collected = listOf(
                me.owdding.skyocean.features.recipe.crafthelper.modifiers.ForgeModifier,
                me.owdding.skyocean.features.recipe.crafthelper.modifiers.RecipeModifier,
                me.owdding.skyocean.features.recipe.crafthelper.modifiers.VisitorModifier
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanLateInitModules {
    public val collected = listOf(
                me.owdding.skyocean.`data`.RecentColorStorage,
                me.owdding.skyocean.`data`.profile.CraftHelperStorage,
                me.owdding.skyocean.features.gambling.dungeons.chest.DungeonItems,
                me.owdding.skyocean.features.gambling.vanguard.VanguardGambling,
                me.owdding.skyocean.features.item.custom.CustomItems,
                me.owdding.skyocean.features.recipe.SimpleRecipeApi,
                me.owdding.skyocean.features.recipe.crafthelper.display.CraftHelperDisplay,
                me.owdding.skyocean.repo.customization.AnimatedSkulls,
                me.owdding.skyocean.repo.customization.DyeData,
                me.owdding.skyocean.repo.museum.MuseumRepoData
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanPreInitModules {
    public val collected = listOf(
                me.owdding.skyocean.repo.SackData,
                me.owdding.skyocean.utils.chat.OceanGradients.Companion
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanOverlays {
    public val collected = listOf(
                me.owdding.skyocean.features.garden.cropfever.CoinRainOverlay,
                me.owdding.skyocean.features.recipe.crafthelper.CraftHelperOverlay
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}

internal object SkyOceanModules {
    public val collected = listOf(
                me.owdding.skyocean.SkyOcean,
                me.owdding.skyocean.api.FishingCatchApi,
                me.owdding.skyocean.api.HotspotAPI,
                me.owdding.skyocean.commands.CalcCommand,
                me.owdding.skyocean.commands.CraftHelperCommand,
                me.owdding.skyocean.commands.CustomizeCommand,
                me.owdding.skyocean.commands.GiveItemCommand,
                me.owdding.skyocean.commands.ReplyBoop,
                me.owdding.skyocean.commands.SendCoords,
                me.owdding.skyocean.config.DefaultEnabledMessageHelper,
                me.owdding.skyocean.`data`.profile.FarmingItemStorage,
                me.owdding.skyocean.`data`.profile.GalateaItemStorage,
                me.owdding.skyocean.`data`.profile.InventoryStorage,
                me.owdding.skyocean.`data`.profile.MinionStorage,
                me.owdding.skyocean.`data`.profile.SackOfSacksItemStorage,
                me.owdding.skyocean.events.FmlApi,
                me.owdding.skyocean.features.chat.PiggyBankRepairHelper,
                me.owdding.skyocean.features.chat.ProfileInChat,
                me.owdding.skyocean.features.chat.SackNotification,
                me.owdding.skyocean.features.chat.WhiteNonMessage,
                me.owdding.skyocean.features.combat.slayer.BlazeSlayerHighlight,
                me.owdding.skyocean.features.combat.slayer.HighlightBoss,
                me.owdding.skyocean.features.combat.slayer.MinibossHighlight,
                me.owdding.skyocean.features.dev.ComponentAnimatorDebug,
                me.owdding.skyocean.features.dev.IdDebug,
                me.owdding.skyocean.features.dev.NpcRecipeParser,
                me.owdding.skyocean.features.fishing.BobberTime,
                me.owdding.skyocean.features.fishing.FishingWarningScale,
                me.owdding.skyocean.features.fishing.HotspotFeatures,
                me.owdding.skyocean.features.fishing.TrophyFishingNumbers,
                me.owdding.skyocean.features.foraging.HotfHelper,
                me.owdding.skyocean.features.foraging.galatea.MoongladeBeacon,
                me.owdding.skyocean.features.foraging.galatea.MuteTheFuckingPhantoms,
                me.owdding.skyocean.features.gambling.dungeons.DungeonGambling,
                me.owdding.skyocean.features.garden.DeskPestHighlight,
                me.owdding.skyocean.features.garden.PestBaitType,
                me.owdding.skyocean.features.garden.PestWarning,
                me.owdding.skyocean.features.garden.cropfever.CropFeverEffects,
                me.owdding.skyocean.features.hotkeys.HotkeyPresets,
                me.owdding.skyocean.features.hotkeys.system.HotkeyManager,
                me.owdding.skyocean.features.inventory.MinionHelper,
                me.owdding.skyocean.features.inventory.SackValue,
                me.owdding.skyocean.features.inventory.SalvagingHelper,
                me.owdding.skyocean.features.inventory.buttons.InvButtons,
                me.owdding.skyocean.features.inventory.museum.MuseumDonationHelper,
                me.owdding.skyocean.features.item.custom.CustomizeKeybind,
                me.owdding.skyocean.features.item.modifier.ItemModifiers,
                me.owdding.skyocean.features.item.search.ItemSearch,
                me.owdding.skyocean.features.item.search.highlight.ItemHighlightKeybind,
                me.owdding.skyocean.features.item.search.highlight.ItemHighlighter,
                me.owdding.skyocean.features.item.search.highlight.ReiItemHighlighter,
                me.owdding.skyocean.features.item.`value`.ItemValueScreen.Companion,
                me.owdding.skyocean.features.mining.CommissionHighlighter,
                me.owdding.skyocean.features.mining.ForgeReminder,
                me.owdding.skyocean.features.mining.HotmHelper,
                me.owdding.skyocean.features.mining.PuzzlerSolver,
                me.owdding.skyocean.features.mining.RedCarpets,
                me.owdding.skyocean.features.mining.hollows.AreaWalls,
                me.owdding.skyocean.features.mining.hollows.MetalDetectorSolver,
                me.owdding.skyocean.features.mining.mineshaft.CorpseKeyAnnouncement,
                me.owdding.skyocean.features.mining.mineshaft.CorpseWaypoint,
                me.owdding.skyocean.features.mining.mineshaft.MineshaftAnnouncement,
                me.owdding.skyocean.features.mining.mineshaft.PityMessage,
                me.owdding.skyocean.features.mining.scathas.Scathas,
                me.owdding.skyocean.features.misc.AnvilHelper,
                me.owdding.skyocean.features.misc.ChestTracker,
                me.owdding.skyocean.features.misc.ImplosionHider,
                me.owdding.skyocean.features.misc.InvulnerabilityAnimation,
                me.owdding.skyocean.features.misc.MinisterInCalendar,
                me.owdding.skyocean.features.misc.PreviousServers,
                me.owdding.skyocean.features.misc.QueueEstimate,
                me.owdding.skyocean.features.misc.RatHitboxes,
                me.owdding.skyocean.features.recipe.ForgeRecipeScreenHandler,
                me.owdding.skyocean.features.recipe.crafthelper.CraftHelperManager,
                me.owdding.skyocean.features.recipe.crafthelper.modifiers.CraftHelperModifiers,
                me.owdding.skyocean.features.textures.MobIcons,
                me.owdding.skyocean.helpers.CooldownHelper.Companion,
                me.owdding.skyocean.repo.attributes.SkyShardsAttributeRepoData,
                me.owdding.skyocean.repo.customization.TrimPatternMap,
                me.owdding.skyocean.repo.misc.GalateaRepoData,
                me.owdding.skyocean.utils.DevUtils,
                me.owdding.skyocean.utils.LevelBoundValueHolder,
                me.owdding.skyocean.utils.PlayerUtils,
                me.owdding.skyocean.utils.RemoteRepoDelegate.Companion,
                me.owdding.skyocean.utils.RemoteStrings,
                me.owdding.skyocean.utils.SoundUtils,
                me.owdding.skyocean.utils.items.ItemCache,
                me.owdding.skyocean.utils.nbs.NBSMusicManager,
                me.owdding.skyocean.utils.rendering.OceanOverlays,
                me.owdding.skyocean.utils.storage.DataStorage.Companion,
                me.owdding.skyocean.utils.storage.ProfileStorage.Companion
            )

    public fun `init`(applicator: (Any) -> Unit) {
        collected.forEach(applicator)
    }
}
