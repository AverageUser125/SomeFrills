@file:Suppress("UNCHECKED_CAST")

package me.owdding.skyocean.generated

import com.google.gson.JsonElement
import com.mojang.blaze3d.platform.InputConstants
import com.mojang.serialization.Codec
import com.mojang.serialization.MapCodec
import com.mojang.serialization.codecs.RecordCodecBuilder
import java.lang.Class
import java.lang.Integer
import java.util.Optional
import java.util.UUID
import kotlin.Int
import kotlin.Lazy
import kotlin.Suppress
import me.owdding.lib.repo.PowderType
import me.owdding.lib.repo.WhisperType
import me.owdding.skyocean.`data`.profile.ChestItem
import me.owdding.skyocean.`data`.profile.FarmingItems
import me.owdding.skyocean.`data`.profile.GalateaItems
import me.owdding.skyocean.`data`.profile.MinionStorage
import me.owdding.skyocean.`data`.profile.StoredPerkData
import me.owdding.skyocean.config.patcher.AddListPatch
import me.owdding.skyocean.config.patcher.AddPatch
import me.owdding.skyocean.config.patcher.CodeConfigPatch
import me.owdding.skyocean.config.patcher.RemovePatch
import me.owdding.skyocean.features.gambling.dungeons.chest.DungeonItem
import me.owdding.skyocean.features.gambling.vanguard.VanguardGambling
import me.owdding.skyocean.features.hotkeys.HotkeyPresets
import me.owdding.skyocean.features.hotkeys.HotkeyUtils
import me.owdding.skyocean.features.hotkeys.actions.CommandHotkeyAction
import me.owdding.skyocean.features.hotkeys.actions.HotkeyAction
import me.owdding.skyocean.features.hotkeys.conditions.AndHotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.DungeonClassHotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.DungeonFloorHotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.HotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.IslandHotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.MayorPerkHotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.NotHotkeyCondition
import me.owdding.skyocean.features.hotkeys.conditions.OrHotkeyCondition
import me.owdding.skyocean.features.hotkeys.system.ConflictContext
import me.owdding.skyocean.features.hotkeys.system.Hotkey
import me.owdding.skyocean.features.hotkeys.system.HotkeyCategory
import me.owdding.skyocean.features.hotkeys.system.HotkeyManager
import me.owdding.skyocean.features.hotkeys.system.Keybind
import me.owdding.skyocean.features.hotkeys.system.KeybindSettings
import me.owdding.skyocean.features.inventory.DimensionInventory
import me.owdding.skyocean.features.inventory.MinionHelper
import me.owdding.skyocean.features.item.custom.`data`.AnimatedSkyBlockDye
import me.owdding.skyocean.features.item.custom.`data`.AnimatedSkyblockSkin
import me.owdding.skyocean.features.item.custom.`data`.ArmorTrim
import me.owdding.skyocean.features.item.custom.`data`.CustomItemData
import me.owdding.skyocean.features.item.custom.`data`.GradientEntry
import me.owdding.skyocean.features.item.custom.`data`.GradientItemColor
import me.owdding.skyocean.features.item.custom.`data`.IdAndTimeKey
import me.owdding.skyocean.features.item.custom.`data`.IdKey
import me.owdding.skyocean.features.item.custom.`data`.ItemColor
import me.owdding.skyocean.features.item.custom.`data`.ItemColorType
import me.owdding.skyocean.features.item.custom.`data`.ItemKey
import me.owdding.skyocean.features.item.custom.`data`.ItemKeyType
import me.owdding.skyocean.features.item.custom.`data`.ItemModel
import me.owdding.skyocean.features.item.custom.`data`.ItemModelType
import me.owdding.skyocean.features.item.custom.`data`.ItemSkin
import me.owdding.skyocean.features.item.custom.`data`.ItemSkinType
import me.owdding.skyocean.features.item.custom.`data`.SkyBlockDye
import me.owdding.skyocean.features.item.custom.`data`.SkyblockModel
import me.owdding.skyocean.features.item.custom.`data`.SkyblockSkin
import me.owdding.skyocean.features.item.custom.`data`.StaticItemColor
import me.owdding.skyocean.features.item.custom.`data`.StaticModel
import me.owdding.skyocean.features.item.custom.`data`.StaticSkin
import me.owdding.skyocean.features.item.custom.`data`.UuidKey
import me.owdding.skyocean.features.recipe.CurrencyIngredient
import me.owdding.skyocean.features.recipe.CurrencyType
import me.owdding.skyocean.features.recipe.Ingredient
import me.owdding.skyocean.features.recipe.IngredientType
import me.owdding.skyocean.features.recipe.ItemLikeIngredient
import me.owdding.skyocean.features.recipe.SkyOceanItemIngredient
import me.owdding.skyocean.features.recipe.crafthelper.CraftHelperRecipe
import me.owdding.skyocean.features.recipe.crafthelper.`data`.CraftHelperRecipeType
import me.owdding.skyocean.features.recipe.crafthelper.`data`.NormalCraftHelperRecipe
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsCycleElement
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsCycleStep
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsDirectElement
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsMethod
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsMethodType
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsRecipe
import me.owdding.skyocean.features.recipe.crafthelper.`data`.SkyShardsRecipeElement
import me.owdding.skyocean.features.recipe.custom.CustomRecipe
import me.owdding.skyocean.features.textures.MobIconSettings
import me.owdding.skyocean.repo.SackData
import me.owdding.skyocean.repo.attributes.SkyShardsAttributeData
import me.owdding.skyocean.repo.customization.AnimatedSkulls
import me.owdding.skyocean.repo.misc.GalateaData
import me.owdding.skyocean.repo.museum.MuseumArmour
import me.owdding.skyocean.repo.museum.MuseumItem
import me.owdding.skyocean.repo.museum.MuseumRepoData
import me.owdding.skyocean.utils.OldPackDescriptorFormats
import me.owdding.skyocean.utils.PackDescriptor
import me.owdding.skyocean.utils.PackDescriptorFormats
import me.owdding.skyocean.utils.PackMetadata
import me.owdding.skyocean.utils.PackOverlay
import me.owdding.skyocean.utils.PackOverlayHolder
import me.owdding.skyocean.utils.items.ItemStackBlueprint
import me.owdding.skyocean.utils.tags.SkyblockTagFile
import net.minecraft.core.BlockPos
import net.minecraft.core.ClientAsset
import net.minecraft.network.chat.Component
import net.minecraft.resources.Identifier
import net.minecraft.world.entity.EquipmentSlot
import net.minecraft.world.item.ItemStack
import tech.thatgravyboat.skyblockapi.api.`data`.MayorPerk
import tech.thatgravyboat.skyblockapi.api.area.dungeon.DungeonClass
import tech.thatgravyboat.skyblockapi.api.area.dungeon.DungeonFloor
import tech.thatgravyboat.skyblockapi.api.location.SkyBlockIsland
import tech.thatgravyboat.skyblockapi.api.remote.api.SkyBlockId
import java.lang.Boolean as LangBoolean
import java.lang.Byte as LangByte
import java.lang.Double as LangDouble
import java.lang.Float as LangFloat
import java.lang.Long as LangLong
import java.lang.Short as LangShort
import java.lang.String as LangString
import kotlin.Boolean as KotlinBoolean
import kotlin.Byte as KotlinByte
import kotlin.Double as KotlinDouble
import kotlin.Float as KotlinFloat
import kotlin.Long as KotlinLong
import kotlin.Short as KotlinShort
import kotlin.String as KotlinString

internal object SkyOceanCodecs {
    public val AddListPatchCodec: MapCodec<AddListPatch> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("path").forGetter { getter -> getter.path },
                        CodecUtils.list(getCodec<JsonElement>()).fieldOf("inserts").forGetter { getter -> getter.inserts },
                    ).apply(it) { p_path, p_inserts -> 
                        AddListPatch(path = p_path, inserts = p_inserts)
                    }
                }
            }

    public val AddPatchCodec: MapCodec<AddPatch> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("path").forGetter { getter -> getter.path },
                        getCodec<JsonElement>().fieldOf("insert").forGetter { getter -> getter.insert },
                    ).apply(it) { p_path, p_insert -> 
                        AddPatch(path = p_path, insert = p_insert)
                    }
                }
            }

    public val CodeConfigPatchCodec: MapCodec<CodeConfigPatch> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("name").forGetter { getter -> getter.name },
                    ).apply(it) { p_name -> 
                        CodeConfigPatch(name = p_name)
                    }
                }
            }

    public val RemovePatchCodec: MapCodec<RemovePatch> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("path").forGetter { getter -> getter.path },
                    ).apply(it) { p_path -> 
                        RemovePatch(path = p_path)
                    }
                }
            }

    public val FarmingItemsCodec: MapCodec<FarmingItems> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.list(getCodec<ItemStackBlueprint>()).optionalFieldOf("toolkit_items").forGetter { getter -> Optional.of(getter.toolkitItemsTemplate) },
                    ).apply(it) { p_toolkitItemsTemplate -> 
                        when {
                            p_toolkitItemsTemplate.isPresent -> FarmingItems(toolkitItemsTemplate = p_toolkitItemsTemplate.get())
                            else -> FarmingItems()
                        }
                    }
                }
            }

    public val GalateaItemsCodec: MapCodec<GalateaItems> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<ItemStackBlueprint>().optionalFieldOf("huntaxeItem").forGetter { getter -> Optional.ofNullable(getter.huntaxeItemTemplate) },
                        CodecUtils.list(getCodec<ItemStackBlueprint>()).fieldOf("toolkitItems").forGetter { getter -> getter.toolkitItemsTemplate },
                    ).apply(it) { p_huntaxeItemTemplate, p_toolkitItemsTemplate -> 
                        GalateaItems(huntaxeItemTemplate = p_huntaxeItemTemplate.orElse(null), toolkitItemsTemplate = p_toolkitItemsTemplate)
                    }
                }
            }

    public val ChestItemCodec: MapCodec<ChestItem> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<ItemStackBlueprint>().fieldOf("item_stack").forGetter { getter -> getter.itemStackBlueprint },
                        getCodec<Int>().optionalFieldOf("slot").forGetter { getter -> Optional.of(getter.slot) },
                        getCodec<BlockPos>().fieldOf("pos").forGetter { getter -> getter.pos },
                        getCodec<BlockPos>().optionalFieldOf("pos2").forGetter { getter -> Optional.ofNullable(getter.pos2) },
                    ).apply(it) { p_itemStackBlueprint, p_slot, p_pos, p_pos2 -> 
                        when {
                            p_slot.isPresent -> ChestItem(itemStackBlueprint = p_itemStackBlueprint, pos = p_pos, pos2 = p_pos2.orElse(null), slot = p_slot.get())
                            else -> ChestItem(itemStackBlueprint = p_itemStackBlueprint, pos = p_pos, pos2 = p_pos2.orElse(null))
                        }
                    }
                }
            }

    public val MinionCodec: MapCodec<MinionStorage.Minion> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("partId").forGetter { getter -> getter.partId },
                        getCodec<Int>().fieldOf("maxUnlock").forGetter { getter -> getter.maxUnlock },
                    ).apply(it) { p_partId, p_maxUnlock -> 
                        MinionStorage.Minion(partId = p_partId, maxUnlock = p_maxUnlock)
                    }
                }
            }

    public val StoredPerkDataCodec: MapCodec<StoredPerkData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.map(getCodec<PowderType>(), getCodec<KotlinString>()).optionalFieldOf("hotm").forGetter { getter -> Optional.of(getter.hotm) },
                        CodecUtils.map(getCodec<WhisperType>(), getCodec<KotlinString>()).optionalFieldOf("hotf").forGetter { getter -> Optional.of(getter.hotf) },
                    ).apply(it) { p_hotm, p_hotf -> 
                        when {
                            p_hotm.isPresent && p_hotf.isPresent -> StoredPerkData(hotm = p_hotm.get(), hotf = p_hotf.get())
                            p_hotm.isPresent -> StoredPerkData(hotm = p_hotm.get())
                            p_hotf.isPresent -> StoredPerkData(hotf = p_hotf.get())
                            else -> StoredPerkData()
                        }
                    }
                }
            }

    public val DungeonItemCodec: MapCodec<DungeonItem> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("id").forGetter { getter -> getter.id },
                        getCodec<KotlinDouble>().fieldOf("weight").forGetter { getter -> getter.weight },
                    ).apply(it) { p_id, p_weight -> 
                        DungeonItem(id = p_id, weight = p_weight)
                    }
                }
            }

    public val VanguardRepoDataCodec: MapCodec<VanguardGambling.VanguardRepoData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        Codec.unboundedMap(getCodec<SkyBlockId>(), getCodec<Int>()).fieldOf("items").forGetter { getter -> getter.items },
                        CodecUtils.list(getCodec<SkyBlockId>()).fieldOf("valuables").forGetter { getter -> getter.valuables },
                    ).apply(it) { p_items, p_valuables -> 
                        VanguardGambling.VanguardRepoData(items = p_items, valuables = p_valuables)
                    }
                }
            }

    public val HotkeyPresetCodec: MapCodec<HotkeyPresets.HotkeyPreset> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("name").forGetter { getter -> getter.name },
                        getCodec<KotlinString>().fieldOf("description").forGetter { getter -> getter.description },
                        getCodec<KotlinString>().fieldOf("data").forGetter { getter -> getter.data },
                    ).apply(it) { p_name, p_description, p_data -> 
                        HotkeyPresets.HotkeyPreset(name = p_name, description = p_description, data = p_data)
                    }
                }
            }

    public val v1HotkeyDataCodec: MapCodec<HotkeyUtils.v1HotkeyData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<HotkeyCategory>().fieldOf("category").forGetter { getter -> getter.category },
                        CodecUtils.list(getCodec<Hotkey>()).fieldOf("hotkeys").forGetter { getter -> getter.hotkeys },
                    ).apply(it) { p_category, p_hotkeys -> 
                        HotkeyUtils.v1HotkeyData(category = p_category, hotkeys = p_hotkeys)
                    }
                }
            }

    public val CommandHotkeyActionCodec: MapCodec<CommandHotkeyAction> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("command").forGetter { getter -> getter.command },
                        getCodec<KotlinBoolean>().optionalFieldOf("allow_client_commands").forGetter { getter -> getter.allowClientCommands.let { if (it == false) Optional.empty() else Optional.of(it) } },
                    ).apply(it) { p_command, p_allowClientCommands -> 
                        when {
                            p_allowClientCommands.isPresent -> CommandHotkeyAction(command = p_command, allowClientCommands = p_allowClientCommands.get())
                            else -> CommandHotkeyAction(command = p_command)
                        }
                    }
                }
            }

    public val AndHotkeyConditionCodec: MapCodec<AndHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.mutableList(getCodec<HotkeyCondition>()).optionalFieldOf("conditions").forGetter { getter -> Optional.of(getter.conditions) },
                    ).apply(it) { p_conditions -> 
                        when {
                            p_conditions.isPresent -> AndHotkeyCondition(conditions = p_conditions.get())
                            else -> AndHotkeyCondition()
                        }
                    }
                }
            }

    public val DungeonFloorHotkeyConditionCodec: MapCodec<DungeonFloorHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.compactMutableSet(getCodec<DungeonFloor>()).optionalFieldOf("floors").forGetter { getter -> Optional.of(getter.floors) },
                    ).apply(it) { p_floors -> 
                        when {
                            p_floors.isPresent -> DungeonFloorHotkeyCondition(floors = p_floors.get())
                            else -> DungeonFloorHotkeyCondition()
                        }
                    }
                }
            }

    public val DungeonClassHotkeyConditionCodec: MapCodec<DungeonClassHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.compactMutableSet(getCodec<DungeonClass>()).optionalFieldOf("classes").forGetter { getter -> Optional.of(getter.classes) },
                    ).apply(it) { p_classes -> 
                        when {
                            p_classes.isPresent -> DungeonClassHotkeyCondition(classes = p_classes.get())
                            else -> DungeonClassHotkeyCondition()
                        }
                    }
                }
            }

    public val IslandHotkeyConditionCodec: MapCodec<IslandHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.compactMutableSet(getCodec<SkyBlockIsland>()).optionalFieldOf("islands").forGetter { getter -> Optional.of(getter.islands) },
                    ).apply(it) { p_islands -> 
                        when {
                            p_islands.isPresent -> IslandHotkeyCondition(islands = p_islands.get())
                            else -> IslandHotkeyCondition()
                        }
                    }
                }
            }

    public val MayorPerkHotkeyConditionCodec: MapCodec<MayorPerkHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.compactMutableSet(getCodec<MayorPerk>()).optionalFieldOf("perks").forGetter { getter -> Optional.of(getter.perks) },
                    ).apply(it) { p_perks -> 
                        when {
                            p_perks.isPresent -> MayorPerkHotkeyCondition(perks = p_perks.get())
                            else -> MayorPerkHotkeyCondition()
                        }
                    }
                }
            }

    public val NotHotkeyConditionCodec: MapCodec<NotHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<HotkeyCondition>().fieldOf("child").forGetter { getter -> getter.child },
                    ).apply(it) { p_child -> 
                        NotHotkeyCondition(child = p_child)
                    }
                }
            }

    public val OrHotkeyConditionCodec: MapCodec<OrHotkeyCondition> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.mutableList(getCodec<HotkeyCondition>()).optionalFieldOf("conditions").forGetter { getter -> Optional.of(getter.conditions) },
                    ).apply(it) { p_conditions -> 
                        when {
                            p_conditions.isPresent -> OrHotkeyCondition(conditions = p_conditions.get())
                            else -> OrHotkeyCondition()
                        }
                    }
                }
            }

    public val HotkeyCodec: MapCodec<Hotkey> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Keybind>().fieldOf("keybind").forGetter { getter -> getter.keybind },
                        getCodec<HotkeyAction>().fieldOf("action").forGetter { getter -> getter.action },
                        getCodec<HotkeyCondition>().fieldOf("condition").forGetter { getter -> getter.condition },
                        getCodec<KotlinString>().fieldOf("name").forGetter { getter -> getter.name },
                        getCodec<KotlinBoolean>().optionalFieldOf("enabled").forGetter { getter -> getter.enabled.let { if (it == true) Optional.empty() else Optional.of(it) } },
                        getCodec<UUID>().optionalFieldOf("group").forGetter { getter -> Optional.ofNullable(getter.group) },
                        getCodec<KotlinLong>().optionalFieldOf("created_at").forGetter { getter -> Optional.of(getter.timeCreated) },
                    ).apply(it) { p_keybind, p_action, p_condition, p_name, p_enabled, p_group, p_timeCreated -> 
                        when {
                            p_enabled.isPresent && p_timeCreated.isPresent -> Hotkey(keybind = p_keybind, action = p_action, condition = p_condition, name = p_name, group = p_group.orElse(null), enabled = p_enabled.get(), timeCreated = p_timeCreated.get())
                            p_enabled.isPresent -> Hotkey(keybind = p_keybind, action = p_action, condition = p_condition, name = p_name, group = p_group.orElse(null), enabled = p_enabled.get())
                            p_timeCreated.isPresent -> Hotkey(keybind = p_keybind, action = p_action, condition = p_condition, name = p_name, group = p_group.orElse(null), timeCreated = p_timeCreated.get())
                            else -> Hotkey(keybind = p_keybind, action = p_action, condition = p_condition, name = p_name, group = p_group.orElse(null))
                        }
                    }
                }
            }

    public val HotkeyCategoryCodec: MapCodec<HotkeyCategory> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<UUID>().fieldOf("identifier").forGetter { getter -> getter.identifier },
                        getCodec<KotlinString>().fieldOf("name").forGetter { getter -> getter.name },
                        getCodec<KotlinString>().optionalFieldOf("username").forGetter { getter -> Optional.of(getter.username) },
                    ).apply(it) { p_identifier, p_name, p_username -> 
                        when {
                            p_username.isPresent -> HotkeyCategory(identifier = p_identifier, name = p_name, username = p_username.get())
                            else -> HotkeyCategory(identifier = p_identifier, name = p_name)
                        }
                    }
                }
            }

    public val HotkeyDataCodec: MapCodec<HotkeyManager.StoredData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.mutableSet(getCodec<HotkeyCategory>()).fieldOf("categories").forGetter { getter -> getter.categories },
                        me.owdding.skyocean.features.hotkeys.system.HotkeyManager.hotkeySet.fieldOf("hotkeys").forGetter { getter -> getter.hotkeys },
                    ).apply(it) { p_categories, p_hotkeys -> 
                        HotkeyManager.StoredData(categories = p_categories, hotkeys = p_hotkeys)
                    }
                }
            }

    public val KeybindCodec: MapCodec<Keybind> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.list(getCodec<InputConstants.Key>()).fieldOf("keys").forGetter { getter -> getter.keys },
                        getCodec<KeybindSettings>().fieldOf("settings").forGetter { getter -> getter.settings },
                    ).apply(it) { p_keys, p_settings -> 
                        Keybind(keys = p_keys, settings = p_settings)
                    }
                }
            }

    public val KeybindSettingsCodec: MapCodec<KeybindSettings> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        OptionalAliasMapCodec(listOf("order_sensitive"), false, getCodec<KotlinBoolean>()).forGetter { getter -> Optional.of(getter.orderSensitive) },
                        OptionalAliasMapCodec(listOf("allow_extra_keys"), false, getCodec<KotlinBoolean>()).forGetter { getter -> Optional.of(getter.allowExtraKeys) },
                        getCodec<Int>().optionalFieldOf("priority").forGetter { getter -> Optional.of(getter.priority) },
                        getCodec<ConflictContext>().optionalFieldOf("context").forGetter { getter -> Optional.of(getter.context) },
                    ).apply(it) { p_orderSensitive, p_allowExtraKeys, p_priority, p_context -> 
                        when {
                            p_orderSensitive.isPresent && p_allowExtraKeys.isPresent && p_priority.isPresent && p_context.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), allowExtraKeys = p_allowExtraKeys.get(), priority = p_priority.get(), context = p_context.get())
                            p_orderSensitive.isPresent && p_allowExtraKeys.isPresent && p_priority.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), allowExtraKeys = p_allowExtraKeys.get(), priority = p_priority.get())
                            p_orderSensitive.isPresent && p_allowExtraKeys.isPresent && p_context.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), allowExtraKeys = p_allowExtraKeys.get(), context = p_context.get())
                            p_orderSensitive.isPresent && p_priority.isPresent && p_context.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), priority = p_priority.get(), context = p_context.get())
                            p_allowExtraKeys.isPresent && p_priority.isPresent && p_context.isPresent -> KeybindSettings(allowExtraKeys = p_allowExtraKeys.get(), priority = p_priority.get(), context = p_context.get())
                            p_orderSensitive.isPresent && p_allowExtraKeys.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), allowExtraKeys = p_allowExtraKeys.get())
                            p_orderSensitive.isPresent && p_priority.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), priority = p_priority.get())
                            p_allowExtraKeys.isPresent && p_priority.isPresent -> KeybindSettings(allowExtraKeys = p_allowExtraKeys.get(), priority = p_priority.get())
                            p_orderSensitive.isPresent && p_context.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get(), context = p_context.get())
                            p_allowExtraKeys.isPresent && p_context.isPresent -> KeybindSettings(allowExtraKeys = p_allowExtraKeys.get(), context = p_context.get())
                            p_priority.isPresent && p_context.isPresent -> KeybindSettings(priority = p_priority.get(), context = p_context.get())
                            p_orderSensitive.isPresent -> KeybindSettings(orderSensitive = p_orderSensitive.get())
                            p_allowExtraKeys.isPresent -> KeybindSettings(allowExtraKeys = p_allowExtraKeys.get())
                            p_priority.isPresent -> KeybindSettings(priority = p_priority.get())
                            p_context.isPresent -> KeybindSettings(context = p_context.get())
                            else -> KeybindSettings()
                        }
                    }
                }
            }

    public val DimensionInventoryCodec: MapCodec<DimensionInventory> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.list(getCodec<ItemStackBlueprint>()).optionalFieldOf("inventory").forGetter { getter -> Optional.of(getter.inventoryTemplate) },
                        CodecUtils.map(getCodec<EquipmentSlot>(), getCodec<ItemStackBlueprint>()).optionalFieldOf("armour").forGetter { getter -> Optional.of(getter.armourTemplate) },
                    ).apply(it) { p_inventoryTemplate, p_armourTemplate -> 
                        when {
                            p_inventoryTemplate.isPresent && p_armourTemplate.isPresent -> DimensionInventory(inventoryTemplate = p_inventoryTemplate.get(), armourTemplate = p_armourTemplate.get())
                            p_inventoryTemplate.isPresent -> DimensionInventory(inventoryTemplate = p_inventoryTemplate.get())
                            p_armourTemplate.isPresent -> DimensionInventory(armourTemplate = p_armourTemplate.get())
                            else -> DimensionInventory()
                        }
                    }
                }
            }

    public val MinionRepoDataCodec: MapCodec<MinionHelper.MinionRepoData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<MinionHelper.Levels>().fieldOf("data").forGetter { getter -> getter.data },
                    ).apply(it) { p_data -> 
                        MinionHelper.MinionRepoData(data = p_data)
                    }
                }
            }

    public val LevelsCodec: MapCodec<MinionHelper.Levels> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("default_max").forGetter { getter -> getter.defaultMax },
                        Codec.unboundedMap(getCodec<KotlinString>(), getCodec<Int>()).fieldOf("max_tier_overrides").forGetter { getter -> getter.maxTierOverrides },
                    ).apply(it) { p_defaultMax, p_maxTierOverrides -> 
                        MinionHelper.Levels(defaultMax = p_defaultMax, maxTierOverrides = p_maxTierOverrides)
                    }
                }
            }

    public val CustomItemDataCodec: MapCodec<CustomItemData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<ItemKey>().fieldOf("key").forGetter { getter -> getter.key },
                        me.owdding.skyocean.features.item.custom.data.CustomItemDataComponents.COMPONENT_MAP_CODEC.optionalFieldOf("data").forGetter { getter -> Optional.of(getter.data) },
                    ).apply(it) { p_key, p_data -> 
                        when {
                            p_data.isPresent -> CustomItemData(key = p_key, data = p_data.get())
                            else -> CustomItemData(key = p_key)
                        }
                    }
                }
            }

    public val ArmorTrimCodec: MapCodec<ArmorTrim> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Identifier>().fieldOf("trimMaterial").forGetter { getter -> getter.trimMaterial },
                        getCodec<Identifier>().fieldOf("trimPattern").forGetter { getter -> getter.trimPattern },
                    ).apply(it) { p_trimMaterial, p_trimPattern -> 
                        ArmorTrim(trimMaterial = p_trimMaterial, trimPattern = p_trimPattern)
                    }
                }
            }

    public val StaticItemColorCodec: MapCodec<StaticItemColor> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("colorCode").forGetter { getter -> getter.colorCode },
                    ).apply(it) { p_colorCode -> 
                        StaticItemColor(colorCode = p_colorCode)
                    }
                }
            }

    public val GradientItemColorCodec: MapCodec<GradientItemColor> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.list(getCodec<Int>()).fieldOf("gradient").forGetter { getter -> getter.gradient },
                        getCodec<Int>().fieldOf("time").forGetter { getter -> getter.time },
                    ).apply(it) { p_gradient, p_time -> 
                        GradientItemColor(gradient = p_gradient, time = p_time)
                    }
                }
            }

    public val GradientEntryCodec: MapCodec<GradientEntry> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("color").forGetter { getter -> getter.color },
                        getCodec<KotlinDouble>().fieldOf("progress").forGetter { getter -> getter.progress },
                    ).apply(it) { p_color, p_progress -> 
                        GradientEntry(color = p_color, progress = p_progress)
                    }
                }
            }

    public val SkyBlockDyeCodec: MapCodec<SkyBlockDye> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("id").forGetter { getter -> getter.id },
                    ).apply(it) { p_id -> 
                        SkyBlockDye(id = p_id)
                    }
                }
            }

    public val AnimatedSkyBlockDyeCodec: MapCodec<AnimatedSkyBlockDye> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("id").forGetter { getter -> getter.id },
                    ).apply(it) { p_id -> 
                        AnimatedSkyBlockDye(id = p_id)
                    }
                }
            }

    public val UuidKeyCodec: MapCodec<UuidKey> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<UUID>().fieldOf("uuid").forGetter { getter -> getter.uuid },
                    ).apply(it) { p_uuid -> 
                        UuidKey(uuid = p_uuid)
                    }
                }
            }

    public val IdAndTimeKeyCodec: MapCodec<IdAndTimeKey> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("item").forGetter { getter -> getter.item },
                        getCodec<KotlinLong>().fieldOf("time").forGetter { getter -> getter.time },
                    ).apply(it) { p_item, p_time -> 
                        IdAndTimeKey(item = p_item, time = p_time)
                    }
                }
            }

    public val IdKeyCodec: MapCodec<IdKey> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("key").forGetter { getter -> getter.key },
                    ).apply(it) { p_key -> 
                        IdKey(key = p_key)
                    }
                }
            }

    public val StaticModelCodec: MapCodec<StaticModel> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Identifier>().fieldOf("location").forGetter { getter -> getter.location },
                    ).apply(it) { p_location -> 
                        StaticModel(location = p_location)
                    }
                }
            }

    public val SkyblockModelCodec: MapCodec<SkyblockModel> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("location").forGetter { getter -> getter.location },
                    ).apply(it) { p_location -> 
                        SkyblockModel(location = p_location)
                    }
                }
            }

    public val StaticSkinCodec: MapCodec<StaticSkin> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("skin").forGetter { getter -> getter.skin },
                    ).apply(it) { p_skin -> 
                        StaticSkin(skin = p_skin)
                    }
                }
            }

    public val SkyblockSkinCodec: MapCodec<SkyblockSkin> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("item").forGetter { getter -> getter.item },
                    ).apply(it) { p_item -> 
                        SkyblockSkin(item = p_item)
                    }
                }
            }

    public val AnimatedSkyblockSkinCodec: MapCodec<AnimatedSkyblockSkin> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("id").forGetter { getter -> getter.id },
                    ).apply(it) { p_id -> 
                        AnimatedSkyblockSkin(id = p_id)
                    }
                }
            }

    public val SkyOceanItemIngredientCodec: MapCodec<SkyOceanItemIngredient> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("id").forGetter { getter -> getter.id },
                        getCodec<Int>().optionalFieldOf("amount").forGetter { getter -> Optional.of(getter.amount) },
                    ).apply(it) { p_id, p_amount -> 
                        when {
                            p_amount.isPresent -> SkyOceanItemIngredient(id = p_id, amount = p_amount.get())
                            else -> SkyOceanItemIngredient(id = p_id)
                        }
                    }
                }
            }

    public val CurrencyIngredientCodec: MapCodec<CurrencyIngredient> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("amount").forGetter { getter -> getter.amount },
                        getCodec<CurrencyType>().fieldOf("currency").forGetter { getter -> getter.currency },
                    ).apply(it) { p_amount, p_currency -> 
                        CurrencyIngredient(amount = p_amount, currency = p_currency)
                    }
                }
            }

    public val SkyShardsRecipeCodec: MapCodec<SkyShardsRecipe> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyShardsMethod>().fieldOf("tree").forGetter { getter -> getter.tree },
                    ).apply(it) { p_tree -> 
                        SkyShardsRecipe(tree = p_tree)
                    }
                }
            }

    public val SkyShardsRecipeElementCodec: MapCodec<SkyShardsRecipeElement> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("shard").forGetter { getter -> getter.shard },
                        getCodec<Int>().fieldOf("quantity").forGetter { getter -> getter.quantity },
                        getCodec<Int>().fieldOf("craftsExpected").forGetter { getter -> getter.craftsExpected },
                        getCodec<Int>().fieldOf("outputQuantity").forGetter { getter -> getter.outputQuantity },
                        getCodec<Int>().fieldOf("pureReptile").forGetter { getter -> getter.pureReptile },
                        CodecUtils.list(getCodec<SkyShardsMethod>()).fieldOf("inputs").forGetter { getter -> getter._inputs },
                    ).apply(it) { p_shard, p_quantity, p_craftsExpected, p_outputQuantity, p_pureReptile, p__inputs -> 
                        SkyShardsRecipeElement(shard = p_shard, quantity = p_quantity, craftsExpected = p_craftsExpected, outputQuantity = p_outputQuantity, pureReptile = p_pureReptile, _inputs = p__inputs)
                    }
                }
            }

    public val SkyShardsDirectElementCodec: MapCodec<SkyShardsDirectElement> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("shard").forGetter { getter -> getter.shard },
                        getCodec<Int>().fieldOf("quantity").forGetter { getter -> getter.quantity },
                    ).apply(it) { p_shard, p_quantity -> 
                        SkyShardsDirectElement(shard = p_shard, quantity = p_quantity)
                    }
                }
            }

    public val SkyShardsCycleElementCodec: MapCodec<SkyShardsCycleElement> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("shard").forGetter { getter -> getter.shard },
                        getCodec<Int>().fieldOf("quantity").forGetter { getter -> getter.quantity },
                        getCodec<Int>().fieldOf("craftsExpected").forGetter { getter -> getter.craftsExpected },
                        getCodec<Int>().fieldOf("outputQuantity").forGetter { getter -> getter.outputQuantity },
                        getCodec<Int>().fieldOf("pureReptile").forGetter { getter -> getter.pureReptile },
                        CodecUtils.list(getCodec<SkyShardsCycleStep>()).fieldOf("steps").forGetter { getter -> getter.steps },
                    ).apply(it) { p_shard, p_quantity, p_craftsExpected, p_outputQuantity, p_pureReptile, p_steps -> 
                        SkyShardsCycleElement(shard = p_shard, quantity = p_quantity, craftsExpected = p_craftsExpected, outputQuantity = p_outputQuantity, pureReptile = p_pureReptile, steps = p_steps)
                    }
                }
            }

    public val SkyShardsCycleStepCodec: MapCodec<SkyShardsCycleStep> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().fieldOf("shard").forGetter { getter -> getter.shard },
                        CodecUtils.list(getCodec<SkyBlockId>()).fieldOf("inputs").forGetter { getter -> getter.inputs },
                    ).apply(it) { p_shard, p_inputs -> 
                        SkyShardsCycleStep(shard = p_shard, inputs = p_inputs)
                    }
                }
            }

    public val NormalCraftHelperRecipeCodec: MapCodec<NormalCraftHelperRecipe> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<SkyBlockId>().optionalFieldOf("item").forGetter { getter -> Optional.ofNullable(getter.item) },
                        getCodec<Int>().optionalFieldOf("amount").forGetter { getter -> Optional.of(getter.amount) },
                    ).apply(it) { p_item, p_amount -> 
                        when {
                            p_amount.isPresent -> NormalCraftHelperRecipe(item = p_item.orElse(null), amount = p_amount.get())
                            else -> NormalCraftHelperRecipe(item = p_item.orElse(null))
                        }
                    }
                }
            }

    public val CustomRecipeCodec: MapCodec<CustomRecipe> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<ItemLikeIngredient>().optionalFieldOf("output").forGetter { getter -> Optional.ofNullable(getter.output) },
                        CodecUtils.mutableList(getCodec<Ingredient>()).fieldOf("inputs").forGetter { getter -> getter.inputs },
                    ).apply(it) { p_output, p_inputs -> 
                        CustomRecipe(output = p_output.orElse(null), inputs = p_inputs)
                    }
                }
            }

    public val MobIconSettingsCodec: MapCodec<MobIconSettings> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinBoolean>().fieldOf("shouldColor").forGetter { getter -> getter.shouldColor },
                    ).apply(it) { p_shouldColor -> 
                        MobIconSettings(shouldColor = p_shouldColor)
                    }
                }
            }

    public val SackCodec: MapCodec<SackData.Sack> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("sack").forGetter { getter -> getter.sack },
                        CodecUtils.list(getCodec<KotlinString>()).fieldOf("items").forGetter { getter -> getter.items },
                    ).apply(it) { p_sack, p_items -> 
                        SackData.Sack(sack = p_sack, items = p_items)
                    }
                }
            }

    public val SkyShardsAttributeDataCodec: MapCodec<SkyShardsAttributeData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("fuse_amount").forGetter { getter -> getter.fuseAmount },
                    ).apply(it) { p_fuseAmount -> 
                        SkyShardsAttributeData(fuseAmount = p_fuseAmount)
                    }
                }
            }

    public val AnimatedSkullDataCodec: MapCodec<AnimatedSkulls.AnimatedSkullData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        me.owdding.skyocean.repo.customization.AnimatedSkulls.minOne.optionalFieldOf("ticks").forGetter { getter -> Optional.of(getter.ticks) },
                        me.owdding.skyocean.repo.customization.AnimatedSkulls.textureCodec.fieldOf("textures").forGetter { getter -> getter.textures },
                    ).apply(it) { p_ticks, p_textures -> 
                        when {
                            p_ticks.isPresent -> AnimatedSkulls.AnimatedSkullData(textures = p_textures, ticks = p_ticks.get())
                            else -> AnimatedSkulls.AnimatedSkullData(textures = p_textures)
                        }
                    }
                }
            }

    public val GalateaDataCodec: MapCodec<GalateaData> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<BlockPos>().fieldOf("moonglade_beacon_pos").forGetter { getter -> getter.moongladeBeaconPos },
                    ).apply(it) { p_moongladeBeaconPos -> 
                        GalateaData(moongladeBeaconPos = p_moongladeBeaconPos)
                    }
                }
            }

    public val MuseumArmourCodec: MapCodec<MuseumArmour> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("armor_id").forGetter { getter -> getter.id },
                        getCodec<KotlinString>().optionalFieldOf("parent_id").forGetter { getter -> Optional.ofNullable(getter.parentId) },
                        CodecUtils.list(getCodec<KotlinString>()).optionalFieldOf("items").forGetter { getter -> Optional.of(getter.armorIds) },
                    ).apply(it) { p_id, p_parentId, p_armorIds -> 
                        when {
                            p_armorIds.isPresent -> MuseumArmour(id = p_id, parentId = p_parentId.orElse(null), armorIds = p_armorIds.get())
                            else -> MuseumArmour(id = p_id, parentId = p_parentId.orElse(null))
                        }
                    }
                }
            }

    public val MuseumItemCodec: MapCodec<MuseumItem> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("id").forGetter { getter -> getter.id },
                        getCodec<KotlinString>().optionalFieldOf("parent").forGetter { getter -> Optional.ofNullable(getter.parentId) },
                        CodecUtils.list(getCodec<KotlinString>()).optionalFieldOf("mapped_item_ids").forGetter { getter -> Optional.of(getter.mappedIds) },
                    ).apply(it) { p_id, p_parentId, p_mappedIds -> 
                        when {
                            p_mappedIds.isPresent -> MuseumItem(id = p_id, parentId = p_parentId.orElse(null), mappedIds = p_mappedIds.get())
                            else -> MuseumItem(id = p_id, parentId = p_parentId.orElse(null))
                        }
                    }
                }
            }

    public val MuseumDataCodec: MapCodec<MuseumRepoData.Data> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.list(getCodec<KotlinString>()).fieldOf("special").forGetter { getter -> getter.special },
                        Codec.unboundedMap(getCodec<KotlinString>(), getCodec<MuseumRepoData.MuseumCategory>()).fieldOf("categories").forGetter { getter -> getter.categories },
                    ).apply(it) { p_special, p_categories -> 
                        MuseumRepoData.Data(special = p_special, categories = p_categories)
                    }
                }
            }

    public val MuseumCategoryCodec: MapCodec<MuseumRepoData.MuseumCategory> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        me.owdding.skyocean.repo.museum.MuseumItem.Companion.MUSEUM_ITEM_CODEC.fieldOf("items").forGetter { getter -> getter.items },
                        CodecUtils.list(getCodec<MuseumArmour>()).fieldOf("armors").forGetter { getter -> getter.armors },
                    ).apply(it) { p_items, p_armors -> 
                        MuseumRepoData.MuseumCategory(items = p_items, armors = p_armors)
                    }
                }
            }

    public val PackMetadataCodec: MapCodec<PackMetadata> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<PackDescriptor>().fieldOf("pack").forGetter { getter -> getter.pack },
                        getCodec<PackOverlayHolder>().optionalFieldOf("overlays").forGetter { getter -> Optional.ofNullable(getter.overlays) },
                    ).apply(it) { p_pack, p_overlays -> 
                        PackMetadata(pack = p_pack, overlays = p_overlays.orElse(null))
                    }
                }
            }

    public val PackDescriptorCodec: MapCodec<PackDescriptor> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<JsonElement>().fieldOf("description").forGetter { getter -> getter.description },
                        getMapCodec<PackDescriptorFormats>().forGetter { getter -> getter.formats },
                        getCodec<Int>().optionalFieldOf("pack_format").forGetter { getter -> Optional.of(getter.packFormat) },
                        getCodec<OldPackDescriptorFormats>().optionalFieldOf("supported_formats").forGetter { getter -> Optional.of(getter._supportedFormats) },
                    ).apply(it) { p_description, p_formats, p_packFormat, p__supportedFormats -> 
                        when {
                            p_packFormat.isPresent && p__supportedFormats.isPresent -> PackDescriptor(description = p_description, formats = p_formats, packFormat = p_packFormat.get(), _supportedFormats = p__supportedFormats.get())
                            p_packFormat.isPresent -> PackDescriptor(description = p_description, formats = p_formats, packFormat = p_packFormat.get())
                            p__supportedFormats.isPresent -> PackDescriptor(description = p_description, formats = p_formats, _supportedFormats = p__supportedFormats.get())
                            else -> PackDescriptor(description = p_description, formats = p_formats)
                        }
                    }
                }
            }

    public val PackDescriptorFormatsCodec: MapCodec<PackDescriptorFormats> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("min_format").forGetter { getter -> getter.minFormat },
                        getCodec<Int>().fieldOf("max_format").forGetter { getter -> getter.maxFormat },
                    ).apply(it) { p_minFormat, p_maxFormat -> 
                        PackDescriptorFormats(minFormat = p_minFormat, maxFormat = p_maxFormat)
                    }
                }
            }

    public val OldPackDescriptorFormatsCodec: MapCodec<OldPackDescriptorFormats> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<Int>().fieldOf("min_inclusive").forGetter { getter -> getter.minFormat },
                        getCodec<Int>().fieldOf("max_inclusive").forGetter { getter -> getter.maxFormat },
                    ).apply(it) { p_minFormat, p_maxFormat -> 
                        OldPackDescriptorFormats(minFormat = p_minFormat, maxFormat = p_maxFormat)
                    }
                }
            }

    public val PackOverlayHolderCodec: MapCodec<PackOverlayHolder> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.mutableList(getCodec<PackOverlay>()).optionalFieldOf("entries").forGetter { getter -> Optional.of(getter.entries) },
                    ).apply(it) { p_entries -> 
                        when {
                            p_entries.isPresent -> PackOverlayHolder(entries = p_entries.get())
                            else -> PackOverlayHolder()
                        }
                    }
                }
            }

    public val PackOverlayCodec: MapCodec<PackOverlay> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        getCodec<KotlinString>().fieldOf("directory").forGetter { getter -> getter.directory },
                        getMapCodec<PackDescriptorFormats>().forGetter { getter -> getter.formats },
                        getCodec<OldPackDescriptorFormats>().optionalFieldOf("formats").forGetter { getter -> Optional.of(getter._formats) },
                    ).apply(it) { p_directory, p_formats, p__formats -> 
                        when {
                            p__formats.isPresent -> PackOverlay(directory = p_directory, formats = p_formats, _formats = p__formats.get())
                            else -> PackOverlay(directory = p_directory, formats = p_formats)
                        }
                    }
                }
            }

    public val SkyblockTagFileCodec: MapCodec<SkyblockTagFile> = CodecUtils.lazyMapCodec {
                RecordCodecBuilder.mapCodec {
                    it.group(
                        CodecUtils.list(getCodec<KotlinString>()).fieldOf("values").forGetter { getter -> getter.values },
                    ).apply(it) { p_values -> 
                        SkyblockTagFile(values = p_values)
                    }
                }
            }

    public val ItemColorCodec: MapCodec<ItemColor> = Codec.STRING.dispatchMap("type", { it.type.id }, { ItemColorType.getType(it).codec })

    public val ItemKeyCodec: MapCodec<ItemKey> = Codec.STRING.dispatchMap("type", { it.type.id }, { ItemKeyType.getType(it).codec })

    public val ItemModelCodec: MapCodec<ItemModel> = Codec.STRING.dispatchMap("type", { it.type.id }, { ItemModelType.getType(it).codec })

    public val ItemSkinCodec: MapCodec<ItemSkin> = Codec.STRING.dispatchMap("type", { it.type.id }, { ItemSkinType.getType(it).codec })

    public val IngredientCodec: MapCodec<Ingredient> = Codec.STRING.dispatchMap("type", { it.type.id }, { IngredientType.getType(it).codec })

    public val CraftHelperRecipeCodec: MapCodec<CraftHelperRecipe> = Codec.STRING.dispatchMap("type", { it.type.id }, { CraftHelperRecipeType.getType(it).codec })

    public val SkyShardsMethodCodec: MapCodec<SkyShardsMethod> = Codec.STRING.dispatchMap("method", { it.method.id }, { SkyShardsMethodType.getType(it).codec })

    public inline fun <reified T> getLazyCodec(): Codec<Lazy<T>> = getLazyCodec(T::class.java) as Codec<Lazy<T>>

    public inline fun <reified T> getLazyMapCodec(): MapCodec<Lazy<T>> = getLazyMapCodec(T::class.java) as MapCodec<Lazy<T>>

    public inline fun <reified T> getCodec(): Codec<T> = getCodec(T::class.java) as Codec<T>

    public inline fun <reified T> getMapCodec(): MapCodec<T> = getMapCodec(T::class.java) as MapCodec<T>

    public fun getLazyMapCodec(clazz: Class<*>): MapCodec<out Lazy<*>> = when {
        else -> CodecUtils.toLazy(getMapCodec(clazz))
    }

    public fun getLazyCodec(clazz: Class<*>): Codec<out Lazy<*>> = when {
        else -> getLazyMapCodec(clazz).codec()
    }

    public fun getMapCodec(clazz: Class<*>): MapCodec<*> = when {
        clazz == ItemStackBlueprint::class.java -> me.owdding.skyocean.utils.items.ItemStackBlueprint.Companion.MAP_CODEC
        clazz == ItemColor::class.java -> ItemColorCodec
        clazz == ItemKey::class.java -> ItemKeyCodec
        clazz == ItemModel::class.java -> ItemModelCodec
        clazz == ItemSkin::class.java -> ItemSkinCodec
        clazz == Ingredient::class.java -> IngredientCodec
        clazz == CraftHelperRecipe::class.java -> CraftHelperRecipeCodec
        clazz == SkyShardsMethod::class.java -> SkyShardsMethodCodec
        clazz == AddListPatch::class.java -> AddListPatchCodec
        clazz == AddPatch::class.java -> AddPatchCodec
        clazz == CodeConfigPatch::class.java -> CodeConfigPatchCodec
        clazz == RemovePatch::class.java -> RemovePatchCodec
        clazz == FarmingItems::class.java -> FarmingItemsCodec
        clazz == GalateaItems::class.java -> GalateaItemsCodec
        clazz == ChestItem::class.java -> ChestItemCodec
        clazz == MinionStorage.Minion::class.java -> MinionCodec
        clazz == StoredPerkData::class.java -> StoredPerkDataCodec
        clazz == DungeonItem::class.java -> DungeonItemCodec
        clazz == VanguardGambling.VanguardRepoData::class.java -> VanguardRepoDataCodec
        clazz == HotkeyPresets.HotkeyPreset::class.java -> HotkeyPresetCodec
        clazz == HotkeyUtils.v1HotkeyData::class.java -> v1HotkeyDataCodec
        clazz == CommandHotkeyAction::class.java -> CommandHotkeyActionCodec
        clazz == AndHotkeyCondition::class.java -> AndHotkeyConditionCodec
        clazz == DungeonFloorHotkeyCondition::class.java -> DungeonFloorHotkeyConditionCodec
        clazz == DungeonClassHotkeyCondition::class.java -> DungeonClassHotkeyConditionCodec
        clazz == IslandHotkeyCondition::class.java -> IslandHotkeyConditionCodec
        clazz == MayorPerkHotkeyCondition::class.java -> MayorPerkHotkeyConditionCodec
        clazz == NotHotkeyCondition::class.java -> NotHotkeyConditionCodec
        clazz == OrHotkeyCondition::class.java -> OrHotkeyConditionCodec
        clazz == Hotkey::class.java -> HotkeyCodec
        clazz == HotkeyCategory::class.java -> HotkeyCategoryCodec
        clazz == HotkeyManager.StoredData::class.java -> HotkeyDataCodec
        clazz == Keybind::class.java -> KeybindCodec
        clazz == KeybindSettings::class.java -> KeybindSettingsCodec
        clazz == DimensionInventory::class.java -> DimensionInventoryCodec
        clazz == MinionHelper.MinionRepoData::class.java -> MinionRepoDataCodec
        clazz == MinionHelper.Levels::class.java -> LevelsCodec
        clazz == CustomItemData::class.java -> CustomItemDataCodec
        clazz == ArmorTrim::class.java -> ArmorTrimCodec
        clazz == StaticItemColor::class.java -> StaticItemColorCodec
        clazz == GradientItemColor::class.java -> GradientItemColorCodec
        clazz == GradientEntry::class.java -> GradientEntryCodec
        clazz == SkyBlockDye::class.java -> SkyBlockDyeCodec
        clazz == AnimatedSkyBlockDye::class.java -> AnimatedSkyBlockDyeCodec
        clazz == UuidKey::class.java -> UuidKeyCodec
        clazz == IdAndTimeKey::class.java -> IdAndTimeKeyCodec
        clazz == IdKey::class.java -> IdKeyCodec
        clazz == StaticModel::class.java -> StaticModelCodec
        clazz == SkyblockModel::class.java -> SkyblockModelCodec
        clazz == StaticSkin::class.java -> StaticSkinCodec
        clazz == SkyblockSkin::class.java -> SkyblockSkinCodec
        clazz == AnimatedSkyblockSkin::class.java -> AnimatedSkyblockSkinCodec
        clazz == SkyOceanItemIngredient::class.java -> SkyOceanItemIngredientCodec
        clazz == CurrencyIngredient::class.java -> CurrencyIngredientCodec
        clazz == SkyShardsRecipe::class.java -> SkyShardsRecipeCodec
        clazz == SkyShardsRecipeElement::class.java -> SkyShardsRecipeElementCodec
        clazz == SkyShardsDirectElement::class.java -> SkyShardsDirectElementCodec
        clazz == SkyShardsCycleElement::class.java -> SkyShardsCycleElementCodec
        clazz == SkyShardsCycleStep::class.java -> SkyShardsCycleStepCodec
        clazz == NormalCraftHelperRecipe::class.java -> NormalCraftHelperRecipeCodec
        clazz == CustomRecipe::class.java -> CustomRecipeCodec
        clazz == MobIconSettings::class.java -> MobIconSettingsCodec
        clazz == SackData.Sack::class.java -> SackCodec
        clazz == SkyShardsAttributeData::class.java -> SkyShardsAttributeDataCodec
        clazz == AnimatedSkulls.AnimatedSkullData::class.java -> AnimatedSkullDataCodec
        clazz == GalateaData::class.java -> GalateaDataCodec
        clazz == MuseumArmour::class.java -> MuseumArmourCodec
        clazz == MuseumItem::class.java -> MuseumItemCodec
        clazz == MuseumRepoData.Data::class.java -> MuseumDataCodec
        clazz == MuseumRepoData.MuseumCategory::class.java -> MuseumCategoryCodec
        clazz == PackMetadata::class.java -> PackMetadataCodec
        clazz == PackDescriptor::class.java -> PackDescriptorCodec
        clazz == PackDescriptorFormats::class.java -> PackDescriptorFormatsCodec
        clazz == OldPackDescriptorFormats::class.java -> OldPackDescriptorFormatsCodec
        clazz == PackOverlayHolder::class.java -> PackOverlayHolderCodec
        clazz == PackOverlay::class.java -> PackOverlayCodec
        clazz == SkyblockTagFile::class.java -> SkyblockTagFileCodec
        else -> throw IllegalArgumentException("Unknown codec for class: $clazz")
    }

    public fun getCodec(clazz: Class<*>): Codec<*> = when {
        clazz == LangString::class.java -> com.mojang.serialization.Codec.STRING
        clazz == KotlinString::class.java -> com.mojang.serialization.Codec.STRING
        clazz == LangBoolean::class.java -> com.mojang.serialization.Codec.BOOL
        clazz == KotlinBoolean::class.java -> com.mojang.serialization.Codec.BOOL
        clazz == LangByte::class.java -> com.mojang.serialization.Codec.BYTE
        clazz == KotlinByte::class.java -> com.mojang.serialization.Codec.BYTE
        clazz == LangShort::class.java -> com.mojang.serialization.Codec.SHORT
        clazz == KotlinShort::class.java -> com.mojang.serialization.Codec.SHORT
        clazz == Integer::class.java -> com.mojang.serialization.Codec.INT
        clazz == Int::class.java -> com.mojang.serialization.Codec.INT
        clazz == LangLong::class.java -> com.mojang.serialization.Codec.LONG
        clazz == KotlinLong::class.java -> com.mojang.serialization.Codec.LONG
        clazz == LangFloat::class.java -> com.mojang.serialization.Codec.FLOAT
        clazz == KotlinFloat::class.java -> com.mojang.serialization.Codec.FLOAT
        clazz == LangDouble::class.java -> com.mojang.serialization.Codec.DOUBLE
        clazz == KotlinDouble::class.java -> com.mojang.serialization.Codec.DOUBLE
        clazz == UUID::class.java -> CodecUtils.UUID_CODEC
        clazz == JsonElement::class.java -> CodecUtils.JSON_ELEMENT_CODEC
        clazz == HotkeyAction::class.java -> me.owdding.skyocean.features.hotkeys.actions.KeybindActions.CODEC
        clazz == HotkeyCondition::class.java -> me.owdding.skyocean.features.hotkeys.conditions.HotkeyConditions.CODEC
        clazz == ItemLikeIngredient::class.java -> me.owdding.skyocean.features.recipe.IngredientType.Companion.ITEM_LIKE
        clazz == ItemStack::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.ITEM_STACK_CODEC
        clazz == BlockPos::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.BLOCK_POS_CODEC
        clazz == Identifier::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.RESOURCE_LOCATION
        clazz == Component::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.COMPONENT_CODEC
        clazz == SkyBlockId::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.SKYBLOCK_ID_UNKNOWN
        clazz == ClientAsset::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.CLIENT_ASSET_CODEC
        clazz == InputConstants.Key::class.java -> me.owdding.skyocean.utils.codecs.CodecHelpers.keyCodec
        clazz.isEnum -> EnumCodec.forKCodec(clazz.enumConstants)
        else -> getMapCodec(clazz).codec()
    }
}
