package me.owdding.skyocean.generated

internal interface DispatchHelper<T: Any> {
    val codec: com.mojang.serialization.MapCodec<out T>
        get() = codec(type)
    val type: kotlin.reflect.KClass<out T>
    val name: String
    val id: String
        get() = name

    private fun <T: Any> codec(type: kotlin.reflect.KClass<T>): com.mojang.serialization.MapCodec<T> {
        return SkyOceanCodecs.getMapCodec(type.java) as com.mojang.serialization.MapCodec<T>
    }
}
