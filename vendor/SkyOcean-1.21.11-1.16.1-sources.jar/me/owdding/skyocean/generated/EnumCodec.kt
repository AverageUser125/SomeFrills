package me.owdding.skyocean.generated

internal class EnumCodec<T> private constructor(private val codec: com.mojang.serialization.Codec<T>) : com.mojang.serialization.Codec<T> {

    override fun <T1 : Any?> encode(input: T, ops: com.mojang.serialization.DynamicOps<T1>?, prefix: T1): com.mojang.serialization.DataResult<T1> = codec.encode(input, ops, prefix)
    override fun <T1 : Any?> decode(ops: com.mojang.serialization.DynamicOps<T1>?, input: T1): com.mojang.serialization.DataResult<com.mojang.datafixers.util.Pair<T, T1>> = codec.decode(ops, input)

    companion object {

        fun <T> forKCodec(constants: Array<T>): EnumCodec<T> =
            EnumCodec(com.mojang.serialization.Codec.withAlternative(constantCodec(constants), intCodec(constants)))

        private fun <T> intCodec(constants: Array<T>): com.mojang.serialization.Codec<T> {
            return com.mojang.serialization.Codec.INT.flatXmap(
                { ordinal: Int ->
                    if (ordinal >= 0 && ordinal < constants.size) {
                        return@flatXmap com.mojang.serialization.DataResult.success<T>(constants[ordinal])
                    }
                    com.mojang.serialization.DataResult.error { "Unknown enum ordinal: $ordinal" }
                },
                { value: T -> com.mojang.serialization.DataResult.success((value as Enum<*>).ordinal) },
            )
        }

        private fun <T> constantCodec(constants: Array<T>): com.mojang.serialization.Codec<T> = com.mojang.serialization.Codec.STRING.flatXmap(
            { name: String ->
                runCatching {
                    com.mojang.serialization.DataResult.success(constants.first { (it as Enum<*>).name.equals(name, true) })
                }.getOrElse {
                    com.mojang.serialization.DataResult.error { "Unknown enum name: $name" }
                }
            },
            { value: T -> com.mojang.serialization.DataResult.success((value as Enum<*>).name) },
        )
    }
}