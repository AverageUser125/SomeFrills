package me.owdding.skyocean.config.features.misc.crafthelper

import com.teamresourceful.resourcefulconfigkt.api.CategoryKt
import me.owdding.skyocean.config.separator
import me.owdding.skyocean.features.item.sources.ItemSources
import me.owdding.skyocean.features.recipe.crafthelper.display.CraftHelperFormat
import me.owdding.skyocean.features.recipe.crafthelper.display.CraftHelperLocation

object CraftHelperConfig : CategoryKt("crafthelper") {
    override val name get() = Translated("skyocean.config.misc.crafthelper")

    init {
        separator("skyocean.config.misc.crafthelper")
    }

    var enabled by boolean(true) {
        translation = "skyocean.config.misc.crafthelper.enabled"
    }

    var quickSet by boolean(true) {
        translation = "skyocean.config.misc.crafthelper.quick_set"
    }

    var hideCompleted by boolean(true) {
        translation = "skyocean.config.misc.crafthelper.hideCompleted"
    }

    var parentAmount by boolean(true) {
        translation = "skyocean.config.misc.crafthelper.parentAmount"
    }

    var noRootItems by boolean(false) {
        translation = "skyocean.config.misc.crafthelper.disableRootItems"
    }

    var disallowedSources by select<ItemSources> {
        translation = "skyocean.config.misc.crafthelper.disallowedItemSources"
    }

    var position by enum(CraftHelperLocation.LEFT_OF_INVENTORY) {
        translation = "skyocean.config.misc.crafthelper.position"
    }

    var margin by int(10) {
        translation = "skyocean.config.misc.crafthelper.margin"
    }

    val doneNotificationConfig by obj(CraftHelperNotificationsConfig) {
        translation = "skyocean.config.misc.crafthelper.done_notifications"
    }

    var formatter by enum(CraftHelperFormat.TREE) {
        translation = "skyocean.config.misc.crafthelper.tree_formatter"
    }

    var rawFormatterHideCompleted by boolean(false) {
        translation = "skyocean.config.misc.crafthelper.raw_formatter_hide_completed"
    }

    var enableOverlay by boolean(false) {
        translation = "skyocean.config.misc.crafthelper.enable_hud_overlay"
    }

    var overlayBackground by boolean(false) {
        translation = "skyocean.config.misc.crafthelper.overlay_background"
    }

    init {
        separator("skyocean.config.misc.crafthelper.transformers")
    }

    var compactedCutoffDegree by int(0) {
        translation = "skyocean.config.misc.crafthelper.transformers.compacted_cutoff_degree"
        range = 0..5
        slider = true
    }
}
