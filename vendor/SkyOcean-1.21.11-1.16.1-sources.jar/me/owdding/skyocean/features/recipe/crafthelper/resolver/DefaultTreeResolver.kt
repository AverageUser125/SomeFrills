package me.owdding.skyocean.features.recipe.crafthelper.resolver

import me.owdding.skyocean.data.profile.CraftHelperStorage
import me.owdding.skyocean.features.recipe.SimpleRecipeApi.getBestRecipe
import me.owdding.skyocean.features.recipe.SkyOceanItemIngredient
import me.owdding.skyocean.features.recipe.crafthelper.CraftHelperTree
import me.owdding.skyocean.features.recipe.crafthelper.data.CraftHelperRecipeType
import me.owdding.skyocean.features.recipe.crafthelper.data.NormalCraftHelperRecipe
import me.owdding.skyocean.utils.chat.ChatUtils.sendWithPrefix
import tech.thatgravyboat.skyblockapi.utils.text.Text
import tech.thatgravyboat.skyblockapi.utils.text.TextColor
import tech.thatgravyboat.skyblockapi.utils.text.TextStyle.color

object DefaultTreeResolver : TreeResolver<NormalCraftHelperRecipe> {
    override val type: CraftHelperRecipeType get() = CraftHelperRecipeType.NORMAL

    override fun resolve(recipe: NormalCraftHelperRecipe, resetLayout: () -> Unit, clear: () -> Unit): CraftHelperTree? {

        val currentRecipe = CraftHelperStorage.selectedItem ?: run {
            resetLayout()
            return null
        }

        val recipe = getBestRecipe(currentRecipe) ?: return CraftHelperTree(
            recipe = null,
            output = SkyOceanItemIngredient(currentRecipe, CraftHelperStorage.selectedAmount.coerceAtLeast(1)),
        )

        val output = recipe.output ?: run {
            Text.of("Recipe output is null!") { this.color = TextColor.RED }.sendWithPrefix()
            resetLayout()
            clear()
            return null
        }

        return CraftHelperTree(recipe, output, CraftHelperStorage.selectedAmount.coerceAtLeast(1))
    }
}
