package me.owdding.skyocean.features.recipe.crafthelper

import com.mojang.blaze3d.platform.InputConstants
import me.owdding.ktmodules.Module
import me.owdding.lib.compat.REIRuntimeCompatability
import me.owdding.skyocean.ApiDebug
import me.owdding.skyocean.config.SkyOceanKeybind
import me.owdding.skyocean.config.features.misc.crafthelper.CraftHelperConfig
import me.owdding.skyocean.config.features.misc.crafthelper.CraftHelperNotificationType
import me.owdding.skyocean.data.profile.CraftHelperStorage
import me.owdding.skyocean.data.profile.CraftHelperStorage.setSelected
import me.owdding.skyocean.features.item.sources.ItemSources
import me.owdding.skyocean.features.recipe.crafthelper.eval.ItemTracker
import me.owdding.skyocean.features.recipe.crafthelper.views.CraftHelperState
import me.owdding.skyocean.features.recipe.crafthelper.views.SimpleRecipeView
import me.owdding.skyocean.features.recipe.crafthelper.visitors.CompactedResourceCutoffTreeTransformer
import me.owdding.skyocean.utils.Utils.refreshScreen
import me.owdding.skyocean.utils.Utils.text
import me.owdding.skyocean.utils.chat.ChatUtils
import me.owdding.skyocean.utils.chat.ChatUtils.sendWithPrefix
import me.owdding.skyocean.utils.debug.DebugBuilder
import tech.thatgravyboat.skyblockapi.api.events.base.Subscription
import tech.thatgravyboat.skyblockapi.api.events.base.predicates.TimePassed
import tech.thatgravyboat.skyblockapi.api.events.screen.ScreenKeyReleasedEvent
import tech.thatgravyboat.skyblockapi.api.events.time.TickEvent
import tech.thatgravyboat.skyblockapi.api.remote.api.SkyBlockId
import tech.thatgravyboat.skyblockapi.api.remote.api.SkyBlockId.Companion.getSkyBlockId
import tech.thatgravyboat.skyblockapi.helpers.McClient
import tech.thatgravyboat.skyblockapi.helpers.McScreen
import tech.thatgravyboat.skyblockapi.utils.extentions.getHoveredSlot
import tech.thatgravyboat.skyblockapi.utils.extentions.toFormattedString
import tech.thatgravyboat.skyblockapi.utils.text.Text
import tech.thatgravyboat.skyblockapi.utils.text.TextBuilder.append
import tech.thatgravyboat.skyblockapi.utils.text.TextColor
import tech.thatgravyboat.skyblockapi.utils.text.TextStyle.bold
import tech.thatgravyboat.skyblockapi.utils.text.TextStyle.color
import java.util.concurrent.atomic.AtomicReference
import java.util.function.UnaryOperator

@Module
object CraftHelperManager {
    var lastData: CraftHelperRecipe? = null
    var hasBeenNotified = false
    var lastEvaluatedRoot: AtomicReference<CraftHelperState?> = AtomicReference()
    private val keybind = SkyOceanKeybind("crafthelper", InputConstants.KEY_V)


    fun clear() {
        CraftHelperStorage.clear()
        CraftHelperStorage.save()
    }

    fun resolve(resetLayout: () -> Unit, clear: () -> Unit): CraftHelperTree? {
        val tree = CraftHelperStorage.data?.resolve(resetLayout, clear) ?: return null
        return getTransformers().fold(tree) { tree, op -> op.apply(tree) }
    }

    fun getTransformers(): List<UnaryOperator<CraftHelperTree>> = buildList {

        CraftHelperConfig.compactedCutoffDegree.takeIf { it > 0 }?.let {
            add { tree -> CompactedResourceCutoffTreeTransformer.apply(it, tree) }
        }

    }

    @Subscription(TickEvent::class)
    @TimePassed("5t")
    fun onTick() {
        if (lastData != CraftHelperStorage.data) {
            this.lastData = CraftHelperStorage.data
            hasBeenNotified = false
            lastEvaluatedRoot.set(null)
        }
        val tree = resolve({}, ::clear) ?: return
        SimpleRecipeView {
            if (it.path != "root") return@SimpleRecipeView
            lastEvaluatedRoot.set(it)
            if (!it.childrenDone) return@SimpleRecipeView
            if (hasBeenNotified) return@SimpleRecipeView
            hasBeenNotified = true
            CraftHelperConfig.doneNotificationConfig.doneTypes.forEach(::doneNotification)
        }.visit(tree, ItemTracker(ItemSources.craftHelperSources - CraftHelperConfig.disallowedSources.toSet()))
    }

    fun doneNotification(type: CraftHelperNotificationType) {
        when (type) {
            CraftHelperNotificationType.DONE_MESSAGE -> {
                text("You have all materials to craft ") {
                    CraftHelperStorage.selectedItem?.toItem()?.hoverName?.let { item ->
                        append("${CraftHelperStorage.selectedAmount}x ") { color = TextColor.GREEN }
                        append(item)
                    } ?: append("your selected craft helper tree")
                    append("!")
                }.sendWithPrefix()
            }
            CraftHelperNotificationType.DONE_TITLE -> {
                val title = CraftHelperStorage.selectedItem?.let {
                    Text.of {
                        append(ChatUtils.ICON_WITH_SPACE)
                        append("${CraftHelperStorage.selectedAmount}x ") { color = TextColor.GREEN }
                        append(it.toItem().hoverName)
                        append(" Craftable!") { color = TextColor.GREEN }
                    }
                } ?: Text.of {
                    append("CraftHelper Item Craftable!") { this.color = TextColor.GREEN }
                }
                McClient.setTitle(title, null, 0f, 3f, 0.5f)
            }
            CraftHelperNotificationType.DONE_SOUND -> {
                McClient.playSound(CraftHelperConfig.doneNotificationConfig.soundEvent)
            }
        }
    }


    @Subscription
    fun onKeybind(event: ScreenKeyReleasedEvent.Pre) {
        if (!keybind.matches(event)) return

        val reiHovered = REIRuntimeCompatability.getReiHoveredItemStack()
        val mcScreenHovered = McScreen.asMenu?.getHoveredSlot()?.item?.takeUnless { it.isEmpty }
        val item = mcScreenHovered ?: reiHovered ?: return

        if (item.getSkyBlockId() == null) {
            Text.of("Item ") {
                append(item.hoverName)
                append(" does not have a SkyBlockId, cannot be selected as CraftHelper item")
                color = TextColor.RED
            }.sendWithPrefix("crafthelper_no_id")
            return
        }

        setSelected(SkyBlockId.fromItem(item))
        McScreen.refreshScreen()

        Text.of("Set selected Crafthelper item to ") {
            append(item.hoverName) {
                this.bold = true
            }
        }.sendWithPrefix()
    }

    @ApiDebug("Craft Helper")
    internal fun debug(builder: DebugBuilder) = with(builder) {
        field("Selected", CraftHelperStorage.selectedItem)
        field("Amount", CraftHelperStorage.selectedAmount)
        iterable("Allowed Sources", ItemSources.craftHelperSources - CraftHelperConfig.disallowedSources.toSet()) {
            literal(it.name)
        }
        val itemTracker = ItemTracker(ItemSources.craftHelperSources - CraftHelperConfig.disallowedSources.toSet())
        field("Total Items Tracked", itemTracker.items.values.flatten().sumOf { it.amount }, copyValue = buildString {
            appendLine("Currencies")
            appendLine()
            itemTracker.currencies.entries.sortedByDescending { (_, amount) -> amount }.forEach { (type, amount) ->
                appendLine("- $type: ${amount.toFormattedString()}")
            }
            appendLine()
            appendLine("Items")
            itemTracker.items.entries.sortedByDescending { (_, value) -> value.sumOf { it.amount } }.forEach { (id, sources) ->
                append("- ")
                append(id)
                append(": ")
                append(sources.sumOf { it.amount }.toFormattedString())
                append(" (")
                append(sources.map { 1 shl it.source.ordinal }.reduce(Int::or).toString(32))
                append(")")
                appendLine()
            }

        })
    }
}
