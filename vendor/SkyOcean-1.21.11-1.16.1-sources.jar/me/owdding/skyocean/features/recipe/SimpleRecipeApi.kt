package me.owdding.skyocean.features.recipe

import me.owdding.lib.utils.MeowddingLogger
import me.owdding.lib.utils.MeowddingLogger.Companion.featureLogger
import me.owdding.skyocean.SkyOcean
import me.owdding.skyocean.generated.CodecUtils
import me.owdding.skyocean.generated.SkyOceanCodecs
import me.owdding.skyocean.utils.LateInitLoader
import me.owdding.skyocean.utils.LateInitModule
import me.owdding.skyocean.utils.Utils
import me.owdding.skyocean.utils.extensions.addAll
import me.owdding.skyocean.utils.extensions.runCatching
import tech.thatgravyboat.repolib.api.RepoAPI
import tech.thatgravyboat.skyblockapi.api.data.SkyBlockRarity
import tech.thatgravyboat.skyblockapi.api.remote.api.SkyBlockId
import tech.thatgravyboat.skyblockapi.api.remote.api.SkyBlockItemId
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import me.owdding.skyocean.features.recipe.RepoApiRecipe as RepoApiRecipeWrapper
import tech.thatgravyboat.repolib.api.recipes.Recipe as RepoApiRecipe

@LateInitModule
object SimpleRecipeApi : MeowddingLogger by SkyOcean.featureLogger(), LateInitLoader {

    internal val supportedTypes = arrayOf(
        RepoApiRecipe.Type.FORGE to RecipeType.FORGE,
        RepoApiRecipe.Type.CRAFTING to RecipeType.CRAFTING,
        RepoApiRecipe.Type.KAT to RecipeType.KAT,
        RepoApiRecipe.Type.SHOP to RecipeType.SHOP,
    )

    internal val illegalIngredients = CopyOnWriteArrayList<SkyBlockItemId>()
    internal val recipes = CopyOnWriteArrayList<Recipe>()
    internal val idToRecipes: MutableMap<SkyBlockId, List<Recipe>> = ConcurrentHashMap()
    internal val illegalShopRecipes = CopyOnWriteArrayList<SkyBlockItemId>()

    override fun load() {
        recipes.clear()
        idToRecipes.clear()
        illegalIngredients.clear()
        illegalShopRecipes.clear()

        runCatching("Loading illegal ingredients from remote repo") {
            illegalIngredients.addAll(Utils.loadRemoteRepoData("skyocean/illegal_ingredients", CodecUtils::list))
            debug("Loaded ${illegalIngredients.size} illegal ingredients")
        }
        runCatching("Loading illegal shop recipes from remote repo") {
            illegalShopRecipes.addAll(Utils.loadRemoteRepoData("skyocean/illegal_shop_recipes", CodecUtils::list))
            debug("Loaded ${illegalShopRecipes.size} illegal shop recipes")
        }

        supportedTypes.forEach { (recipe, type) ->
            recipes += RepoAPI.recipes().getRecipes(recipe).map { recipe ->
                RepoApiRecipeWrapper(
                    recipe,
                    type,
                )
            }
        }
        recipes.removeIf {
            isBlacklisted(it).apply {
                if (this) {
                    trace(
                        "Removing ${it.output?.skyblockId} with ${it.inputs.size} ingredients",
                    )
                }
            }
        }

        debug("Loaded ${recipes.size} Recipes from repo api")
        runCatching("Loading extra recipes from repo!") {
            val extra = Utils.loadRemoteRepoData("skyocean/recipes", SkyOceanCodecs.CustomRecipeCodec.codec().listOf())
            recipes.addAll(extra)
            debug("Loaded ${extra?.size ?: 0} extra from remote repo, new total is ${recipes.size}")
        }

        rebuildRecipes()
    }

    fun rebuildRecipes() {
        idToRecipes.clear()
        idToRecipes.putAll(
            recipes.mapNotNull { recipe -> recipe.output?.id?.let { recipe to it } }
                .groupBy { it.second }
                .mapValues { (_, v) -> v.map { it.first } }
                .filter { (_, v) -> v.isNotEmpty() },
        )
        idToRecipes.putAll(idToRecipes.entries.associate { (key, value) -> SkyBlockId.unsafe(key.cleanId) to value })
    }

    fun hasRecipe(id: SkyBlockId) = idToRecipes.containsKey(id)

    fun getBestRecipe(ingredient: Ingredient) = (ingredient as? ItemLikeIngredient)?.id?.takeIf(::hasRecipe)?.let { getBestRecipe(it) }

    fun getBestRecipe(id: SkyBlockId): Recipe? {

        return runCatching {
            idToRecipes[id]?.firstOrNull()?.let { return@runCatching it }

            val variants = when {
                id.isPet -> SkyBlockRarity.entries.reversed().map { SkyBlockId.pet(id.cleanId, it.name) }
                id.isRune -> (3 downTo 0).map { SkyBlockId.rune(id.cleanId, it) }
                id.isEnchantment -> (10 downTo 0).map { SkyBlockId.enchantment(id.cleanId, it) }
                else -> emptyList()
            }
            variants.mapNotNull { idToRecipes[it] }.firstNotNullOfOrNull { it.firstOrNull() }?.let { return@runCatching it }
        }.getOrNull()
    }

    fun isBlacklisted(recipe: Recipe): Boolean {
        if (recipe.recipeType == SHOP) {
            return illegalShopRecipes.contains(recipe.output?.id)
        }
        val inputs = recipe.inputs
        val itemInputs = inputs.filterIsInstance<ItemLikeIngredient>().map { it.id }.distinct()
        if (inputs.size == itemInputs.size && itemInputs.size == 1 && illegalIngredients.containsAll(itemInputs)) {
            return true
        }

        return illegalIngredients.contains(recipe.output?.id)
    }

    fun <K> MutableMap<K, Ingredient>.addOrPut(key: K, ingredient: Ingredient): Ingredient =
        merge(key, ingredient) { a, b -> a + b }!!
}

