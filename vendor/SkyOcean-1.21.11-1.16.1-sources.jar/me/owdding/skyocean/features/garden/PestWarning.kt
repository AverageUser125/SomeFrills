package me.owdding.skyocean.features.garden

import com.teamresourceful.resourcefulconfig.api.types.info.Translatable
import me.owdding.ktmodules.Module
import me.owdding.skyocean.config.features.garden.GardenConfig
import me.owdding.skyocean.utils.SoundUtils
import me.owdding.skyocean.utils.chat.ChatUtils
import me.owdding.skyocean.utils.chat.ChatUtils.sendWithPrefix
import me.owdding.skyocean.utils.chat.OceanColors
import net.minecraft.sounds.SoundEvents
import tech.thatgravyboat.skyblockapi.api.events.base.Subscription
import tech.thatgravyboat.skyblockapi.api.events.base.predicates.OnlyIn
import tech.thatgravyboat.skyblockapi.api.events.base.predicates.OnlyNonGuest
import tech.thatgravyboat.skyblockapi.api.events.hypixel.ServerChangeEvent
import tech.thatgravyboat.skyblockapi.api.events.level.LeftClickBlockEvent
import tech.thatgravyboat.skyblockapi.api.location.SkyBlockIsland.GARDEN
import tech.thatgravyboat.skyblockapi.api.area.farming.garden.Crop
import tech.thatgravyboat.skyblockapi.api.profile.garden.PlotAPI
import tech.thatgravyboat.skyblockapi.helpers.McClient
import tech.thatgravyboat.skyblockapi.helpers.McLevel
import tech.thatgravyboat.skyblockapi.utils.text.Text
import tech.thatgravyboat.skyblockapi.utils.text.TextBuilder.append
import tech.thatgravyboat.skyblockapi.utils.text.TextStyle.bold
import tech.thatgravyboat.skyblockapi.utils.text.TextStyle.color
import tech.thatgravyboat.skyblockapi.utils.extentions.currentInstant
import tech.thatgravyboat.skyblockapi.utils.extentions.since
import kotlin.time.Instant

@Module
object PestWarning {

    private var lastWarning = Instant.DISTANT_PAST

    enum class PestWarningAmountOptions(val amount: Int) : Translatable {
        AUTO(0),
        ONE(1),
        TWO(2),
        THREE(3),
        FOUR(4),
        FIVE(5),
        SIX(6),
        SEVEN(7),
        EIGHT(8);

        override fun getTranslationKey(): String = "skyocean.config.garden.pest_warning_amount.options.${name.lowercase()}"
    }

    @Subscription
    @OnlyIn(GARDEN)
    @OnlyNonGuest
    fun onBlockClick(event: LeftClickBlockEvent) {
        if (Crop.entries.none { it.isCrop(McLevel[event.pos]) }) return
        val pests = PlotAPI.currentPestAmount
        val minAmount = GardenConfig.pestWarningAmount.amount
        if (minAmount == 0) {
            if (!PlotAPI.hasPestDebuff || pests < 8) return // the pests condition is here in case the player has more than 500 bpc which stops pests from ever giving you a debuff
        } else {
            if (pests < minAmount) return
        }
        if (GardenConfig.pestWarning && lastWarning.since() > GardenConfig.pestWarningDelay) {
            lastWarning = currentInstant()
            val title = Text.of {
                append(ChatUtils.ICON_SPACE_COMPONENT)
                append("$pests pests!") {
                    color = OceanColors.WARNING
                    bold = true
                }
            }
            McClient.setTitle(title, null, 0f, 3f, 0.5f)
            SoundUtils.playRepeated(SoundEvents.NOTE_BLOCK_PLING.value(), 10, 4F, 0.5F)

            Text.of {
                append("There are ") { color = OceanColors.WARNING }
                append("$pests ") { color = OceanColors.BETTER_GOLD }
                append("pests! Kill them to get your Farming Fortune back") { color = OceanColors.WARNING }
            }.sendWithPrefix()
        }
    }

    @Subscription(ServerChangeEvent::class)
    fun onWorldChange() {
        lastWarning = Instant.DISTANT_PAST
    }

}
