package com.github.kd_gaming1.skyblockenhancements.feature.storage;

import com.mojang.serialization.DataResult;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_6903;
import net.minecraft.class_7225;

/**
 * Immutable snapshot of a storage page's contents.
 *
 * <p>Contains a fixed grid of {@link class_1799}s (typically 45 = 5×9).
 * Serialization to compressed NBT is performed asynchronously via
 * {@link CompletableFuture} to avoid frame drops.
 */
public final class VirtualInventory {
    private final List<class_1799> stacks;
    private final int rows;
    private final CompletableFuture<byte[]> serializationFuture;

    public VirtualInventory(List<class_1799> stacks) {
        if (stacks.isEmpty() || stacks.size() > 54) {
            throw new IllegalArgumentException("Stack count must be 1..54");
        }
        if (stacks.size() % 9 != 0) {
            throw new IllegalArgumentException("Stack count must be a multiple of 9");
        }
        // Defensive copy — ItemStacks are mutable
        List<class_1799> copy = new ArrayList<>(stacks.size());
        for (class_1799 s : stacks) {
            copy.add(s.method_7972());
        }
        this.stacks = List.copyOf(copy);
        this.rows = stacks.size() / 9;
        this.serializationFuture = CompletableFuture.supplyAsync(this::serializeToBytes);
    }

    public List<class_1799> stacks() {
        return stacks;
    }

    public int rows() {
        return rows;
    }

    public int size() {
        return stacks.size();
    }

    public class_1799 get(int index) {
        return stacks.get(index);
    }

    public CompletableFuture<byte[]> getSerializationFuture() {
        return serializationFuture;
    }

    private byte[] serializeToBytes() {
        class_2499 list = new class_2499();
        for (class_1799 stack : stacks) {
            if (stack.method_7960()) {
                list.add(new class_2487());
            } else {
                try {
                    class_2520 tag = class_1799.field_24671.encodeStart(class_2509.field_11560, stack).result().orElse(new class_2487());
                    list.add(tag);
                } catch (Exception e) {
                    list.add(new class_2487());
                }
            }
        }
        class_2487 root = new class_2487();
        root.method_10566("Inventory", list);
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            class_2507.method_10634(root, out);
            return out.toByteArray();
        } catch (IOException e) {
            return new byte[0];
        }
    }

    public static VirtualInventory deserialize(byte[] bytes, class_7225.class_7874 lookup) {
        if (bytes == null || bytes.length == 0) {
            return empty(5);
        }
        try {
            class_2487 root = class_2507.method_10629(new ByteArrayInputStream(bytes), class_2505.method_53898());
            class_2499 list = root.method_68569("Inventory");
            class_6903<class_2520> ops = lookup.method_57093(class_2509.field_11560);
            List<class_1799> stacks = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                class_2520 tag = list.method_10534(i);
                if (tag instanceof class_2487 compound && !compound.method_33133()) {
                    DataResult<class_1799> result = class_1799.field_24671.parse(ops, compound);
                    stacks.add(result.result().orElse(class_1799.field_8037));
                } else {
                    stacks.add(class_1799.field_8037);
                }
            }
            // Pad or trim to valid size
            while (stacks.size() < 9) stacks.add(class_1799.field_8037);
            while (stacks.size() > 54) stacks.removeLast();
            int rows = stacks.size() / 9;
            int targetSize = rows * 9;
            while (stacks.size() < targetSize) stacks.add(class_1799.field_8037);
            return new VirtualInventory(stacks);
        } catch (Exception e) {
            return empty(5);
        }
    }

    public static VirtualInventory empty(int rows) {
        List<class_1799> stacks = new ArrayList<>(rows * 9);
        for (int i = 0; i < rows * 9; i++) {
            stacks.add(class_1799.field_8037);
        }
        return new VirtualInventory(stacks);
    }
}
