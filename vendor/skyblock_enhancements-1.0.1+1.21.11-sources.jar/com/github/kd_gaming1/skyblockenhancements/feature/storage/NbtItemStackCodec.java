package com.github.kd_gaming1.skyblockenhancements.feature.storage;

import com.mojang.serialization.DataResult;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_6903;
import net.minecraft.class_7225;

/**
 * Bidirectional codec between {@link class_1799} and Base64-encoded compressed NBT.
 *
 * <p>Uses {@link class_1799#field_24671} with a {@link class_6903} context so that
 * DataComponents are preserved correctly on 1.21.11.
 */
public final class NbtItemStackCodec {

    private NbtItemStackCodec() {}

    /**
     * Encodes an item stack to a Base64 string.
     *
     * @param stack  the stack to encode; empty stacks yield {@code null}
     * @param lookup registry lookup for component serialization
     * @return Base64-encoded compressed NBT, or {@code null} if empty or encoding fails
     */
    public static String encode(class_1799 stack, class_7225.class_7874 lookup) {
        if (stack == null || stack.method_7960()) {
            return null;
        }

        class_6903<class_2520> ops = lookup.method_57093(class_2509.field_11560);
        DataResult<class_2520> result = class_1799.field_24671.encodeStart(ops, stack);
        Optional<class_2520> tagOpt = result.result();
        if (tagOpt.isEmpty() || !(tagOpt.get() instanceof class_2487 compound)) {
            return null;
        }

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            class_2507.method_10634(compound, baos);
            return Base64.getEncoder().encodeToString(baos.toByteArray());
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Decodes a Base64 string to an {@link class_1799}.
     *
     * @param base64 the Base64-encoded compressed NBT
     * @param lookup registry lookup for component deserialization
     * @return the decoded stack, or {@link class_1799#field_8037} on failure
     */
    public static class_1799 decode(String base64, class_7225.class_7874 lookup) {
        if (base64 == null || base64.isEmpty()) {
            return class_1799.field_8037;
        }

        byte[] bytes;
        try {
            bytes = Base64.getDecoder().decode(base64);
        } catch (IllegalArgumentException e) {
            return class_1799.field_8037;
        }

        class_2487 compound;
        try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes)) {
            compound = class_2507.method_10629(bais, class_2505.method_53898());
        } catch (IOException e) {
            return class_1799.field_8037;
        }

        class_6903<class_2520> ops = lookup.method_57093(class_2509.field_11560);
        DataResult<class_1799> result = class_1799.field_24671.parse(ops, compound);
        return result.result().orElse(class_1799.field_8037);
    }

    /**
     * Decodes only the NBT tag from Base64, without resolving to an ItemStack.
     * Useful when the registry lookup is not yet available.
     *
     * @param base64 the Base64-encoded compressed NBT
     * @return the raw compound tag, or empty on failure
     */
    public static Optional<class_2487> decodeToTag(String base64) {
        if (base64 == null || base64.isEmpty()) {
            return Optional.empty();
        }
        try {
            byte[] bytes = Base64.getDecoder().decode(base64);
            try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes)) {
                return Optional.of(class_2507.method_10629(bais, class_2505.method_53898()));
            }
        } catch (Exception e) {
            return Optional.empty();
        }
    }
}
