package com.github.kd_gaming1.skyblockenhancements.feature.storage;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_465;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.gui.storage.ContainerOverlay;
import com.github.kd_gaming1.skyblockenhancements.gui.storage.StorageOverlayGui;

/**
 * Creates and caches storage overlays when a recognised container screen opens.
 */
public final class StorageOverlayLifecycle {

    private StorageOverlayLifecycle() {}

    /**
     * Called by the mixin when a container screen initializes.
     * If the screen is a recognised storage page, creates and returns an overlay.
     */
    public static ContainerOverlay createOverlay(class_465<?> screen) {
        if (!SkyblockEnhancementsConfig.enableStorageDashboard_Test) {
            return null;
        }

        String rawTitle = screen.method_25440().getString();
        Optional<StorageTitleParser.ParsedTitle> parsed = StorageTitleParser.parse(rawTitle);
        if (parsed.isEmpty()) {
            return null;
        }

        StoragePageSlot activeSlot = parsed.get().slot();
        class_310 mc = class_310.method_1551();

        if (parsed.get().isOverview()) {
            for (int i = 0; i < StoragePageSlot.COUNT; i++) {
                StoragePageSlot slot = new StoragePageSlot(i);
                if (!StorageData.INSTANCE.hasInventory(slot)) {
                    StorageData.INSTANCE.updateInventory(slot, slot.defaultName(), null);
                }
            }
            rememberOverview(screen);
            return new StorageOverlayGui(screen, null);
        }

        // Capture the live page data
        if (activeSlot != null && mc.field_1687 != null) {
            rememberPage(screen, activeSlot, rawTitle);
        }

        return new StorageOverlayGui(screen, activeSlot);
    }

    private static void rememberPage(class_465<?> screen, StoragePageSlot slot, String title) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;

        List<class_1799> stacks = new java.util.ArrayList<>();
        for (net.minecraft.class_1735 s : screen.method_17577().field_7761) {
            if (s.field_7871 != mc.field_1724.method_31548()) {
                while (stacks.size() <= s.field_7874) stacks.add(net.minecraft.class_1799.field_8037);
                stacks.set(s.field_7874, s.method_7677().method_7972());
            }
        }
        // Trim to valid size
        int rows = Math.clamp((stacks.size() + 8) / 9, 1, 6);
        int target = rows * 9;
        while (stacks.size() < target) stacks.add(net.minecraft.class_1799.field_8037);
        if (stacks.size() > target) stacks = stacks.subList(0, target);

        VirtualInventory vinv = new VirtualInventory(stacks);
        StorageData.INSTANCE.updateInventory(slot, title, vinv);
        StorageData.INSTANCE.markDirty(vinv.getSerializationFuture());
    }

    private static void rememberOverview(class_465<?> screen) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;

        for (int i = 0; i < screen.method_17577().method_7602().size(); i++) {
            net.minecraft.class_1799 stack = screen.method_17577().method_7602().get(i);
            if (stack.method_7960()) continue;
            StoragePageSlot slot = StoragePageSlot.fromOverviewSlotIndex(i);
            if (slot == null) continue;

            if (!StorageData.INSTANCE.hasInventory(slot)) {
                StorageData.INSTANCE.updateInventory(slot, slot.defaultName(), null);
            }
        }
        StorageData.INSTANCE.markDirty();
    }

    public static void onOverviewPacketReceived(class_465<?> screen) {
        rememberOverview(screen);
    }
}
