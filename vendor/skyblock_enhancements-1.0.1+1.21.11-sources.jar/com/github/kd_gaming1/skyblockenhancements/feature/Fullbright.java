package com.github.kd_gaming1.skyblockenhancements.feature;

import com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import eu.midnightdust.lib.config.MidnightConfig;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class Fullbright {

    private static class_304 toggleKey;
    private static final class_304.class_11900 CATEGORY = KeybindCategories.GENERAL;

    public static void init() {
        toggleKey =
                KeyBindingHelper.registerKeyBinding(
                        new class_304(
                                "key.skyblock_enhancements.fullbright",
                                GLFW.GLFW_KEY_UNKNOWN,
                                CATEGORY));
    }

    public static void onTick(class_310 client) {
        if (toggleKey == null) return;
        while (toggleKey.method_1436()) {
            SkyblockEnhancementsConfig.enableFullbright = !SkyblockEnhancementsConfig.enableFullbright;
            MidnightConfig.write(SkyblockEnhancements.MOD_ID);

            if (client.field_1724 != null) {
                boolean on = SkyblockEnhancementsConfig.enableFullbright;
                client.field_1724.method_7353(
                        class_2561.method_43470("Fullbright " + (on ? "§aenabled" : "§cdisabled")), true);
            }
        }
    }
}