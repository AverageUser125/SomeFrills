package com.github.kd_gaming1.skyblockenhancements.feature.pricing;

import com.github.kd_gaming1.skyblockenhancements.feature.KeybindCategories;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Registers and tracks the two price-modifier keybinds:
 * <ul>
 *   <li><b>Full Stack</b> (default Left Control) — multiplies displayed prices by the
 *       item's logical stack size (max stack for inventory items, order amount for Bazaar).</li>
 *   <li><b>Current Amount</b> (default Left Shift) — multiplies displayed prices by the
 *       hovered item's logical stack size (same as Full Stack for Bazaar UI).</li>
 * </ul>
 */
public final class PriceTooltipKeybinds {

    private static class_304 fullStackKey;
    private static class_304 currentAmountKey;

    private static final class_304.class_11900 CATEGORY = KeybindCategories.GENERAL;

    private PriceTooltipKeybinds() {}

    /** Registers the two modifier keybinds. Call once during mod init. */
    public static void init() {
        fullStackKey = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.skyblock_enhancements.full_stack_price",
                        GLFW.GLFW_KEY_LEFT_CONTROL,
                        CATEGORY));

        currentAmountKey = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.skyblock_enhancements.current_amount_price",
                        GLFW.GLFW_KEY_LEFT_SHIFT,
                        CATEGORY));
    }

    /** Returns {@code true} while the Full Stack modifier key is physically held. */
    public static boolean isFullStackHeld() {
        return isKeyPhysicallyDown(fullStackKey);
    }

    /** Returns {@code true} while the Current Amount modifier key is physically held. */
    public static boolean isCurrentAmountHeld() {
        return isKeyPhysicallyDown(currentAmountKey);
    }

    /**
     * Returns the translated display name of the Full Stack key, or empty if unbound.
     * Useful for hint lines in tooltips.
     */
    public static String getFullStackKeyName() {
        if (fullStackKey == null) return "";
        return fullStackKey.method_16007().getString();
    }

    /**
     * Returns the translated display name of the Current Amount key, or empty if unbound.
     * Useful for hint lines in tooltips.
     */
    public static String getCurrentAmountKeyName() {
        if (currentAmountKey == null) return "";
        return currentAmountKey.method_16007().getString();
    }

    // ── GLFW polling ───────────────────────────────────────────────────────────

    /**
     * Queries GLFW directly to determine whether a key is physically pressed.
     * This bypasses Minecraft's {@link class_304#method_1424()} / {@code isDown()}
     * logic which can be stale or reset while GUI screens are open.
     *
     * <p>Uses reflection to read {@code KeyMapping.key} (protected, no getter)
     * so rebound keys are detected correctly.
     */
    private static boolean isKeyPhysicallyDown(class_304 mapping) {
        if (mapping == null) return false;

        class_3675.class_306 key = getBoundKey(mapping);
        if (key == null || key.method_1442() != class_3675.class_307.field_1668) return false;

        int keyCode = key.method_1444();
        if (keyCode == class_3675.field_16237.method_1444()) return false;

        class_310 mc = class_310.method_1551();
        class_1041 window = mc.method_22683();

        return class_3675.method_15987(window, keyCode);
    }

    /** Reads the current {@code KeyMapping.key} via Fabric API. */
    private static class_3675.class_306 getBoundKey(class_304 mapping) {
        return KeyBindingHelper.getBoundKeyOf(mapping);
    }
}
