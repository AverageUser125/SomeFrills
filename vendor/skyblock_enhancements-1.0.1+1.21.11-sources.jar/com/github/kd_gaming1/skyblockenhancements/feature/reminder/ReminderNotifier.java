package com.github.kd_gaming1.skyblockenhancements.feature.reminder;

import com.github.kd_gaming1.skyblockenhancements.config.ModSettings;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_6880;

/**
 * Handles all user-facing notification output for reminders:
 * chat messages, screen titles, and configurable sounds.
 *
 * <p>Extracted from {@link ReminderManager} so the manager can focus on
 * scheduling and state, while this class deals with Minecraft-side effects.
 */
public final class ReminderNotifier {

    private final ModSettings settings;

    public ReminderNotifier(ModSettings settings) {
        this.settings = settings;
    }

    public void fire(class_310 client, Reminder reminder, long now) {
        if (client.field_1724 == null) {
            return;
        }

        long lateMs = reminder.getLateMs(now);

        switch (reminder.outputType) {
            case CHAT, CHAT_AND_TITLE, CHAT_AND_SOUND, ALL -> sendChatMessage(client, reminder, lateMs);
            default -> {}
        }
        switch (reminder.outputType) {
            case TITLE_BOX, CHAT_AND_TITLE, TITLE_AND_SOUND, ALL -> sendTitle(client, reminder);
            default -> {}
        }
        switch (reminder.outputType) {
            case SOUND_ONLY, CHAT_AND_SOUND, TITLE_AND_SOUND, ALL -> playReminderSound(client);
            default -> {}
        }
    }

    private void sendChatMessage(class_310 client, Reminder reminder, long lateMs) {
        class_5250 msg =
                class_2561.method_43470("⏰ ")
                        .method_27692(class_124.field_1065)
                        .method_10852(class_2561.method_43470(reminder.message).method_27692(class_124.field_1068));

        if (lateMs > 5000) {
            msg.method_10852(
                    class_2561.method_43470(" (fired " + ReminderManager.formatMs(lateMs) + " late)")
                            .method_27692(class_124.field_1063));
        }

        client.field_1705.method_1743().method_1812(msg);
    }

    private void sendTitle(class_310 client, Reminder reminder) {
        client.field_1705.method_34004(class_2561.method_43470(reminder.message).method_27692(class_124.field_1054));
        client.field_1705.method_34002(class_2561.method_43470("Reminder").method_27692(class_124.field_1065));
    }

    private void playReminderSound(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null || !settings.enableReminderSound()) {
            return;
        }

        Object candidate = switch (settings.reminderSound()) {
            case BELL -> class_3417.field_14793;
            case PLING -> class_3417.field_14622;
            case CHIME -> class_3417.field_14725;
            case LEVEL_UP -> class_3417.field_14709;
            case EXPERIENCE -> class_3417.field_14627;
            case HARP -> class_3417.field_15114;
            case SUCCESS -> class_3417.field_15195;
            case UI -> class_3417.field_14561;
        };

        class_3414 soundEvent =
                candidate instanceof class_6880<?> h ? (class_3414) h.comp_349() : (class_3414) candidate;

        client.field_1687.method_8396(
                client.field_1724,
                client.field_1724.method_24515(),
                soundEvent,
                class_3419.field_15248,
                (float) settings.reminderSoundVolume(),
                (float) settings.reminderSoundPitch());
    }
}
