package com.github.kd_gaming1.skyblockenhancements.feature.katreminder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;

/**
 * Coordinates Kat pet-upgrade reminders: parses NPC dialog, persists reminders,
 * and fires chat notifications when upgrades are ready.
 *
 * <p>Delegation:
 * <ul>
 *   <li>Dialog parsing → {@link KatDialogParser}</li>
 *   <li>File persistence → {@link KatReminderStore}</li>
 * </ul>
 */
public class KatUpgradeReminderManager {

    private final BooleanSupplier inHubSupplier;
    private final KatReminderStore store;

    private final List<KatUpgradeReminder> activeReminders = new ArrayList<>();

    private KatDialogParser.UpgradeStart pendingUpgrade;
    private long lastSecondUpdateMs;
    private boolean pendingBrokenFileNotice;

    public KatUpgradeReminderManager(java.nio.file.Path storagePath, BooleanSupplier inHubSupplier) {
        this.inHubSupplier = inHubSupplier;
        this.store = new KatReminderStore(storagePath);
    }

    // ── Persistence ──────────────────────────────────────────────────────────────

    public void load() {
        KatReminderStore.LoadResult result = store.load();
        activeReminders.clear();
        activeReminders.addAll(result.reminders());
        pendingBrokenFileNotice = result.wasRecoveredFromBrokenFile();
    }

    public void save() {
        store.save(activeReminders);
    }

    public List<KatReminderStore.KatReminderData> getActiveReminders() {
        List<KatReminderStore.KatReminderData> reminders = new ArrayList<>();
        for (KatUpgradeReminder r : activeReminders) {
            KatReminderStore.KatReminderData d = new KatReminderStore.KatReminderData();
            d.pet = r.pet();
            d.rarity = r.rarity();
            d.readyAtMs = r.readyAtMs();
            reminders.add(d);
        }
        return reminders;
    }

    public int removeAllReminders() {
        int count = activeReminders.size();
        activeReminders.clear();
        reset();
        save();
        return count;
    }

    // ── Dialog handling ──────────────────────────────────────────────────────────

    public void onNpcDialog(String npcName, String dialog) {
        if (!SkyblockEnhancementsConfig.setKatReminderForPetUpgrades) return;
        if (!"Kat".equals(npcName)) return;

        KatDialogParser.SpecialDialog special = KatDialogParser.detectSpecialDialog(dialog);
        if (special != KatDialogParser.SpecialDialog.NONE) {
            handleSpecialDialog(special);
            return;
        }

        KatDialogParser.UpgradeStart upgrade = KatDialogParser.tryParseUpgradeStart(dialog);
        if (upgrade != null) {
            pendingUpgrade = upgrade;
            return;
        }

        KatDialogParser.ReminderStart reminder = KatDialogParser.tryParseReminderStart(dialog);
        if (reminder != null) {
            pendingUpgrade = new KatDialogParser.UpgradeStart(reminder.pet(), "COMMON");
            return;
        }

        tryCreateReminderFromDuration(dialog);
    }

    private void handleSpecialDialog(KatDialogParser.SpecialDialog special) {
        switch (special) {
            case FLOWER -> reduceMostRecentReminder(KatDialogParser.FLOWER_REDUCTION_MS);
            case BOUQUET -> reduceMostRecentReminder(KatDialogParser.BOUQUET_REDUCTION_MS);
            case RESET -> reset();
            default -> { /* no-op */ }
        }
    }

    private void tryCreateReminderFromDuration(String dialog) {
        if (pendingUpgrade == null) return;

        long durationMs = KatDialogParser.parseDuration(dialog);
        if (durationMs <= 0) return;

        activeReminders.add(new KatUpgradeReminder(
                pendingUpgrade.pet(), pendingUpgrade.rarity(),
                System.currentTimeMillis() + durationMs));
        reset();
        save();
    }

    private void reduceMostRecentReminder(long reductionMs) {
        if (activeReminders.isEmpty()) return;

        int index = activeReminders.size() - 1;
        KatUpgradeReminder r = activeReminders.get(index);
        long reducedReadyAt = Math.max(System.currentTimeMillis(), r.readyAtMs() - reductionMs);

        activeReminders.set(index, new KatUpgradeReminder(r.pet(), r.rarity(), reducedReadyAt));
        save();
    }

    private void reset() {
        pendingUpgrade = null;
    }

    // ── Tick / firing ────────────────────────────────────────────────────────────

    public void onClientTick(class_310 client) {
        if (pendingBrokenFileNotice && client.field_1724 != null) {
            sendBrokenFileMessage(client);
            pendingBrokenFileNotice = false;
        }

        if (!SkyblockEnhancementsConfig.setKatReminderForPetUpgrades) return;
        if (client.field_1724 == null) return;

        long now = System.currentTimeMillis();
        if (lastSecondUpdateMs == 0) {
            lastSecondUpdateMs = now;
            return;
        }
        if (now - lastSecondUpdateMs < 1000) return;
        lastSecondUpdateMs = now;

        boolean changed = false;
        Iterator<KatUpgradeReminder> it = activeReminders.iterator();
        while (it.hasNext()) {
            KatUpgradeReminder r = it.next();
            if (now < r.readyAtMs()) continue;
            if (!inHubSupplier.getAsBoolean()) continue;

            sendReadyMessage(client, r);
            it.remove();
            changed = true;
        }

        if (changed) save();
    }

    // ── Chat messages ────────────────────────────────────────────────────────────

    private void sendBrokenFileMessage(class_310 client) {
        class_5250 message = class_2561.method_43470("[KatReminder]").method_27692(class_124.field_1075)
                .method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("Your ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("KatReminder File ").method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470("was ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470("broken").method_27692(class_124.field_1061))
                .method_10852(class_2561.method_43470(". We've created a fresh one for you and backed up your old file.").method_27692(class_124.field_1054));

        assert client.field_1724 != null;
        client.field_1724.method_7353(message, false);
    }

    private void sendReadyMessage(class_310 client, KatUpgradeReminder reminder) {
        class_124 rarityColor = mapRarityColor(reminder.rarity());
        class_5250 message = class_2561.method_43470("Your ")
                .method_10852(class_2561.method_43470(reminder.pet()).method_27692(rarityColor))
                .method_10852(class_2561.method_43470(" is Ready to pick up! "))
                .method_10852(class_2561.method_43470("[call]").method_27694(style -> style
                        .method_10977(class_124.field_1075)
                        .method_10958(new class_2558.class_10609("/call kat"))));

        assert client.field_1724 != null;
        client.field_1724.method_7353(message, false);
    }

    private class_124 mapRarityColor(String rarity) {
        return switch (rarity) {
            case "UNCOMMON" -> class_124.field_1060;
            case "RARE" -> class_124.field_1078;
            case "EPIC" -> class_124.field_1064;
            case "LEGENDARY" -> class_124.field_1065;
            case "MYTHIC" -> class_124.field_1076;
            default -> class_124.field_1068;
        };
    }
}
