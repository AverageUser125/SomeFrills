package com.github.kd_gaming1.skyblockenhancements.feature.missingenchants;

import com.github.kd_gaming1.skyblockenhancements.compat.rrv.RrvCompat;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.util.HypixelLocationState;
import com.github.kd_gaming1.skyblockenhancements.util.JsonLookup;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.nio.file.Path;
import java.util.*;

// import static com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements.LOGGER;
import static com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements.MOD_ID;

/**
 * Appends a "Missing enchantments" section to the tooltip of any enchantable Skyblock item.
 *
 * <p>For each hovered item is the feature:
 * <ol>
 *   <li>Reads the item type and current enchants from the tooltip / NBT via {@link HoveredEnchantReader}.</li>
 *   <li>Compares the current enchants against the full list for that item type (loaded from
 *       {@code enchants.json}) via {@link MissingEnchantResolver}, respecting mutually exclusive
 *       enchant pools so that only one enchant per pool is ever counted as missing.</li>
 *   <li>Injects the resulting list into the tooltip, either as a compact count (default) or a
 *       full expanded list (while Shift is held), positioned just after the existing enchant lines.</li>
 * </ol>
 *
 * <p><b>Caching:</b> {@code onTooltip} is called every frame for the hovered item, so three layers
 * of caching keep it cheap:
 * <ul>
 *   <li><b>Identity cache</b> — if the same {@link class_1799} object is seen again, skip all NBT
 *       parsing and jump straight to inserting (or rebuilding if Shift changed).</li>
 *   <li><b>Item cache</b> — if the item type and enchant set are unchanged, skip the resolver.</li>
 *   <li><b>Render cache</b> — if neither the missing list nor the expanded state changed, reuse
 *       the already-built {@link class_2561} list.</li>
 * </ul>
 * Items without enchants (e.g. plain tools, consumables) are ignored and do <em>not</em> update
 * the identity cache, so mousing back to a previously analysed enchanted item still hits the fast path.
 */
public final class MissingEnchants {

    private static final Path DATA_ROOT = FabricLoader.getInstance().getConfigDir()
            .resolve(MOD_ID).resolve("data");
    private static final Path ENCHANTS_JSON_PATH = DATA_ROOT.resolve("constants/enchants.json");

    private static final int MAX_LINE_WIDTH = 200;
    private static final String LIST_PREFIX = "› ";

    private static final HoveredEnchantReader ENCHANT_READER = new HoveredEnchantReader();
    private static final MissingEnchantResolver MISSING_RESOLVER =
            new MissingEnchantResolver(new JsonLookup(), ENCHANTS_JSON_PATH);

    private static final Set<String> ROMAN_NUMERALS = Set.of(
            "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"
    );

    // --- Item cache: what was the last enchantable item we resolved? ---
    private static String lastItemType;
    private static Map<String, Integer> lastCurrentEnchants = Map.of();
    private static List<String> lastMissingNamesSorted = List.of();
    private static List<String> lastNotMaxedNamesSorted = List.of();

    // --- Insert-index cache: valid while lastItemType / lastCurrentEnchants are unchanged ---
    private static List<String> lastNormalizedTokens = null;
    private static int lastInsertIndex = -1;

    // --- Render cache: the built Component list, valid while the missing list and expanded state are unchanged ---
    private static List<String> lastRenderedForMissing = List.of();
    private static boolean lastRenderedExpanded;
    private static List<class_2561> lastRenderBlock = List.of();

    // --- Identity cache: the last ItemStack object we successfully analysed ---
    private static class_1799 lastStack = class_1799.field_8037;

    public static void init() {
        ItemTooltipCallback.EVENT.register(MissingEnchants::onTooltip);
    }

    private static void onTooltip(class_1799 stack, class_1792.class_9635 ctx, class_1836 flag, List<class_2561> tooltipLines) {
        if (!SkyblockEnhancementsConfig.showMissingEnchantments) return;
        if (!HypixelLocationState.isOnHypixel()) return;
        // Skip items hovered in the RRV item-list overlay
        if (RrvCompat.isOverlayTooltip()) return;

        boolean expanded = !SkyblockEnhancementsConfig.showWhenPressingShift || class_310.method_1551().method_74187();

        // Identity fast path: the same ItemStack object means the item hasn't changed.
        if (!lastStack.method_7960() && class_1799.method_31577(stack, lastStack)) {
            if (expanded == lastRenderedExpanded) {
                // Nothing changed — just re-insert the cached block.
                if (!lastRenderBlock.isEmpty()) insertBlock(tooltipLines, lastRenderBlock, lastCurrentEnchants);
                return;
            }
            // Only Shift changed — rebuild the block without reparsing NBT.
            if (!lastMissingNamesSorted.isEmpty() || !lastNotMaxedNamesSorted.isEmpty()) {
                // LOGGER.wiki("Rebuilding tooltip block (expanded={})", expanded);
                lastRenderBlock = expanded
                        ? buildExpandedBlock(lastMissingNamesSorted, lastNotMaxedNamesSorted)
                        : buildCollapsedBlock(lastMissingNamesSorted.size(), lastNotMaxedNamesSorted.size());
                lastRenderedExpanded = expanded;
                lastRenderedForMissing = lastMissingNamesSorted;
                insertBlock(tooltipLines, lastRenderBlock, lastCurrentEnchants);
            }
            return;
        }

        // New stack — parse it. If the item isn't enchantable, we return without updating the lastStack
        // so that mousing back to the previous enchanted item still hits the identity fast path above.
        HoveredEnchantReader.HoveredItemInfo hovered = ENCHANT_READER.readHoveredItemInfo(stack, tooltipLines);
        if (hovered == null) return;

        if (!isSameItem(hovered)) {
            // LOGGER.wiki("Recomputing missing enchants for {} with enchants {}", hovered.itemType(), hovered.currentEnchants());
            lastMissingNamesSorted = MISSING_RESOLVER.findMissingEnchantNames(
                    hovered.itemType(), hovered.currentEnchants().keySet());

            if (SkyblockEnhancementsConfig.showNotMaxedEnchantments) {
                lastNotMaxedNamesSorted = MISSING_RESOLVER.findNotMaxedEnchantNames(
                        hovered.itemType(), hovered.currentEnchants());
            } else {
                lastNotMaxedNamesSorted = List.of();
            }

            lastItemType = hovered.itemType();
            lastCurrentEnchants = hovered.currentEnchants();
            lastRenderedForMissing = List.of(); // invalidate render cache for the new item
            lastNormalizedTokens = null;        // invalidate token cache
            lastInsertIndex = -1;               // invalidate index cache
        }

        // Commit the identity cache only after confirming this is an enchantable item.
        lastStack = stack.method_7972();

        if (lastMissingNamesSorted.isEmpty() && lastNotMaxedNamesSorted.isEmpty()) return;

        // Rebuild the rendered Component list only when content or view mode changed.
        if (!Objects.equals(lastMissingNamesSorted, lastRenderedForMissing) || expanded != lastRenderedExpanded) {
            // LOGGER.wiki("Rebuilding tooltip block (expanded={})", expanded);
            lastRenderBlock = expanded
                    ? buildExpandedBlock(lastMissingNamesSorted, lastNotMaxedNamesSorted)
                    : buildCollapsedBlock(lastMissingNamesSorted.size(), lastNotMaxedNamesSorted.size());
            lastRenderedForMissing = lastMissingNamesSorted;
            lastRenderedExpanded = expanded;
        }

        insertBlock(tooltipLines, lastRenderBlock, lastCurrentEnchants);
    }

    private static boolean isSameItem(HoveredEnchantReader.HoveredItemInfo hovered) {
        return Objects.equals(hovered.itemType(), lastItemType)
                && hovered.currentEnchants().equals(lastCurrentEnchants);
    }

    private static List<class_2561> buildCollapsedBlock(int missingCount, int notMaxedCount) {
        List<class_2561> out = new ArrayList<>();
        out.add(class_2561.method_43470(""));
        if (missingCount > 0) {
            out.add(class_2561.method_43470("◆ Missing enchantments: " + missingCount + " (hold Shift)")
                    .method_27692(class_124.field_1062));
        }
        if (SkyblockEnhancementsConfig.showNotMaxedEnchantments && notMaxedCount > 0) {
            out.add(class_2561.method_43470("◆ Not maxed: " + notMaxedCount + " (hold Shift)")
                    .method_27692(class_124.field_1065));
        }
        return out;
    }

    private static List<class_2561> buildExpandedBlock(List<String> missingNamesSorted, List<String> notMaxedNamesSorted) {
        class_310 mc = class_310.method_1551();

        List<class_2561> out = new ArrayList<>();

        if (!missingNamesSorted.isEmpty()) {
            out.add(class_2561.method_43470(""));
            out.add(class_2561.method_43470("◆ Missing enchantments:")
                    .method_27695(class_124.field_1075, class_124.field_1056));
            appendWrappedNames(mc, out, missingNamesSorted, class_124.field_1080);
        }

        if (SkyblockEnhancementsConfig.showNotMaxedEnchantments && !notMaxedNamesSorted.isEmpty()) {
            out.add(class_2561.method_43470(""));
            out.add(class_2561.method_43470("◆ Not maxed enchantments:")
                    .method_27695(class_124.field_1065, class_124.field_1056));
            appendWrappedNames(mc, out, notMaxedNamesSorted, class_124.field_1054);
        }

        return out;
    }

    /** Word-wraps {@code names} onto lines fitting within {@link #MAX_LINE_WIDTH} pixels and appends them to {@code out}. */
    private static void appendWrappedNames(class_310 mc, List<class_2561> out, List<String> names, class_124 color) {
        int commaWidth = mc.field_1772.method_1727(", ");
        int prefixWidth = mc.field_1772.method_1727(LIST_PREFIX);
        int maxWidth = MAX_LINE_WIDTH - prefixWidth;

        List<String> currentLine = new ArrayList<>();
        int currentWidth = 0;

        for (String name : names) {
            int nameWidth = mc.field_1772.method_1727(name);
            int addWidth = currentLine.isEmpty() ? nameWidth : (commaWidth + nameWidth);

            if (!currentLine.isEmpty() && currentWidth + addWidth > maxWidth) {
                out.add(class_2561.method_43470(LIST_PREFIX + String.join(", ", currentLine))
                        .method_27692(color));
                currentLine.clear();
                currentWidth = 0;
                addWidth = nameWidth;
            }

            currentLine.add(name);
            currentWidth += addWidth;
        }

        if (!currentLine.isEmpty()) {
            out.add(class_2561.method_43470(LIST_PREFIX + String.join(", ", currentLine))
                    .method_27692(color));
        }
    }

    private static void insertBlock(List<class_2561> tooltipLines, List<class_2561> block, Map<String, Integer> currentEnchants) {
        tooltipLines.addAll(findInsertIndex(tooltipLines, currentEnchants.keySet()), block);
    }

    private static int findInsertIndex(List<class_2561> tooltipLines, Set<String> enchantKeys) {
        if (lastInsertIndex >= 0 && lastInsertIndex <= tooltipLines.size()) return lastInsertIndex;

        List<String> tokens = lastNormalizedTokens;
        if (tokens == null) {
            tokens = new ArrayList<>(enchantKeys.size());
            for (String key : enchantKeys) {
                String t = normalizeEnchantToken(key);
                if (!t.isEmpty()) tokens.add(t);
            }
            lastNormalizedTokens = tokens;
        }

        int lastRomanLine   = -1;
        int lastEnchantLine = -1;

        for (int i = 0; i < tooltipLines.size(); i++) {
            String raw  = tooltipLines.get(i).getString();
            String line = raw.toLowerCase(Locale.ROOT);

            String trimmed = raw.stripTrailing();
            int spaceIdx = trimmed.lastIndexOf(' ');
            if (spaceIdx >= 0 && ROMAN_NUMERALS.contains(trimmed.substring(spaceIdx + 1))) {
                lastRomanLine = i;
                continue;
            }

            boolean isEnchantLine = line.contains("enchant");
            if (!isEnchantLine) {
                for (String token : tokens) {
                    if (line.contains(token)) {
                        isEnchantLine = true;
                        break;
                    }
                }
            }
            if (isEnchantLine) {
                lastEnchantLine = i;
            }
        }

        int anchor = lastRomanLine >= 0 ? lastRomanLine
                : lastEnchantLine >= 0 ? lastEnchantLine
                  : tooltipLines.size() - 1;

        int base = Math.min(anchor + 1, tooltipLines.size());

        for (int i = base; i < Math.min(tooltipLines.size(), base + 8); i++) {
            if (tooltipLines.get(i).getString().isEmpty()) {
                lastInsertIndex = i;
                return i;
            }
        }
        lastInsertIndex = base;
        return base;
    }

    private static String normalizeEnchantToken(String enchantId) {
        return enchantId.replace("ultimate_", "")
                .replace('_', ' ')
                .toLowerCase(Locale.ROOT);
    }

    /** Clears all caches — called when the repo data is reloaded from disk. */
    public static void invalidateRepoDataCaches() {
        MISSING_RESOLVER.clearCaches();

        lastItemType = null;
        lastCurrentEnchants = Map.of();
        lastMissingNamesSorted = List.of();
        lastNotMaxedNamesSorted = List.of();

        lastRenderedForMissing = List.of();
        lastRenderedExpanded = false;
        lastRenderBlock = List.of();

        lastNormalizedTokens = null;
        lastInsertIndex = -1;
    }
}