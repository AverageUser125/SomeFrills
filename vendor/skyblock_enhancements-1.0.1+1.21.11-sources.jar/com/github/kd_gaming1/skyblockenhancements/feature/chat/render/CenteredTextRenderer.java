package com.github.kd_gaming1.skyblockenhancements.feature.chat.render;

import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import net.minecraft.class_9848;

/** Draws a chat line centered horizontally in the chat area. */
public final class CenteredTextRenderer implements CustomChatRenderer {

    public static final CenteredTextRenderer INSTANCE = new CenteredTextRenderer();

    private CenteredTextRenderer() {}

    @Override
    public void render(
            class_332 graphics,
            class_327 font,
            class_5481 text,
            int lineX,
            int textY,
            int lineWidth,
            float alpha) {
        int x = lineX + (lineWidth - font.method_30880(text)) / 2;
        int color = class_9848.method_61330(class_9848.method_61326(alpha), 0xFFFFFF);
        graphics.method_51430(font, text, x, textY, color, true);
    }

    @Override
    public HitTest hitTest(class_327 font, class_5481 text, int lineX, int lineWidth) {
        return HitTest.shifted((lineWidth - font.method_30880(text)) / 2);
    }
}