package com.github.kd_gaming1.skyblockenhancements.feature.chat.render;

import com.github.kd_gaming1.skyblockenhancements.access.SBEChatAccess;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.ChatLineTracker;
import java.util.function.Consumer;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_5481;
import net.minecraft.class_7591;
import net.minecraft.class_9848;
import org.joml.Matrix3x2f;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

/**
 * Intercepts vanilla chat rendering to dispatch to {@link CustomChatRenderer}s and to draw the
 * selection outline around the currently targeted message.
 *
 * <p>All parent-message and renderer lookups are O(1) via {@link ChatLineTracker}; the proxy
 * itself does no searching. Line spacing is sampled once per render pass to avoid repeated
 * option reads in the per-line hot path.
 */
public class ChatGraphicsAccessProxy implements class_338.class_12233 {

    private static final float OUTLINE_ALPHA_FACTOR = 0.35f;
    private static final int OUTLINE_LEFT_INSET = -4;
    private static final int OUTLINE_RIGHT_INSET = 8;
    private static final int OFFSCREEN_Y = -10000;

    private class_338.class_12233 delegate;
    private final SBEChatAccess chatAccess;
    private @Nullable class_332 graphics;
    private class_327 font;

    // Sampled once per frame — chat line-spacing doesn't change during a render pass.
    private int entryHeight;
    private int entryBottomToMessageY;

    // Per-line outline accumulation; reset between messages by handleMessage.
    private boolean outlineActive;
    private int outlineMinY = Integer.MAX_VALUE;
    private int outlineMaxY = Integer.MIN_VALUE;
    private float outlineOpacity;

    public ChatGraphicsAccessProxy(
            class_338.class_12233 delegate,
            SBEChatAccess chatAccess,
            @Nullable class_332 graphics,
            class_327 font) {
        this.chatAccess = chatAccess;
        prepareForFrame(delegate, graphics, font);
    }

    /**
     * Resets mutable state and updates fields that may change between render passes.
     * Call once before each chat render when reusing a proxy instance.
     */
    public void prepareForFrame(class_338.class_12233 delegate,
                                 @Nullable class_332 graphics, class_327 font) {
        this.delegate = delegate;
        this.graphics = graphics;
        this.font = font;
        this.outlineActive = false;
        this.outlineMinY = Integer.MAX_VALUE;
        this.outlineMaxY = Integer.MIN_VALUE;
        this.outlineOpacity = 0f;

        double lineSpacing = class_310.method_1551().field_1690.method_42546().method_41753();
        this.entryHeight = (int) (9.0 * (lineSpacing + 1.0));
        this.entryBottomToMessageY = (int) Math.round(8.0 * (lineSpacing + 1.0) - 4.0 * lineSpacing);
    }

    @Override
    public void method_75811(@NonNull Consumer<Matrix3x2f> updater) {
        delegate.method_75811(updater);
    }

    @Override
    public void method_75809(int x0, int y0, int x1, int y1, int color) {
        delegate.method_75809(x0, y0, x1, y1, color);
    }

    @Override
    public boolean method_75807(int textTop, float opacity, @NonNull class_5481 message) {
        ChatLineTracker tracker = chatAccess.sbe$getLineTracker();
        CustomChatRenderer renderer = tracker.rendererFor(message);

        boolean hovered = renderer == null
                ? delegate.method_75807(textTop, opacity, message)
                : dispatchCustom(renderer, message, textTop, opacity);

        class_303 selected = tracker.getSelectedMessage();
        if (selected != null) {
            class_303 parent = tracker.parentFor(message);
            int entryBottom = textTop + entryBottomToMessageY;
            int entryTop = entryBottom - entryHeight;
            maybeAccumulateOutline(parent, selected, opacity, entryTop, entryBottom);
        }
        return hovered;
    }

    @Override
    public void method_75808(int x0, int y0, int x1, int y1, float opacity, @NonNull class_7591 tag) {
        // Intentionally empty: the coloured indicator bar is suppressed for all messages.
    }

    @Override
    public void method_75810(
            int left, int bottom, boolean forceVisible,
            @NonNull class_7591 tag, class_7591.@NonNull class_7592 icon) {
        delegate.method_75810(left, bottom, forceVisible, tag, icon);
    }

    /**
     * Draws the accumulated outline (one merged rectangle spanning every visible line of the
     * selected message). Call once after the render pass completes.
     */
    public void finishOutline() {
        if (graphics == null || !outlineActive) return;

        int scaledWidth = chatAccess.sbe$getScaledWidth();
        int alpha = class_9848.method_61326(outlineOpacity * OUTLINE_ALPHA_FACTOR);
        int color = class_9848.method_61324(alpha, 0xFF, 0xFF, 0xFF);

        int x0 = OUTLINE_LEFT_INSET;
        int x1 = scaledWidth + OUTLINE_RIGHT_INSET;
        int y0 = outlineMinY;
        int y1 = outlineMaxY;

        graphics.method_25294(x0, y0, x1, y0 + 1, color);
        graphics.method_25294(x0, y1 - 1, x1, y1, color);
        graphics.method_25294(x0, y0, x0 + 1, y1, color);
        graphics.method_25294(x1 - 1, y0, x1, y1, color);

        outlineActive = false;
        outlineMinY = Integer.MAX_VALUE;
        outlineMaxY = Integer.MIN_VALUE;
    }

    // ---------------------------------------------------------------------
    // Internal
    // ---------------------------------------------------------------------

    private boolean dispatchCustom(
            CustomChatRenderer renderer, class_5481 message, int textTop, float opacity) {

        int scaledWidth = chatAccess.sbe$getScaledWidth();
        if (graphics != null) {
            renderer.render(graphics, font, message, 0, textTop, scaledWidth, opacity);
        }

        CustomChatRenderer.HitTest hit = renderer.hitTest(font, message, 0, scaledWidth);
        if (!hit.isEnabled()) return false;

        return hiddenHitTest(message, textTop, opacity, hit.offsetX());
    }

    /**
     * Runs the vanilla hit-test with the visible delegate draw shifted far off-screen (text
     * was already drawn by the custom renderer). If {@code offsetX} is non-zero the hit-test
     * is translated to match the custom draw's actual position.
     */
    private boolean hiddenHitTest(class_5481 message, int textTop, float opacity, int offsetX) {
        if (offsetX != 0) {
            delegate.method_75811(pose -> pose.translate(offsetX, 0));
        }
        if (graphics != null) {
            graphics.method_51448().pushMatrix();
            graphics.method_51448().translate(0, OFFSCREEN_Y);
        }
        try {
            return delegate.method_75807(textTop, opacity, message);
        } finally {
            if (graphics != null) graphics.method_51448().popMatrix();
            if (offsetX != 0) {
                int reverse = -offsetX;
                delegate.method_75811(pose -> pose.translate(reverse, 0));
            }
        }
    }

    private void maybeAccumulateOutline(
            @Nullable class_303 parent, @Nullable class_303 selected,
            float opacity, int entryTop, int entryBottom) {
        if (selected == null || parent != selected) return;
        outlineActive = true;
        outlineOpacity = opacity;
        outlineMinY = Math.min(outlineMinY, entryTop);
        outlineMaxY = Math.max(outlineMaxY, entryBottom);
    }
}