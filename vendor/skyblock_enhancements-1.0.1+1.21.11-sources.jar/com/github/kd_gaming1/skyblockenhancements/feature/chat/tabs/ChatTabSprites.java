package com.github.kd_gaming1.skyblockenhancements.feature.chat.tabs;

import static com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements.MOD_ID;

import net.minecraft.class_2960;
import net.minecraft.class_8666;

/** Resource-pack-retexturable sprite sets for chat tab buttons. */
public final class ChatTabSprites {

    public static final class_8666 INACTIVE = new class_8666(
            class_2960.method_60655(MOD_ID, "chat/button"),
            class_2960.method_60655(MOD_ID, "chat/button_disabled"),
            class_2960.method_60655(MOD_ID, "chat/button_highlighted"));

    public static final class_8666 ACTIVE = new class_8666(
            class_2960.method_60655(MOD_ID, "chat/button_toggled"),
            class_2960.method_60655(MOD_ID, "chat/button_disabled"),
            class_2960.method_60655(MOD_ID, "chat/button_toggled_highlighted"));

    private ChatTabSprites() {}
}