package com.github.kd_gaming1.skyblockenhancements.feature.chat.menu;

import com.github.kd_gaming1.skyblockenhancements.access.SBEChatAccess;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.render.ChatTextHelper;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.class_5251;
import org.jspecify.annotations.Nullable;

/**
 * Maps cursor positions to messages and converts {@link class_2561}s into copyable strings
 * (plain, body-only, or &-code annotated).
 *
 * <p>Resolution uses the line-to-message mapping maintained by
 * {@link com.github.kd_gaming1.skyblockenhancements.feature.chat.ChatLineTracker}; there is
 * no fallback path because the tracker is updated by the same injections that populate
 * {@code trimmedMessages}, so any resolvable line is guaranteed to have a mapping.
 */
public final class ChatMessageResolver {

    /** Chat area bottom margin (pixels from screen bottom to the bottom of the newest line). */
    private static final int CHAT_BOTTOM_MARGIN = 40;

    private static final Int2ObjectMap<class_124> FORMAT_BY_RGB = buildColorLookup();

    private ChatMessageResolver() {}

    /** @return the message under the given screen coordinates, or {@code null} if none. */
    public static @Nullable class_303 resolve(double screenY) {
        class_310 mc = class_310.method_1551();
        class_338 chat = mc.field_1705.method_1743();
        SBEChatAccess access = (SBEChatAccess) chat;

        List<class_303.class_7590> trimmed = access.sbe$getTrimmedMessages();
        if (trimmed.isEmpty()) return null;

        double scale = mc.field_1690.method_42554().method_41753();
        double lineSpacing = mc.field_1690.method_42546().method_41753();
        int entryHeight = (int) (9.0 * (lineSpacing + 1.0));
        if (entryHeight <= 0) return null;

        int screenHeight = mc.method_22683().method_4502();
        double localY = (screenY - screenHeight + CHAT_BOTTOM_MARGIN) / scale;
        int lineIndex = (int) Math.floor(-localY / entryHeight);
        if (lineIndex < 0 || lineIndex >= chat.method_1813()) return null;

        int trimmedIndex = lineIndex + access.sbe$getChatScrollbarPos();
        if (trimmedIndex < 0 || trimmedIndex >= trimmed.size()) return null;

        return access.sbe$getLineTracker().parentFor(trimmed.get(trimmedIndex));
    }

    // ---------------------------------------------------------------------
    // Text extraction
    // ---------------------------------------------------------------------

    /** Plain text with all formatting and compact suffixes stripped. */
    public static String toRawText(class_2561 content) {
        String plain = class_124.method_539(content.getString());
        return ChatTextHelper.stripCompactSuffix(plain);
    }

    /**
     * Message body only — everything after the first {@code ": "} separator. Falls back to
     * the full plain text if no sender prefix is present.
     */
    public static String toMessageBody(class_2561 content) {
        String plain = toRawText(content);
        int sep = plain.indexOf(": ");
        return sep >= 0 ? plain.substring(sep + 2) : plain;
    }

    /** Text with {@code &}-prefixed color/format codes preserved. */
    public static String toFormattedText(class_2561 content) {
        StringBuilder sb = new StringBuilder();
        class_2583[] previous = {class_2583.field_24360};

        content.method_30937().accept((index, style, codePoint) -> {
            if (!style.equals(previous[0])) {
                appendStylePrefix(style, sb);
                previous[0] = style;
            }
            sb.appendCodePoint(codePoint);
            return true;
        });
        return ChatTextHelper.stripCompactSuffix(sb.toString());
    }

    // ---------------------------------------------------------------------
    // Internal
    // ---------------------------------------------------------------------

    private static void appendStylePrefix(class_2583 style, StringBuilder sb) {
        sb.append("&r");

        class_5251 color = style.method_10973();
        if (color != null) {
            class_124 fmt = FORMAT_BY_RGB.get(color.method_27716());
            if (fmt != null) sb.append('&').append(fmt.method_36145());
        }
        if (style.method_10984())          sb.append("&l");
        if (style.method_10966())        sb.append("&o");
        if (style.method_10965())    sb.append("&n");
        if (style.method_10986()) sb.append("&m");
        if (style.method_10987())    sb.append("&k");
    }

    private static Int2ObjectMap<class_124> buildColorLookup() {
        Int2ObjectOpenHashMap<class_124> map = new Int2ObjectOpenHashMap<>(16);
        for (class_124 fmt : class_124.values()) {
            if (fmt.method_543() && fmt.method_532() != null) {
                map.put((int) fmt.method_532(), fmt);
            }
        }
        return Int2ObjectMaps.unmodifiable(map);
    }
}