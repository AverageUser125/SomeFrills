package com.github.kd_gaming1.skyblockenhancements.feature.chat.search;

import com.github.kd_gaming1.skyblockenhancements.feature.chat.ChatLineTracker;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.render.ChatTextHelper;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_303;

/**
 * Owns the chat search query and decides whether individual messages pass the filter.
 *
 * <p>Matching is <b>multi-word AND</b>: the query is split on whitespace and every token must
 * appear (case-insensitive) in the plain-text form of the message. Tokens are lowercased once
 * at query-set time so the per-message path does no string allocation beyond the searchable
 * form of the message itself.
 */
public final class ChatSearchController {

    private static final String[] NO_TOKENS = new String[0];

    private boolean active;
    private String rawQuery = "";
    private String[] tokens = NO_TOKENS;

    public boolean isActive() {
        return active;
    }

    public boolean isFiltering() {
        return active && tokens.length > 0;
    }

    public String getQuery() {
        return rawQuery;
    }

    public void setActive(boolean value) {
        this.active = value;
        if (!value) {
            this.rawQuery = "";
            this.tokens = NO_TOKENS;
        }
    }

    public void setQuery(String query) {
        this.rawQuery = query;
        String trimmed = query.trim();
        this.tokens = trimmed.isEmpty()
                ? NO_TOKENS
                : trimmed.toLowerCase(Locale.ROOT).split("\\s+");
    }

    public boolean matches(class_2561 content) {
        if (!isFiltering()) return true;
        String plain = toSearchable(content);
        for (String token : tokens) {
            if (!plain.contains(token)) return false;
        }
        return true;
    }

    public boolean matches(class_303 message) {
        return matches(message.comp_893());
    }

    public int countMatching(List<class_303> messages) {
        if (!isFiltering()) return messages.size();
        int count = 0;
        for (class_303 msg : messages) {
            if (matches(msg)) count++;
        }
        return count;
    }

    public int countMatching(List<class_303> messages, ChatLineTracker tracker) {
        if (!isFiltering()) return messages.size();
        int count = 0;
        for (class_303 msg : messages) {
            String plain = tracker.getSearchableText(msg);
            if (matchesTokens(plain)) count++;
        }
        return count;
    }

    private boolean matchesTokens(String plain) {
        for (String token : tokens) {
            if (!plain.contains(token)) return false;
        }
        return true;
    }

    public static String toSearchable(class_2561 content) {
        String plain = class_124.method_539(content.getString());
        return ChatTextHelper.stripCompactSuffix(plain).toLowerCase(Locale.ROOT);
    }
}