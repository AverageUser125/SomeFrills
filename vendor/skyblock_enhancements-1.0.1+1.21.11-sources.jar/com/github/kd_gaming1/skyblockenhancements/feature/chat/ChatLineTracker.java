package com.github.kd_gaming1.skyblockenhancements.feature.chat;

import com.github.kd_gaming1.skyblockenhancements.feature.chat.render.CustomChatRenderer;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.search.ChatSearchController;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import java.util.Map;
import net.minecraft.class_303;
import net.minecraft.class_5481;
import org.jspecify.annotations.Nullable;

/**
 * Per-ChatComponent bookkeeping shared by every chat feature that needs to correlate a
 * displayed line with its source message or renderer.
 *
 * <p>The map is keyed on the {@link class_5481} stored inside each
 * {@link class_303.class_7590}, which is unique per displayed line. This gives O(1) lookups for:
 * <ul>
 *   <li>hover/click hit-testing (content → renderer),</li>
 *   <li>copy and delete resolution (content/line → parent message),</li>
 *   <li>selection outline rendering (parent identity comparison).</li>
 * </ul>
 *
 * <p>Line registration is bracketed by {@link #beginAddingLinesFor(class_303)} and
 * {@link #finishAddingLines()} so callers don't have to pass the parent to every record call.
 */
public final class ChatLineTracker {

    private record Entry(class_303 parent, @Nullable CustomChatRenderer renderer) {}

    private final Map<class_5481, Entry> byContent = new Reference2ObjectOpenHashMap<>();
    private final Reference2ObjectOpenHashMap<class_303, String> searchableText = new Reference2ObjectOpenHashMap<>();

    private @Nullable class_303 pendingParent;
    private @Nullable class_303 selectedMessage;

    public void beginAddingLinesFor(class_303 parent) {
        this.pendingParent = parent;
        this.searchableText.put(parent, ChatSearchController.toSearchable(parent.comp_893()));
    }

    public void finishAddingLines() {
        this.pendingParent = null;
    }

    /** Associates a freshly-added display line with its parent message and optional renderer. */
    public void recordLine(class_303.class_7590 line, @Nullable CustomChatRenderer renderer) {
        if (pendingParent == null) return;
        byContent.put(line.comp_896(), new Entry(pendingParent, renderer));
    }

    public void evictLine(class_303.class_7590 line) {
        byContent.remove(line.comp_896());
    }

    /** Discards all per-line state AND any active selection. Use on full history clear. */
    public void clearAll() {
        byContent.clear();
        searchableText.clear();
        selectedMessage = null;
    }

    /**
     * Discards per-line state only; leaves the selected message intact so the outline survives
     * display-queue rebuilds (e.g. rescale, tab switch) as long as the message still exists.
     */
    public void clearLineMappings() {
        byContent.clear();
        searchableText.clear();
    }

    public @Nullable CustomChatRenderer rendererFor(class_5481 content) {
        Entry entry = byContent.get(content);
        return entry == null ? null : entry.renderer;
    }

    public @Nullable class_303 parentFor(class_5481 content) {
        Entry entry = byContent.get(content);
        return entry == null ? null : entry.parent;
    }

    public @Nullable class_303 parentFor(class_303.class_7590 line) {
        return parentFor(line.comp_896());
    }

    public void setSelectedMessage(@Nullable class_303 message) {
        this.selectedMessage = message;
    }

    public @Nullable class_303 getSelectedMessage() {
        return selectedMessage;
    }

    /** Returns the pre-computed searchable plain text for a message, computing on demand if absent. */
    public String getSearchableText(class_303 message) {
        String cached = searchableText.get(message);
        if (cached != null) return cached;
        return ChatSearchController.toSearchable(message.comp_893());
    }
}