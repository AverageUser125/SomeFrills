package com.github.kd_gaming1.skyblockenhancements.feature.chat.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5481;
import org.jspecify.annotations.Nullable;

/**
 * Turns a message's raw lines into final display lines, tagging each with an optional
 * {@link CustomChatRenderer}. Called once per message added to the display queue.
 */
public final class ChatLineProcessor {

    /** Parallel arrays of the same length: {@code lines[i]} is rendered by {@code renderers[i]}. */
    public record Result(List<class_5481> lines, List<@Nullable CustomChatRenderer> renderers) {}

    private ChatLineProcessor() {}

    public static Result process(
            List<class_5481> rawLines,
            class_327 font,
            int width,
            boolean centerEnabled,
            boolean separatorsEnabled) {

        List<class_5481> lines = new ArrayList<>(rawLines.size());
        List<CustomChatRenderer> renderers = new ArrayList<>(rawLines.size());

        for (class_5481 rawSeq : rawLines) {
            String rawStr = ChatTextHelper.getString(rawSeq);
            String trimmedStr = rawStr.trim();

            // Blank lines are preserved verbatim: Hypixel uses them as vertical spacing
            // and reformatting them would collapse intentional gaps between messages.
            if (trimmedStr.isEmpty()) {
                lines.add(rawSeq);
                renderers.add(null);
                continue;
            }

            if (separatorsEnabled && ChatTextHelper.isFullSeparator(trimmedStr)) {
                lines.add(ChatTextHelper.trim(rawSeq));
                renderers.add(new SeparatorRenderer(ChatTextHelper.extractColor(rawSeq), null));

            } else if (separatorsEnabled && ChatTextHelper.isCenteredSeparator(trimmedStr)) {
                lines.add(ChatTextHelper.trim(rawSeq));
                renderers.add(new SeparatorRenderer(
                        ChatTextHelper.extractColor(rawSeq),
                        ChatTextHelper.extractMiddleText(trimmedStr)));

            } else if (centerEnabled && ChatTextHelper.isCenteredText(font, rawStr, trimmedStr)) {
                class_2561 trimmedComponent = ChatTextHelper.toComponent(ChatTextHelper.trim(rawSeq));
                for (class_5481 wrapped : font.method_1728(trimmedComponent, width)) {
                    lines.add(wrapped);
                    renderers.add(CenteredTextRenderer.INSTANCE);
                }

            } else {
                class_2561 component = ChatTextHelper.toComponent(rawSeq);
                for (class_5481 wrapped : font.method_1728(component, width)) {
                    lines.add(wrapped);
                    renderers.add(null);
                }
            }
        }
        return new Result(lines, renderers);
    }
}