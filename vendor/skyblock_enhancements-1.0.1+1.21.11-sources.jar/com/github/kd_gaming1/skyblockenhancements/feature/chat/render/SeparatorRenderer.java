package com.github.kd_gaming1.skyblockenhancements.feature.chat.render;

import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import net.minecraft.class_9848;
import org.jspecify.annotations.Nullable;

/**
 * Draws a separator line as two smooth rectangles flanking optional centered text.
 * When {@code middleText} is null, a single continuous line spans the chat area.
 */
public record SeparatorRenderer(int lineColor, @Nullable String middleText)
        implements CustomChatRenderer {

    /** Hypixel's heavy-block separator; rendered as a thicker line. */
    private static final int BLOCK_CHAR = '▬';

    private static final int TEXT_PADDING = 4;
    private static final float SHADOW_FACTOR = 0.25f;

    @Override
    public void render(
            class_332 graphics,
            class_327 font,
            class_5481 text,
            int lineX,
            int textY,
            int lineWidth,
            float alpha) {

        int thickness = containsBlockChar(text) ? 2 : 1;
        int alpha8 = class_9848.method_61326(alpha);
        int color = class_9848.method_61330(alpha8, lineColor);
        int shadow = class_9848.method_61321(color, SHADOW_FACTOR);
        int lineY = textY + (font.field_2000 - thickness) / 2;
        int right = lineX + lineWidth;

        if (middleText == null || middleText.isEmpty()) {
            drawLineSegment(graphics, lineX, lineY, right, thickness, color, shadow);
            return;
        }

        int textWidth = font.method_1727(middleText);
        int textX = lineX + (lineWidth - textWidth) / 2;
        graphics.method_51433(font, middleText, textX, textY, color, true);

        int leftEnd = textX - TEXT_PADDING;
        if (leftEnd > lineX + 2) {
            drawLineSegment(graphics, lineX + 1, lineY, leftEnd, thickness, color, shadow);
        }

        int rightStart = textX + textWidth + TEXT_PADDING;
        if (rightStart < right - 2) {
            drawLineSegment(graphics, rightStart, lineY, right, thickness, color, shadow);
        }
    }

    @Override
    public HitTest hitTest(class_327 font, class_5481 text, int lineX, int lineWidth) {
        // Even separators with middle text carry no clickable content, so hit-testing is
        // unconditionally off. Mouse interaction on these lines is intentional no-op.
        return HitTest.DISABLED;
    }

    private static void drawLineSegment(
            class_332 graphics, int x, int y, int xEnd, int thickness, int color, int shadow) {
        graphics.method_25294(x + 1, y + 1, xEnd - 1, y + thickness + 1, shadow);
        graphics.method_25294(x, y, xEnd - 2, y + thickness, color);
    }

    private static boolean containsBlockChar(class_5481 text) {
        boolean[] found = {false};
        text.accept((index, style, cp) -> {
            if (cp == BLOCK_CHAR) {
                found[0] = true;
                return false;
            }
            return true;
        });
        return found[0];
    }
}