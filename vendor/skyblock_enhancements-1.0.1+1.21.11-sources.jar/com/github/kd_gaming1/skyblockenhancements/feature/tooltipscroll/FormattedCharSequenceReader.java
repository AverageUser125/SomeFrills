package com.github.kd_gaming1.skyblockenhancements.feature.tooltipscroll;

import net.minecraft.class_2583;
import net.minecraft.class_5224;
import net.minecraft.class_5481;
import org.jspecify.annotations.NonNull;

/**
 * Reads a {@link class_5481} into a plain {@link String}.
 *
 * <p>Adapted from Provismet's tooltip-scroll mod (MIT license).
 * See THIRD_PARTY_LICENSES.md for details.</p>
 */
public final class FormattedCharSequenceReader {

    private FormattedCharSequenceReader() {}

    /**
     * Visits every character in the sequence and concatenates them into
     * a plain string, discarding style information.
     */
    public static String read(class_5481 text) {
        ReaderSink sink = new ReaderSink();
        text.accept(sink);
        return sink.result.toString();
    }

    private static class ReaderSink implements class_5224 {
        final StringBuilder result = new StringBuilder();

        @Override
        public boolean accept(int index, @NonNull class_2583 style, int codePoint) {
            result.append((char) codePoint);
            return true;
        }
    }
}