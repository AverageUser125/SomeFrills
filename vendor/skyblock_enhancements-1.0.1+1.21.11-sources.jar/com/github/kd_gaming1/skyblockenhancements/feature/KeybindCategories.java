package com.github.kd_gaming1.skyblockenhancements.feature;

import net.minecraft.class_2960;
import net.minecraft.class_304;

public final class KeybindCategories {
    public static final class_304.class_11900 GENERAL =
            class_304.class_11900.method_74698(
                    class_2960.method_60655("skyblock_enhancements", "general")
            );

    private KeybindCategories() {}
}