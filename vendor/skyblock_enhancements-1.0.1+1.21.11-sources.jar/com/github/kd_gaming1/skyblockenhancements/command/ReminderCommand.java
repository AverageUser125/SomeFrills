package com.github.kd_gaming1.skyblockenhancements.command;

import com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements;
import com.github.kd_gaming1.skyblockenhancements.feature.katreminder.KatReminderFeature;
import com.github.kd_gaming1.skyblockenhancements.feature.reminder.OutputType;
import com.github.kd_gaming1.skyblockenhancements.feature.reminder.Reminder;
import com.github.kd_gaming1.skyblockenhancements.feature.reminder.ReminderManager;
import com.github.kd_gaming1.skyblockenhancements.feature.reminder.TriggerType;
import com.github.kd_gaming1.skyblockenhancements.gui.reminder.ReminderScreen;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.List;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class ReminderCommand {

    private static Consumer<ReminderManager> persistHook = rm -> {};

    public static void register(
            ReminderManager reminderManager, Consumer<ReminderManager> persistConsumer) {
        persistHook = persistConsumer != null ? persistConsumer : rm -> {};

        ClientCommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess) -> dispatcher.register(buildRoot(reminderManager)));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildRoot(
            ReminderManager reminderManager) {
        return literal("remindme")
                .then(buildCreateCommand(reminderManager))
                .then(buildRemoveCommand(reminderManager))
                .then(buildRenameCommand(reminderManager))
                .then(buildToggleCommand(reminderManager))
                .then(buildSnoozeCommand(reminderManager))
                .then(literal("list").executes(ctx -> executeList(ctx, reminderManager)))
                .then(literal("help").executes(ReminderCommand::executeHelp))
                .then(buildGuiCommand(reminderManager));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildCreateCommand(
            ReminderManager reminderManager) {
        var messageBranch =
                literal("message")
                        .then(argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> executeCreate(ctx, reminderManager, null, null)));

        var repeatBranch =
                literal("repeat")
                        .then(argument("times", StringArgumentType.word())
                                .suggests(REPEAT_TIMES)
                                .then(argument("message", StringArgumentType.greedyString())
                                        .executes(ctx -> executeCreate(
                                                ctx,
                                                reminderManager,
                                                StringArgumentType.getString(ctx, "times"),
                                                null))));

        var nameBranch =
                literal("name")
                        .then(argument("name", StringArgumentType.word())
                                .then(argument("message", StringArgumentType.greedyString())
                                        .executes(ctx -> executeCreate(
                                                ctx,
                                                reminderManager,
                                                null,
                                                StringArgumentType.getString(ctx, "name")))));

        var outputArg =
                argument("output", StringArgumentType.word())
                        .suggests(OUTPUT_TYPES)
                        .then(messageBranch)
                        .then(repeatBranch)
                        .then(nameBranch);

        var triggerArg =
                argument("trigger", StringArgumentType.word())
                        .suggests(TRIGGERS)
                        .then(outputArg);

        var unitArg =
                argument("unit", StringArgumentType.word())
                        .suggests(TIME_UNITS)
                        .then(triggerArg);

        var amountArg =
                argument("amount", IntegerArgumentType.integer(1))
                        .then(unitArg);

        return literal("create").then(amountArg);
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildRemoveCommand(
            ReminderManager reminderManager) {
        return literal("remove")
                .then(argument("id", IntegerArgumentType.integer(1))
                        .suggests(suggestReminderIds(reminderManager))
                        .executes(ctx -> executeRemove(ctx, reminderManager)))
                .then(literal("all").executes(ctx -> executeRemoveAll(ctx, reminderManager, false)))
                .then(literal("all_confirmed").executes(ctx -> executeRemoveAll(ctx, reminderManager, true)));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildRenameCommand(
            ReminderManager reminderManager) {
        return literal("rename")
                .then(argument("id", IntegerArgumentType.integer(1))
                        .suggests(suggestReminderIds(reminderManager))
                        .then(argument("name", StringArgumentType.greedyString())
                                .executes(ctx -> executeRename(ctx, reminderManager))));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildToggleCommand(
            ReminderManager reminderManager) {
        return literal("toggle")
                .then(argument("id", IntegerArgumentType.integer(1))
                        .suggests(suggestReminderIds(reminderManager))
                        .executes(ctx -> executeToggle(ctx, reminderManager)));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildSnoozeCommand(
            ReminderManager reminderManager) {
        return literal("snooze")
                .then(argument("id", IntegerArgumentType.integer(1))
                        .suggests(suggestReminderIds(reminderManager))
                        .then(argument("amount", IntegerArgumentType.integer(1))
                                .then(argument("unit", StringArgumentType.word())
                                        .suggests(TIME_UNITS)
                                        .executes(ctx -> executeSnooze(ctx, reminderManager)))));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildGuiCommand(
            ReminderManager reminderManager) {
        return literal("gui").executes(ctx -> {
            class_310 client = class_310.method_1551();
            client.method_63588(() -> {
                try {
                    client.method_1507(new ReminderScreen(
                            reminderManager,
                            () -> persistReminders(reminderManager)));
                } catch (Exception e) {
                    SkyblockEnhancements.LOGGER.error("Failed to open config menu", e);
                }
            });
            return 1;
        });
    }

    private static final SuggestionProvider<FabricClientCommandSource> TIME_UNITS =
            (context, builder) -> {
                for (String unit : new String[] {"seconds", "minutes", "hours", "days", "sec", "min", "hour", "day"}) {
                    builder.suggest(unit);
                }
                return builder.buildFuture();
            };

    private static final SuggestionProvider<FabricClientCommandSource> TRIGGERS =
            (context, builder) -> {
                builder.suggest("while_playing");
                builder.suggest("real_time");
                return builder.buildFuture();
            };

    private static final SuggestionProvider<FabricClientCommandSource> OUTPUT_TYPES =
            (context, builder) -> {
                builder.suggest("chat");
                builder.suggest("title_box");
                builder.suggest("chat_and_title");
                builder.suggest("sound_only");
                return builder.buildFuture();
            };

    private static final SuggestionProvider<FabricClientCommandSource> REPEAT_TIMES =
            (context, builder) -> {
                for (String s : new String[] {"until_removed", "2", "3", "5", "10"}) {
                    builder.suggest(s);
                }
                return builder.buildFuture();
            };

    private static SuggestionProvider<FabricClientCommandSource> suggestReminderIds(
            ReminderManager reminderManager) {
        return (context, builder) -> {
            for (Reminder reminder : reminderManager.getActiveReminders()) {
                builder.suggest(reminder.getId(), class_2561.method_43470(reminder.getDisplayName()));
            }
            return builder.buildFuture();
        };
    }

    // Command handlers

    private static int executeCreate(CommandContext<FabricClientCommandSource> context,
                                     ReminderManager reminderManager,
                                     String repeatTimesArg, String name) {
        int amount = IntegerArgumentType.getInteger(context, "amount");
        String unit = StringArgumentType.getString(context, "unit");
        String triggerArg = StringArgumentType.getString(context, "trigger");
        String outputArg = StringArgumentType.getString(context, "output");
        String message = StringArgumentType.getString(context, "message");

        long multiplier = getMultiplier(unit);
        if (multiplier == -1) {
            context.getSource().sendError(class_2561.method_43470("Invalid time unit: " + unit));
            return 0;
        }

        TriggerType triggerType;
        try {
            triggerType = TriggerType.valueOf(triggerArg.toUpperCase());
        } catch (IllegalArgumentException e) {
            context.getSource().sendError(class_2561.method_43470("Invalid trigger: " + triggerArg));
            return 0;
        }

        OutputType outputType;
        try {
            outputType = OutputType.valueOf(outputArg.toUpperCase());
        } catch (IllegalArgumentException e) {
            context.getSource().sendError(class_2561.method_43470("Invalid output type: " + outputArg));
            return 0;
        }

        int repeatCount = parseRepeatCount(context, repeatTimesArg);
        if (repeatTimesArg != null && repeatCount == 0) {
            return 0;
        }

        long durationMs = (long) amount * multiplier;
        Reminder reminder =
                reminderManager.createReminder(durationMs, outputType, name, message, triggerType, repeatCount);

        context.getSource().sendFeedback(
                buildCreateFeedback(reminder, amount, unit, repeatTimesArg, repeatCount));
        persistReminders(reminderManager);
        return 1;
    }

    private static int executeRemove(
            CommandContext<FabricClientCommandSource> context, ReminderManager reminderManager) {
        int id = IntegerArgumentType.getInteger(context, "id");

        if (reminderManager.removeReminder(id)) {
            persistReminders(reminderManager);
            context.getSource().sendFeedback(
                    class_2561.method_43470("Removed reminder ").method_27692(class_124.field_1080)
                            .method_10852(class_2561.method_43470("#" + id).method_27692(class_124.field_1063)));
            return 1;
        }

        context.getSource().sendError(class_2561.method_43470("Reminder #" + id + " not found"));
        return 0;
    }

    private static int executeRemoveAll(CommandContext<FabricClientCommandSource> context,
                                        ReminderManager reminderManager, boolean confirmed) {
        if (!confirmed) {
            class_5250 prompt = class_2561.method_43470("Remove all reminders? ")
                    .method_27692(class_124.field_1080)
                    .method_10852(class_2561.method_43470("[confirm]").method_27694(style -> style
                            .method_10977(class_124.field_1061)
                            .method_10958(new class_2558.class_10609("/remindme remove all_confirmed"))));
            context.getSource().sendFeedback(prompt);
            return 1;
        }

        int count = reminderManager.removeAllReminders() + KatReminderFeature.removeAllReminders();
        persistReminders(reminderManager);
        context.getSource().sendFeedback(
                class_2561.method_43470("Removed " + count + " reminder(s)").method_27692(class_124.field_1080));
        return 1;
    }

    private static int executeRename(
            CommandContext<FabricClientCommandSource> context, ReminderManager reminderManager) {
        int id = IntegerArgumentType.getInteger(context, "id");
        String newName = StringArgumentType.getString(context, "name");

        if (reminderManager.renameReminder(id, newName)) {
            persistReminders(reminderManager);
            context.getSource().sendFeedback(
                    class_2561.method_43470("Renamed #" + id + " to ").method_27692(class_124.field_1080)
                            .method_10852(class_2561.method_43470(newName).method_27692(class_124.field_1054)));
            return 1;
        }

        context.getSource().sendError(class_2561.method_43470("Reminder #" + id + " not found"));
        return 0;
    }

    private static int executeToggle(
            CommandContext<FabricClientCommandSource> context, ReminderManager reminderManager) {
        int id = IntegerArgumentType.getInteger(context, "id");

        if (reminderManager.toggleReminder(id)) {
            persistReminders(reminderManager);
            Reminder found = reminderManager.getActiveReminders()
                    .stream()
                    .filter(r -> r.getId() == id)
                    .findFirst()
                    .orElse(null);

            String stateStr = (found != null && found.isPaused()) ? "OFF" : "ON";
            class_124 stateColor = "ON".equals(stateStr) ? class_124.field_1060 : class_124.field_1080;

            context.getSource().sendFeedback(
                    class_2561.method_43470("Toggled reminder ").method_27692(class_124.field_1080)
                            .method_10852(class_2561.method_43470("#" + id).method_27692(class_124.field_1063))
                            .method_10852(class_2561.method_43470(" -> ").method_27692(class_124.field_1080))
                            .method_10852(class_2561.method_43470(stateStr).method_27692(stateColor)));
            return 1;
        }

        context.getSource().sendError(class_2561.method_43470("Reminder #" + id + " not found"));
        return 0;
    }

    private static int executeSnooze(
            CommandContext<FabricClientCommandSource> context, ReminderManager reminderManager) {
        int id = IntegerArgumentType.getInteger(context, "id");
        int amount = IntegerArgumentType.getInteger(context, "amount");
        String unit = StringArgumentType.getString(context, "unit");

        long multiplier = getMultiplier(unit);
        if (multiplier == -1) {
            context.getSource().sendError(class_2561.method_43470("Invalid time unit: " + unit));
            return 0;
        }

        long extraMs = (long) amount * multiplier;

        if (reminderManager.snoozeReminder(id, extraMs)) {
            persistReminders(reminderManager);
            context.getSource().sendFeedback(
                    class_2561.method_43470("Snoozed #" + id + " for ").method_27692(class_124.field_1080)
                            .method_10852(class_2561.method_43470(amount + " " + unit).method_27692(class_124.field_1075)));
            return 1;
        }

        context.getSource().sendError(class_2561.method_43470("Reminder #" + id + " not found"));
        return 0;
    }

    private static int executeList(
            CommandContext<FabricClientCommandSource> context, ReminderManager reminderManager) {
        List<Reminder> reminders = reminderManager.getActiveReminders();
        var katReminders = KatReminderFeature.getActiveReminders();

        if (reminders.isEmpty() && katReminders.isEmpty()) {
            context.getSource().sendFeedback(
                    class_2561.method_43470("No active reminders").method_27692(class_124.field_1080));
            return 0;
        }

        class_5250 header = class_2561.method_43470("Your Reminders: ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470("[remove all]").method_27694(style -> style
                        .method_10977(class_124.field_1061)
                        .method_10958(new class_2558.class_10609("/remindme remove all"))));
        context.getSource().sendFeedback(header);

        for (Reminder reminder : reminders) {
            context.getSource().sendFeedback(buildReminderListLine(reminder));
        }

        for (var katReminder : katReminders) {
            long remainingMs = Math.max(0L, katReminder.readyAtMs - System.currentTimeMillis());
            class_5250 katName = class_2561.method_43470("Kat: ")
                    .method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470(katReminder.pet).method_27692(mapRarityColor(katReminder.rarity)));
            context.getSource().sendFeedback(
                    buildTimerLine(
                            "#K",
                            katName,
                            ReminderManager.formatMs(remainingMs) + " left",
                            "real time",
                            null,
                            null,
                            null,
                            null,
                            null));
        }

        return 1;
    }

    private static int executeHelp(CommandContext<FabricClientCommandSource> context) {
        context.getSource().sendFeedback(class_2561.method_43470("§6§l=== RemindMe Help ==="));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme create <amount> <unit> <trigger> <output> message <message>"));
        context.getSource().sendFeedback(class_2561.method_43470("  §7Creates a one-time reminder"));
        context.getSource().sendFeedback(class_2561.method_43470("  §7Units: seconds, minutes, hours, days"));
        context.getSource().sendFeedback(class_2561.method_43470("  §7Triggers: while_playing (pauses on logout) or real_time"));
        context.getSource().sendFeedback(class_2561.method_43470("  §7Output: chat, title_box, chat_and_title, sound_only"));
        context.getSource().sendFeedback(class_2561.method_43470(""));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme create ... repeat <times> <message>"));
        context.getSource().sendFeedback(class_2561.method_43470("  §7Repeating reminder — times: until_removed or ≥2"));
        context.getSource().sendFeedback(class_2561.method_43470(""));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme create ... name <label> <message>"));
        context.getSource().sendFeedback(class_2561.method_43470("  §7Creates a reminder with a custom display name"));
        context.getSource().sendFeedback(class_2561.method_43470(""));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme gui                  §7— Open graphical interface"));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme rename <id> <name>  §7— Rename a reminder"));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme toggle <id>         §7— Toggle a reminder ON/OFF"));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme snooze <id> <amount> <unit>  §7— Delay a reminder"));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme remove <id>         §7— Remove a reminder"));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme remove all          §7— Remove all reminders"));
        context.getSource().sendFeedback(class_2561.method_43470("§e/remindme list                §7— List all active reminders"));
        return 1;
    }

    // List line builder

    private static class_5250 buildReminderListLine(Reminder reminder) {
        String index = "#" + reminder.getId();

        String timeDisplay;
        if (reminder.isPaused()) {
            timeDisplay = ReminderManager.formatMs(reminder.getOriginalDuration());
        } else {
            timeDisplay = ReminderManager.formatMs(reminder.getRemainingMs()) + " left";
        }

        String triggerLabel =
                reminder.getTriggerType() == TriggerType.REAL_TIME ? "real time" : "play time";

        String repeatLabel = null;
        if (reminder.getTotalRepeats() == ReminderManager.REPEAT_FOREVER) {
            repeatLabel = "∞";
        } else if (reminder.getTotalRepeats() > 1) {
            repeatLabel = (reminder.getRepeatCount() + 1) + "/" + reminder.getTotalRepeats();
        }

        String toggleCommand = "/remindme toggle " + reminder.getId();
        String toggleLabel = reminder.isPaused() ? "[ON]" : "[OFF]";
        class_124 toggleColor = reminder.isPaused() ? class_124.field_1060 : class_124.field_1080;

        class_5250 name =
                class_2561.method_43470(reminder.getDisplayName()).method_27692(class_124.field_1054);
        if (reminder.isPaused()) {
            name.method_10852(class_2561.method_43470(" (OFF)").method_27692(class_124.field_1063));
        }

        return buildTimerLine(
                index,
                name,
                timeDisplay,
                triggerLabel,
                "/remindme remove " + reminder.getId(),
                toggleCommand,
                toggleLabel,
                toggleColor,
                repeatLabel);
    }

    private static class_5250 buildTimerLine(String index, class_2561 name, String timeDisplay,
                                                   String timerType, String removeCommand,
                                                   String toggleCommand, String toggleLabel,
                                                   class_124 toggleColor, String repeatLabel) {
        class_5250 line = class_2561.method_43470("")
                .method_10852(class_2561.method_43470(index).method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                .method_10852(name)
                .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(timeDisplay).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(timerType).method_27692(class_124.field_1065));

        if (repeatLabel != null) {
            line.method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470(repeatLabel).method_27692(class_124.field_1076));
        }

        if (toggleCommand != null && toggleLabel != null && toggleColor != null) {
            line.method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470(toggleLabel).method_27694(style -> style
                            .method_10977(toggleColor)
                            .method_10958(new class_2558.class_10609(toggleCommand))));
        }

        if (removeCommand != null) {
            line.method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470("[remove]").method_27694(style -> style
                            .method_10977(class_124.field_1061)
                            .method_10958(new class_2558.class_10609(removeCommand))));
        }

        return line;
    }

    // Helpers

    private static int parseRepeatCount(
            CommandContext<FabricClientCommandSource> context, String repeatTimesArg) {
        if (repeatTimesArg == null) {
            return 1;
        }
        if (repeatTimesArg.equalsIgnoreCase("until_removed")) {
            return ReminderManager.REPEAT_FOREVER;
        }

        try {
            int count = Integer.parseInt(repeatTimesArg);
            if (count < 2) {
                context.getSource().sendError(class_2561.method_43470("Repeat count must be at least 2"));
                return 0;
            }
            return count;
        } catch (NumberFormatException e) {
            context.getSource().sendError(class_2561.method_43470("Invalid repeat count: " + repeatTimesArg));
            return 0;
        }
    }

    private static class_5250 buildCreateFeedback(Reminder reminder, int amount, String unit,
                                                        String repeatTimesArg, int repeatCount) {
        String triggerLabel =
                reminder.getTriggerType() == TriggerType.REAL_TIME ? "real time" : "play time";

        class_5250 feedback = class_2561.method_43470("Created ")
                .method_27692(class_124.field_1080)
                .method_10852(class_2561.method_43470(triggerLabel).method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(" reminder ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("#" + reminder.getId()).method_27692(class_124.field_1063));

        if (reminder.getName() != null) {
            feedback.method_10852(class_2561.method_43470(" \"" + reminder.getName() + "\"")
                    .method_27692(class_124.field_1054));
        }

        feedback.method_10852(class_2561.method_43470(" - ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(reminder.getMessage()).method_27692(class_124.field_1068));

        if (repeatTimesArg != null) {
            String repeatLabel =
                    repeatCount == ReminderManager.REPEAT_FOREVER ? "until removed" : repeatCount + "x";
            feedback.method_10852(class_2561.method_43470(" every ").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470(amount + " " + unit).method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                    .method_10852(class_2561.method_43470(repeatLabel).method_27692(class_124.field_1076));
        } else {
            feedback.method_10852(class_2561.method_43470(" in ").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470(amount + " " + unit).method_27692(class_124.field_1075));
        }

        return feedback;
    }

    private static class_124 mapRarityColor(String rarity) {
        if (rarity == null) {
            return class_124.field_1068;
        }
        return switch (rarity.toUpperCase()) {
            case "UNCOMMON" -> class_124.field_1060;
            case "RARE" -> class_124.field_1078;
            case "EPIC" -> class_124.field_1064;
            case "LEGENDARY" -> class_124.field_1065;
            case "MYTHIC" -> class_124.field_1076;
            default -> class_124.field_1068;
        };
    }

    private static long getMultiplier(String unit) {
        return switch (unit.toLowerCase()) {
            case "s", "sec", "seconds" -> 1_000L;
            case "m", "min", "minutes" -> 60 * 1_000L;
            case "h", "hour", "hours" -> 60 * 60 * 1_000L;
            case "d", "day", "days" -> 24 * 60 * 60 * 1_000L;
            default -> -1;
        };
    }

    private static void persistReminders(ReminderManager reminderManager) {
        persistHook.accept(reminderManager);
    }
}
