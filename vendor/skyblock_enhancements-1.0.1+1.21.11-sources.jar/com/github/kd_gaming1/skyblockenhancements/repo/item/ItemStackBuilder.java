package com.github.kd_gaming1.skyblockenhancements.repo.item;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.ImmutableMultimap;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9282;
import net.minecraft.class_9290;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;

/**
 * Converts {@link NeuItem} POJOs into rendered {@link class_1799}s.
 *
 * <p>Stacks are cached as immutable prototypes — callers copy before mutating. Skull textures are
 * embedded at build time but the skin download is deferred to {@link #ensureSkinLoaded}, avoiding
 * thousands of main-thread fetches during bulk construction.
 */
public final class ItemStackBuilder {

    /** Prototype cache. Stacks here are shared; call {@code .copy()} before mutating. */
    private static final Cache<String, class_1799> CACHE = CacheBuilder.newBuilder()
            .maximumSize(2000)
            .build();

    /** Identity set of skull stacks whose skin fetch has already been scheduled. */
    private static final Set<class_1799> SKIN_LOADED =
            Collections.newSetFromMap(new ConcurrentHashMap<>());

    /** Recipe-only virtual items that don't have a corresponding NEU repo entry. */
    private static final Map<String, Supplier<class_1799>> VIRTUAL_ITEMS = Map.of(
            "SKYBLOCK_COIN", ItemStackBuilder::buildCoinStack
    );

    private ItemStackBuilder() {}

    // ── Public API ───────────────────────────────────────────────────────────────

    /** Returns a shared prototype for the given item. Call {@code .copy()} before mutating. */
    public static class_1799 build(NeuItem item) {
        try {
            return CACHE.get(item.internalName, () -> createStack(item));
        } catch (Exception e) {
            throw new RuntimeException("Failed to build ItemStack for " + item.internalName, e);
        }
    }

    /**
     * Builds an ingredient stack from a recipe reference like {@code "ENCHANTED_DIAMOND"}.
     * Resolves against NEU items first, falling back to virtual items, then a visible barrier.
     */
    public static class_1799 buildIngredient(String neuId, int count) {
        if (neuId == null || neuId.isEmpty()) return class_1799.field_8037;

        NeuItem item = NeuItemRegistry.get(neuId);
        if (item != null) {
            class_1799 stack = build(item).method_7972();
            stack.method_7939(count);
            return stack;
        }

        Supplier<class_1799> virtual = VIRTUAL_ITEMS.get(neuId);
        if (virtual != null) {
            class_1799 stack = virtual.get();
            stack.method_7939(count);
            return stack;
        }

        return buildUnknownFallback(neuId, count);
    }

    /**
     * Triggers the skin fetch for a skull stack. Safe to call from a render or tooltip path.
     * No-op for non-skull stacks and for stacks that have already been fetched this session.
     */
    public static void ensureSkinLoaded(class_1799 stack) {
        if (stack.method_7960()) return;
        if (!stack.method_57826(class_9334.field_49617)) return;
        if (!SKIN_LOADED.add(stack)) return;

        class_9296 profile = stack.method_58694(class_9334.field_49617);
        if (profile == null) return;

        class_310 mc = class_310.method_1551();
        mc.execute(() -> mc.method_1582().method_52863(profile.method_73313()));
    }

    /** Drops all cached prototypes — call after a repo reload. */
    public static void clearCache() {
        CACHE.invalidateAll();
        SKIN_LOADED.clear();
    }

    // ── Stack construction ──────────────────────────────────────────────────────

    private static class_1799 createStack(NeuItem item) {
        class_1792 baseItem = resolveBaseItem(item);
        class_1799 stack = new class_1799(baseItem);

        applyDisplayName(stack, item, baseItem);
        applySkyblockIdTag(stack, item.internalName);
        applyLore(stack, item, baseItem);
        applyItemModel(stack, item);
        applySkullProfile(stack, item);
        applyLeatherColor(stack, item);
        applyEnchantmentGlint(stack, item);

        return stack;
    }

    private static void applyDisplayName(class_1799 stack, NeuItem item, class_1792 baseItem) {
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(resolveDisplayName(item, baseItem)));
    }

    /**
     * For enchanted books, prefer the first lore line (e.g. {@code "§9Sharpness III"}) over
     * the generic "Enchanted Book" display name so search/compare works on the actual enchant.
     */
    private static String resolveDisplayName(NeuItem item, class_1792 baseItem) {
        if (baseItem != class_1802.field_8598 || item.lore == null || item.lore.isEmpty()) {
            return item.displayName;
        }

        String enchantLine = item.lore.getFirst();
        if (enchantLine.isBlank()) return item.displayName;

        String rarityColor = (item.displayName != null && item.displayName.length() >= 2
                && item.displayName.charAt(0) == '§')
                ? item.displayName.substring(0, 2)
                : "§f";
        String enchantText = (enchantLine.length() >= 2 && enchantLine.charAt(0) == '§')
                ? enchantLine.substring(2)
                : enchantLine;
        return rarityColor + enchantText;
    }

    private static void applySkyblockIdTag(class_1799 stack, String internalName) {
        class_2487 tag = new class_2487();
        tag.method_10582("id", internalName);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
    }

    private static void applyLore(class_1799 stack, NeuItem item, class_1792 baseItem) {
        if (item.lore == null || item.lore.isEmpty()) return;

        List<String> loreLines = (baseItem == class_1802.field_8598)
                ? item.lore.subList(1, item.lore.size())
                : item.lore;

        List<class_2561> lines = loreLines.stream().<class_2561>map(class_2561::method_43470).toList();
        stack.method_57379(class_9334.field_49632, new class_9290(lines));
    }

    private static void applyItemModel(class_1799 stack, NeuItem item) {
        if (item.itemModel == null) return;
        if (stack.method_7909() == class_1802.field_8575) return;
        class_2960 modelRl = class_2960.method_12829(item.itemModel);
        if (modelRl != null) stack.method_57379(class_9334.field_54199, modelRl);
    }

    private static void applySkullProfile(class_1799 stack, NeuItem item) {
        if (item.skullTexture == null || item.skullTexture.isEmpty()) return;

        PropertyMap properties = new PropertyMap(
                ImmutableMultimap.of("textures", new Property("textures", item.skullTexture)));
        UUID uuid = UUID.nameUUIDFromBytes(item.skullTexture.getBytes(StandardCharsets.UTF_8));
        GameProfile profile = new GameProfile(uuid, item.internalName, properties);
        stack.method_57379(class_9334.field_49617, class_9296.method_73307(profile));
    }

    private static void applyLeatherColor(class_1799 stack, NeuItem item) {
        if (item.leatherColor < 0) return;
        stack.method_57379(class_9334.field_49644, new class_9282(item.leatherColor));
    }

    private static void applyEnchantmentGlint(class_1799 stack, NeuItem item) {
        if (!item.enchantmentGlint) return;
        stack.method_57379(class_9334.field_49641, true);
    }

    // ── Base-item resolution ────────────────────────────────────────────────────

    private static class_1792 resolveBaseItem(NeuItem item) {
        if (item.snbtItemId != null) {
            class_1792 resolved = lookupItem(item.snbtItemId);
            if (resolved != class_1802.field_8077) return resolved;
        }
        return lookupItem(LegacyItemIdMapper.map(item.itemId, item.damage));
    }

    private static class_1792 lookupItem(String id) {
        class_2960 rl = class_2960.method_12829(id);
        if (rl == null) return class_1802.field_8077;
        class_1792 resolved = class_7923.field_41178.method_63535(rl);
        return resolved != class_1802.field_8162 ? resolved : class_1802.field_8077;
    }

    // ── Virtual / fallback stacks ───────────────────────────────────────────────

    private static class_1799 buildCoinStack() {
        class_1799 stack = new class_1799(class_1802.field_8397);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("§6Coins"));
        class_2487 tag = new class_2487();
        tag.method_10582("id", "SKYBLOCK_COIN");
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        return stack;
    }

    private static class_1799 buildUnknownFallback(String neuId, int count) {
        class_1799 fallback = new class_1799(class_1802.field_8077, count);
        fallback.method_57379(class_9334.field_49631, class_2561.method_43470("§c" + neuId));
        class_2487 tag = new class_2487();
        tag.method_10582("id", neuId);
        fallback.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        return fallback;
    }
}