package com.github.kd_gaming1.skyblockenhancements.repo.neu;

import static com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements.LOGGER;

import com.github.kd_gaming1.skyblockenhancements.repo.RepoDiskCache;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * In-memory store for parsed NEU repo {@code constants/*.json} data.
 *
 * <p>Currently models:
 * <ul>
 *   <li>{@code parents.json}       → parent→children family map + reverse index</li>
 *   <li>{@code essencecosts.json}  → per-item star upgrade costs ({@link EssenceUpgrade})</li>
 *   <li>{@code museum.json}        → wing→items map + reverse index</li>
 *   <li>{@code pets.json}          → pet ID → skill type</li>
 *   <li>{@code petnums.json}       → delegated to {@link PetStatResolver}</li>
 * </ul>
 *
 * <p>All state is replaced atomically via volatile publish; reads are lock-free.
 * Raw JSON for cache round-tripping lives in {@link RepoDiskCache}, not here.
 */
public final class NeuConstantsRegistry {

    // ── Parents ─────────────────────────────────────────────────────────────────

    private static volatile Map<String, Set<String>> parentToChildren = Map.of();
    private static volatile Map<String, String> childToParent = Map.of();
    /** Maps every item (parent or child) to its canonical family root. Built from parents.json. */
    private static volatile Map<String, String> canonicalFamily = Map.of();

    // ── Essence costs ───────────────────────────────────────────────────────────

    private static volatile Map<String, EssenceUpgrade> essenceUpgrades = Map.of();

    // ── Museum ──────────────────────────────────────────────────────────────────

    private static volatile Map<String, List<String>> museumCategories = Map.of();
    private static volatile Map<String, String> itemToMuseumWing = Map.of();

    // ── Pet types ───────────────────────────────────────────────────────────────

    private static volatile Map<String, String> petTypes = Map.of();

    // ── Reforges ────────────────────────────────────────────────────────────────

    private static volatile Map<String, ReforgeData> reforges = Map.of();
    private static volatile Map<String, ReforgeStoneData> reforgeStones = Map.of();

    private NeuConstantsRegistry() {}

    // ── Loaders ─────────────────────────────────────────────────────────────────

    /** Parses {@code { "PARENT_ID": ["CHILD_1", ...], ... }}. */
    public static void loadParents(JsonObject json) {
        Map<String, Set<String>> p2c = new HashMap<>(json.size());
        Map<String, String> c2p = new HashMap<>(json.size() * 3);

        for (var entry : json.entrySet()) {
            JsonElement val = entry.getValue();
            if (!val.isJsonArray()) continue;

            String parentId = entry.getKey();
            Set<String> children = new HashSet<>();
            for (JsonElement child : val.getAsJsonArray()) {
                String childId = child.getAsString();
                children.add(childId);
                c2p.put(childId, parentId);
            }
            if (!children.isEmpty()) {
                p2c.put(parentId, Collections.unmodifiableSet(children));
            }
        }

        Map<String, String> cf = new HashMap<>(p2c.size() + c2p.size());
        for (var entry : p2c.entrySet()) {
            String parentId = entry.getKey();
            cf.put(parentId, parentId);
            for (String childId : entry.getValue()) {
                cf.put(childId, parentId);
            }
        }

        parentToChildren = Collections.unmodifiableMap(p2c);
        childToParent = Collections.unmodifiableMap(c2p);
        canonicalFamily = Collections.unmodifiableMap(cf);
        LOGGER.info("Loaded {} parent→children mappings ({} total children)", p2c.size(), c2p.size());
    }

    /**
     * Parses the essence-costs file. Each entry:
     * <pre>{@code
     * "ITEM_ID": {
     *   "type": "Wither",
     *   "1": 10, "2": 25, ...,
     *   "items": { "4": ["SKYBLOCK_COIN:10000"], ... }
     * }
     * }</pre>
     */
    public static void loadEssenceCosts(JsonObject json) {
        Map<String, EssenceUpgrade> upgrades = new HashMap<>(json.size());

        for (var entry : json.entrySet()) {
            JsonElement val = entry.getValue();
            if (!val.isJsonObject()) continue;

            EssenceUpgrade parsed = parseEssenceUpgrade(val.getAsJsonObject());
            if (parsed != null) upgrades.put(entry.getKey(), parsed);
        }

        essenceUpgrades = Collections.unmodifiableMap(upgrades);
        LOGGER.info("Loaded {} essence upgrade entries", upgrades.size());
    }

    private static EssenceUpgrade parseEssenceUpgrade(JsonObject obj) {
        String type = obj.has("type") ? obj.get("type").getAsString() : null;
        if (type == null) return null;

        Map<Integer, Integer> starCosts = new HashMap<>();
        Map<Integer, List<String>> starItems = new HashMap<>();
        int maxStar = 0;

        for (var field : obj.entrySet()) {
            String key = field.getKey();
            if ("type".equals(key) || "items".equals(key)) continue;
            try {
                int star = Integer.parseInt(key);
                starCosts.put(star, field.getValue().getAsInt());
                if (star > maxStar) maxStar = star;
            } catch (NumberFormatException ignored) {
                // not a numeric star key
            }
        }

        if (obj.has("items") && obj.get("items").isJsonObject()) {
            for (var itemEntry : obj.getAsJsonObject("items").entrySet()) {
                try {
                    int star = Integer.parseInt(itemEntry.getKey());
                    JsonArray arr = itemEntry.getValue().getAsJsonArray();
                    List<String> refs = new ArrayList<>(arr.size());
                    for (JsonElement e : arr) refs.add(e.getAsString());
                    starItems.put(star, Collections.unmodifiableList(refs));
                } catch (NumberFormatException ignored) {
                    // not a numeric star key
                }
            }
        }

        if (starCosts.isEmpty()) return null;

        return new EssenceUpgrade(
                type,
                Collections.unmodifiableMap(starCosts),
                Collections.unmodifiableMap(starItems),
                maxStar);
    }

    /** Parses {@code { "items": { "combat": [...], "farming": [...], ... } }}. */
    public static void loadMuseum(JsonObject json) {
        if (!json.has("items") || !json.get("items").isJsonObject()) {
            LOGGER.warn("museum.json missing 'items' object");
            return;
        }

        JsonObject items = json.getAsJsonObject("items");
        Map<String, List<String>> cats = new HashMap<>(items.size());
        Map<String, String> reverse = new HashMap<>(1024);

        for (var entry : items.entrySet()) {
            JsonElement val = entry.getValue();
            if (!val.isJsonArray()) continue;

            String wing = entry.getKey();
            List<String> ids = new ArrayList<>();
            for (JsonElement e : val.getAsJsonArray()) {
                String id = e.getAsString();
                ids.add(id);
                reverse.put(id, wing);
            }
            cats.put(wing, Collections.unmodifiableList(ids));
        }

        museumCategories = Collections.unmodifiableMap(cats);
        itemToMuseumWing = Collections.unmodifiableMap(reverse);
        LOGGER.info("Loaded {} museum wings ({} total items)", cats.size(), reverse.size());
    }

    /** Parses {@code { "pet_types": { "ROCK": "MINING", ... } }}. */
    public static void loadPetTypes(JsonObject json) {
        if (!json.has("pet_types") || !json.get("pet_types").isJsonObject()) {
            LOGGER.warn("pets.json missing 'pet_types' object");
            return;
        }

        JsonObject types = json.getAsJsonObject("pet_types");
        Map<String, String> map = new HashMap<>(types.size());
        for (var entry : types.entrySet()) {
            map.put(entry.getKey(), entry.getValue().getAsString());
        }

        petTypes = Collections.unmodifiableMap(map);
        LOGGER.info("Loaded {} pet type mappings", map.size());
    }

    /** Delegates to {@link PetStatResolver#load}. */
    public static void loadPetNums(JsonObject json) {
        PetStatResolver.load(json);
    }

    /** Parses {@code reforges.json}. */
    public static void loadReforges(JsonObject json) {
        Map<String, ReforgeData> map = new HashMap<>(json.size());
        for (var entry : json.entrySet()) {
            JsonElement val = entry.getValue();
            if (!val.isJsonObject()) continue;
            ReforgeData parsed = parseReforgeData(val.getAsJsonObject());
            if (parsed != null) map.put(entry.getKey(), parsed);
        }
        reforges = Collections.unmodifiableMap(map);
        LOGGER.info("Loaded {} blacksmith reforges", map.size());
    }

    /** Parses {@code reforgestones.json}. */
    public static void loadReforgeStones(JsonObject json) {
        Map<String, ReforgeStoneData> map = new HashMap<>(json.size());
        for (var entry : json.entrySet()) {
            JsonElement val = entry.getValue();
            if (!val.isJsonObject()) continue;
            ReforgeStoneData parsed = parseReforgeStoneData(val.getAsJsonObject());
            if (parsed != null) map.put(entry.getKey(), parsed);
        }
        reforgeStones = Collections.unmodifiableMap(map);
        LOGGER.info("Loaded {} reforge stones", map.size());
    }

    private static ReforgeData parseReforgeData(JsonObject obj) {
        String reforgeName = JsonUtil.getString(obj, "reforgeName");
        String itemTypes = JsonUtil.getString(obj, "itemTypes");
        if (reforgeName == null || itemTypes == null) return null;

        List<String> requiredRarities = List.of(JsonUtil.getStringArray(obj, "requiredRarities"));
        Map<String, Map<String, Double>> stats = parseReforgeStats(obj.get("reforgeStats"));
        Optional<String> nbtModifier = Optional.ofNullable(JsonUtil.getString(obj, "nbtModifier"));

        return new ReforgeData(reforgeName, itemTypes, requiredRarities, stats, nbtModifier);
    }

    private static ReforgeStoneData parseReforgeStoneData(JsonObject obj) {
        String internalName = JsonUtil.getString(obj, "internalName");
        String reforgeName = JsonUtil.getString(obj, "reforgeName");
        if (internalName == null || reforgeName == null) return null;

        List<String> requiredRarities = List.of(JsonUtil.getStringArray(obj, "requiredRarities"));
        Map<String, Integer> costs = new HashMap<>();
        if (obj.has("reforgeCosts") && obj.get("reforgeCosts").isJsonObject()) {
            for (var e : obj.getAsJsonObject("reforgeCosts").entrySet()) {
                try {
                    costs.put(e.getKey(), e.getValue().getAsInt());
                } catch (NumberFormatException ignored) {}
            }
        }

        Optional<String> itemTypes = Optional.empty();
        Optional<List<String>> specificInternalNames = Optional.empty();
        Optional<List<String>> specificItemIds = Optional.empty();

        if (obj.has("itemTypes")) {
            JsonElement it = obj.get("itemTypes");
            if (it.isJsonPrimitive()) {
                itemTypes = Optional.of(it.getAsString());
            } else if (it.isJsonObject()) {
                JsonObject itObj = it.getAsJsonObject();
                if (itObj.has("internalName") && itObj.get("internalName").isJsonArray()) {
                    List<String> list = new ArrayList<>();
                    for (JsonElement el : itObj.getAsJsonArray("internalName")) {
                        if (el.isJsonPrimitive()) list.add(el.getAsString());
                    }
                    specificInternalNames = Optional.of(Collections.unmodifiableList(list));
                }
                if (itObj.has("itemId") && itObj.get("itemId").isJsonArray()) {
                    List<String> list = new ArrayList<>();
                    for (JsonElement el : itObj.getAsJsonArray("itemId")) {
                        if (el.isJsonPrimitive()) list.add(el.getAsString());
                    }
                    specificItemIds = Optional.of(Collections.unmodifiableList(list));
                }
            }
        }

        Optional<String> ability = Optional.empty();
        Map<String, String> abilityByRarity = new HashMap<>();
        if (obj.has("reforgeAbility")) {
            JsonElement ab = obj.get("reforgeAbility");
            if (ab.isJsonPrimitive()) {
                ability = Optional.of(ab.getAsString());
            } else if (ab.isJsonObject()) {
                for (var e : ab.getAsJsonObject().entrySet()) {
                    if (e.getValue().isJsonPrimitive()) {
                        abilityByRarity.put(e.getKey(), e.getValue().getAsString());
                    }
                }
            }
        }

        Map<String, Map<String, Double>> stats = parseReforgeStats(obj.get("reforgeStats"));
        Optional<String> nbtModifier = Optional.ofNullable(JsonUtil.getString(obj, "nbtModifier"));

        return new ReforgeStoneData(
                internalName, reforgeName, itemTypes,
                specificInternalNames, specificItemIds,
                requiredRarities, Collections.unmodifiableMap(costs),
                ability, Collections.unmodifiableMap(abilityByRarity),
                stats, nbtModifier);
    }

    private static Map<String, Map<String, Double>> parseReforgeStats(JsonElement el) {
        if (el == null || !el.isJsonObject()) return Map.of();
        JsonObject obj = el.getAsJsonObject();
        Map<String, Map<String, Double>> out = new HashMap<>();
        for (var rarityEntry : obj.entrySet()) {
            if (!rarityEntry.getValue().isJsonObject()) continue;
            JsonObject statObj = rarityEntry.getValue().getAsJsonObject();
            Map<String, Double> statMap = new HashMap<>();
            for (var statEntry : statObj.entrySet()) {
                try {
                    statMap.put(statEntry.getKey(), statEntry.getValue().getAsDouble());
                } catch (NumberFormatException ignored) {}
            }
            out.put(rarityEntry.getKey(), Collections.unmodifiableMap(statMap));
        }
        return Collections.unmodifiableMap(out);
    }

    /** Clears all loaded data. */
    public static void clear() {
        parentToChildren = Map.of();
        childToParent = Map.of();
        canonicalFamily = Map.of();
        essenceUpgrades = Map.of();
        museumCategories = Map.of();
        itemToMuseumWing = Map.of();
        petTypes = Map.of();
        reforges = Map.of();
        reforgeStones = Map.of();
        PetStatResolver.clear();
    }

    // ── Queries ─────────────────────────────────────────────────────────────────

    public static Collection<String> getChildren(String parentId) {
        return parentToChildren.getOrDefault(parentId, Set.of());
    }

    public static String getParent(String childId) {
        return childToParent.get(childId);
    }

    public static boolean isChild(String itemId) {
        return childToParent.containsKey(itemId);
    }

    public static EssenceUpgrade getEssenceUpgrade(String itemId) {
        return essenceUpgrades.get(itemId);
    }

    public static Map<String, EssenceUpgrade> getAllEssenceUpgrades() {
        return essenceUpgrades;
    }

    public static String getMuseumWing(String itemId) {
        return itemToMuseumWing.get(itemId);
    }

    public static String getPetType(String petId) {
        return petTypes.get(petId);
    }

    public static Map<String, ReforgeData> getAllReforges() {
        return reforges;
    }

    public static Map<String, ReforgeStoneData> getAllReforgeStones() {
        return reforgeStones;
    }

    /**
     * Returns the canonical family root for the given item ID.
     * If the item is a parent, returns itself. If it is a child, returns its parent.
     * Returns {@code null} for standalone items with no family.
     */
    public static String getCanonicalFamily(String itemId) {
        return canonicalFamily.get(itemId);
    }

    public static boolean isLoaded() {
        return !parentToChildren.isEmpty() || !essenceUpgrades.isEmpty()
                || !reforges.isEmpty() || !reforgeStones.isEmpty();
    }

    // ── Data record ─────────────────────────────────────────────────────────────

    /**
     * Immutable per-item essence upgrade data.
     *
     * @param essenceType label (e.g. {@code "Wither"}, {@code "Ice"})
     * @param starCosts   star level → essence amount required
     * @param starItems   star level → companion item refs (e.g. {@code "SKYBLOCK_COIN:10000"})
     * @param maxStar     highest defined star (not necessarily {@code starCosts.size()})
     */
    public record EssenceUpgrade(
            String essenceType,
            Map<Integer, Integer> starCosts,
            Map<Integer, List<String>> starItems,
            int maxStar) {

        public int getCost(int star) {
            return starCosts.getOrDefault(star, 0);
        }

        public List<String> getItems(int star) {
            return starItems.getOrDefault(star, List.of());
        }
    }
}