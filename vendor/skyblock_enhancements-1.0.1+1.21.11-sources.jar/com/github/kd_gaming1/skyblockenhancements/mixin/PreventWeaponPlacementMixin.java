package com.github.kd_gaming1.skyblockenhancements.mixin;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.util.HypixelLocationState;
import java.util.List;
import java.util.regex.Pattern;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2561;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Prevents Skyblock swords (e.g. Spirit Sceptre, which is a Flower) from being placed as
 * blocks. Returning {@link class_1269#field_5811} skips the block placement while still allowing
 * the game to fall through to {@code Item.use}, which sends the right-click packet to the server
 * and triggers the weapon's ability.
 */
@Mixin(class_1747.class)
public class PreventWeaponPlacementMixin {

    @Unique
    private static final Pattern PREVENT_PLACE_TYPE_LINE =
            Pattern.compile(
                    "(?:COMMON|UNCOMMON|RARE|EPIC|LEGENDARY|MYTHIC|DIVINE|VERY SPECIAL|SPECIAL)"
                            + "\\s+(?:DUNGEON\\s+)?(?:SWORD|WATERING\\s+CAN)\\b");

    @Inject(method = "useOn", at = @At("HEAD"), cancellable = true)
    private void sbe$preventWeaponPlacement(
            class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        if (!SkyblockEnhancementsConfig.preventWeaponPlacement) return;
        if (!HypixelLocationState.isOnSkyblock()) return;

        if (sbe$isBlockedItem(context.method_8041())) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }

    @Unique
    private static boolean sbe$isBlockedItem(class_1799 stack) {
        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore == null) return false;

        List<class_2561> lines = lore.comp_2400();
        for (int i = lines.size() - 1; i >= 0; i--) {
            String lineText = lines.get(i).getString();
            if ((lineText.contains("SWORD") || lineText.contains("CAN"))
                    && PREVENT_PLACE_TYPE_LINE.matcher(lineText).find()) {
                return true;
            }
        }
        return false;
    }
}