package com.github.kd_gaming1.skyblockenhancements.mixin.itemglow;

import com.github.kd_gaming1.skyblockenhancements.util.accessor.EntityRenderStateExtension;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Copies the entity UUID onto its render state so downstream mixins can identify it. */
@Mixin(class_897.class)
public class EntityRendererMixin {

    @Inject(
            method = "createRenderState(Lnet/minecraft/world/entity/Entity;F)Lnet/minecraft/client/renderer/entity/state/EntityRenderState;",
            at = @At("TAIL")
    )
    private void captureUuid(class_1297 entity, float partialTick, CallbackInfoReturnable<class_10017> cir) {
        ((EntityRenderStateExtension) cir.getReturnValue()).sbe_setUuid(entity.method_5667());
    }
}