package com.github.kd_gaming1.skyblockenhancements.mixin.itemglow;

import com.github.kd_gaming1.skyblockenhancements.util.accessor.EntityRenderStateExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.UUID;
import net.minecraft.class_10017;

/** Adds a UUID field to EntityRenderState so we can look up glow data per-entity. */
@Mixin(class_10017.class)
public class EntityRenderStateMixin implements EntityRenderStateExtension {

    @Unique
    private UUID sbe_uuid = null;

    @Override
    public UUID sbe_getUuid() { return sbe_uuid; }

    @Override
    public void sbe_setUuid(UUID uuid) { this.sbe_uuid = uuid; }
}