package com.github.kd_gaming1.skyblockenhancements.mixin.itemglow;

import com.github.kd_gaming1.skyblockenhancements.feature.ItemGlowManager;
import com.github.kd_gaming1.skyblockenhancements.util.accessor.EntityRenderStateExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_10017;
import net.minecraft.class_11658;
import net.minecraft.class_1299;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_9779;

/** Injects after visible entities are collected to apply rarity-based glow outlines on items. */
@Mixin(class_761.class)
public class LevelRendererMixin {

    @Inject(method = "extractVisibleEntities", at = @At("TAIL"))
    private void applyItemGlow(
            class_4184 camera, class_4604 frustum,
            class_9779 deltaTracker, class_11658 renderState,
            CallbackInfo ci
    ) {
        boolean hasGlowing = false;

        for (class_10017 state : renderState.field_61735) {
            if (state.field_58171 != class_1299.field_6052) continue;

            UUID uuid = ((EntityRenderStateExtension) state).sbe_getUuid();
            int color = ItemGlowManager.getGlowColorIfActive(uuid);
            if (color == -1) continue;

            state.field_61821 = color;
            hasGlowing = true;
        }

        if (hasGlowing) {
            renderState.field_61736 = true;
        }
    }
}