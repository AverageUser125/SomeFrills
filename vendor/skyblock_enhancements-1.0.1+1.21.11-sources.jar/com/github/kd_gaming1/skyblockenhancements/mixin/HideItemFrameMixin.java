package com.github.kd_gaming1.skyblockenhancements.mixin;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10040;
import net.minecraft.class_1533;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_915;

@Mixin(class_915.class)
public class HideItemFrameMixin {

    // Cache: block-position key → should hide, valid for one tick
    @Unique
    private static final Map<Long, Boolean> hideCache = new HashMap<>();
    @Unique
    private static long lastGameTime = -1;

    @Unique
    private static long blockKey(class_1533 entity) {
        class_2338 pos = entity.method_24515();
        return class_2338.method_10064(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    @Inject(method = "extractRenderState*", at = @At("RETURN"))
    private void onExtractRenderState(
            class_1533 entity,
            class_10040 state,
            float partialTick,
            CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.hideItemFrames) return;

        // Invalidate cache every 10 ticks
        long gameTime = entity.method_73183().method_75260();
        if (Math.abs(gameTime - lastGameTime) > 10) {
            hideCache.clear();
            lastGameTime = gameTime;
        }

        long key = blockKey(entity);
        Boolean cached = hideCache.get(key);
        if (cached == null) {
            class_238 box = entity.method_5829().method_1014(0.1);
            List<class_1533> framesAtPos = entity.method_73183().method_8390(class_1533.class, box, f -> !f.method_6940().method_7960());
            cached = !framesAtPos.isEmpty();
            hideCache.put(key, cached);
        }

        if (cached) {
            state.field_53333 = true;
        }
    }
}