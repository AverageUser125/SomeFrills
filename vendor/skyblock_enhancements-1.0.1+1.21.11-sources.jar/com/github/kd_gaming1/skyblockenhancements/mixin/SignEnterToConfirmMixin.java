package com.github.kd_gaming1.skyblockenhancements.mixin;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.mixin.access.AbstractSignEditScreenAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.regex.Pattern;
import net.minecraft.class_11908;
import net.minecraft.class_310;
import net.minecraft.class_7743;

/**
 * Mixin to allow confirming sign edits with Enter when a Hypixel-style input sign is detected.
 * Behavior:
 * - If `SkyblockEnhancementsConfig.enterToConfirmSign` is enabled and the user presses Enter
 *   (without Shift), this mixin can trigger the sign's confirmation action.
 * - When `enterToConfirmAllSigns` is enabled, skips the check for Hypixel input sing.
 */
@Mixin(class_7743.class)
public abstract class SignEnterToConfirmMixin {

    @Unique
    private static final Pattern HYPIXEL_CARETS_PATTERN = Pattern.compile("(?:\\^\\s*){8,}");

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void sbe$enterToConfirm(class_11908 keyEvent, CallbackInfoReturnable<Boolean> cir) {
        if (!SkyblockEnhancementsConfig.enterToConfirmSign) return;
        if (!keyEvent.method_74230()) return;
        if (keyEvent.method_74239()) return;

        class_7743 self = (class_7743) (Object) this;

        if (!SkyblockEnhancementsConfig.enterToConfirmAllSigns && !sbe$isHypixelInputSign(self)) {
            return;
        }

        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != self) return;

        ((AbstractSignEditScreenAccessor) self).sbe$invokeOnDone();
        cir.setReturnValue(true);
    }

    @Unique
    private static boolean sbe$isHypixelInputSign(class_7743 screen) {
        String[] lines = ((AbstractSignEditScreenAccessor) screen).sbe$getMessages();
        if (lines == null) return false;

        for (String line : lines) {
            if (line == null) continue;
            if (HYPIXEL_CARETS_PATTERN.matcher(line).find()) {
                return true;
            }
        }
        return false;
    }
}