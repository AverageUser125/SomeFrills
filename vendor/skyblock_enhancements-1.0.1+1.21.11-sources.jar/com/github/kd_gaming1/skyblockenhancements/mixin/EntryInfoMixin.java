package com.github.kd_gaming1.skyblockenhancements.mixin;

import com.github.kd_gaming1.skyblockenhancements.access.LightTextureAccessor;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import eu.midnightdust.lib.config.EntryInfo;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import net.minecraft.class_310;
import net.minecraft.class_765;

@Mixin(EntryInfo.class)
public class EntryInfoMixin {

    @Final
    @Shadow
    public Field field;

    @Inject(method = "updateFieldValue", at = @At("TAIL"), remap = false)
    private void onUpdateFieldValue(CallbackInfo ci) {
        if (this.field == null) return;
        if (this.field.getDeclaringClass() != SkyblockEnhancementsConfig.class) return;
        String name = this.field.getName();
        if (!name.equals("fullbrightStrength") && !name.equals("enableFullbright")) return;
        var mc = class_310.method_1551();
        if (mc.field_1773 == null) return;
        class_765 lt = mc.field_1773.method_22974();
        if (lt instanceof LightTextureAccessor accessor) {
            accessor.skyblockenhancements$markDirty();
        }
    }
}
