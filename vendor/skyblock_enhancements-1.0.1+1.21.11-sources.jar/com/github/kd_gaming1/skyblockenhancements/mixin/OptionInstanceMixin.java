package com.github.kd_gaming1.skyblockenhancements.mixin;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.util.IrisCompat;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_7172.class)
public class OptionInstanceMixin<T> {

    @Shadow @Final
    class_2561 caption;

    @Inject(method = "get", at = @At("HEAD"), cancellable = true)
    @SuppressWarnings("unchecked")
    private void overrideGamma(CallbackInfoReturnable<T> cir) {
        if (!SkyblockEnhancementsConfig.enableFullbright) return;
        if (!IrisCompat.isShadersActive() && !SkyblockEnhancementsConfig.fullbrightUseGamma) return;
        if (!(caption.method_10851() instanceof class_2588 tc)
                || !tc.method_11022().equals("options.gamma")) return;
        cir.setReturnValue((T) Double.valueOf(
                (SkyblockEnhancementsConfig.fullbrightStrength / 100.0) * 15.0));
    }
}