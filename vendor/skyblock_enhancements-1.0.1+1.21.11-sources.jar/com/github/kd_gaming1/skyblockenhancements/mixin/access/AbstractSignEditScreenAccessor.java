package com.github.kd_gaming1.skyblockenhancements.mixin.access;

import net.minecraft.class_7743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_7743.class)
public interface AbstractSignEditScreenAccessor {

    @Invoker("onDone")
    void sbe$invokeOnDone();

    @Accessor("messages")
    String[] sbe$getMessages();
}
