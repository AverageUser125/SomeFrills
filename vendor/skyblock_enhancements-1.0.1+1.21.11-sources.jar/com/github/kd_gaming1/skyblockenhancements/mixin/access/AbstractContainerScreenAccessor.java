package com.github.kd_gaming1.skyblockenhancements.mixin.access;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("leftPos")
    int sbe$getLeftPos();

    @Accessor("topPos")
    int sbe$getTopPos();

    @Accessor("imageWidth")
    int sbe$getImageWidth();

    @Accessor("imageHeight")
    int sbe$getImageHeight();
}