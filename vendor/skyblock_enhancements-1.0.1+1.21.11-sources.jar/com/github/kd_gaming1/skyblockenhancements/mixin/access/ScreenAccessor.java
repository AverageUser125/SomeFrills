package com.github.kd_gaming1.skyblockenhancements.mixin.access;

import net.minecraft.class_364;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Exposes {@link class_437#method_37066} for use outside the screen hierarchy. */
@SuppressWarnings("JavadocReference")
@Mixin(class_437.class)
public interface ScreenAccessor {

    @Invoker("removeWidget")
    void sbe$removeWidget(class_364 listener);

    @Invoker("addWidget")
    <T extends class_364 & net.minecraft.class_6379> T sbe$addWidget(T widget);
}