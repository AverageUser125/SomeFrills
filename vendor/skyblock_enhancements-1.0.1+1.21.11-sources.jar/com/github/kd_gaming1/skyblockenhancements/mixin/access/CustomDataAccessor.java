package com.github.kd_gaming1.skyblockenhancements.mixin.access;

import net.minecraft.class_2487;
import net.minecraft.class_9279;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes the private {@code tag} field of {@link class_9279} so callers can read
 * NBT values without paying for an expensive {@link class_2487#method_10553()}.
 *
 * <p>The returned tag must never be mutated — it is the live backing store shared
 * by every reference to this {@code CustomData} instance.
 */
@Mixin(class_9279.class)
public interface CustomDataAccessor {

    @Accessor("tag")
    class_2487 getRawTag();
}
