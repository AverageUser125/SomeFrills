package com.github.kd_gaming1.skyblockenhancements.mixin;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_2739;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_634;

/**
 * Suppresses conflicting POSE packets sent by the server for the local player,
 * preventing the camera from bouncing when quickly sneaking/unsneaking on high ping.
 * Other players are intentionally unaffected.
 */
@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    @Unique
    private int sbe_currentEntityId = -1;

    @Inject(method = "handleSetEntityData", at = @At("HEAD"))
    private void sbe_captureEntityId(class_2739 packet, CallbackInfo ci) {
        sbe_currentEntityId = packet.comp_1127();
    }

    @ModifyArg(
            method = "handleSetEntityData",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/syncher/SynchedEntityData;assignValues(Ljava/util/List;)V"
            ),
            index = 0
    )
    private List<class_2945.class_7834<?>> sbe_filterPose(List<class_2945.class_7834<?>> list) {
        if (!SkyblockEnhancementsConfig.noDoubleSneak) return list;

        class_310 mc = class_310.method_1551();
        // Only filter the local player
        if (mc.field_1724 == null || mc.field_1724.method_5628() != sbe_currentEntityId) return list;

        boolean sneaking = mc.field_1724.method_5715();
        return list.stream()
                .filter(e -> {
                    if (e.comp_1116() != class_2943.field_18238) return true;
                    class_4050 pose = (class_4050) e.comp_1117();
                    // Drop any server pose that contradicts our current input state.
                    // Sneaking: ignore stale STANDING (prevents bounce up)
                    // Not sneaking: ignore stale CROUCHING (prevents bounce down)
                    return sneaking ? pose != class_4050.field_18076 : pose != class_4050.field_18081;
                })
                .toList();
    }
}