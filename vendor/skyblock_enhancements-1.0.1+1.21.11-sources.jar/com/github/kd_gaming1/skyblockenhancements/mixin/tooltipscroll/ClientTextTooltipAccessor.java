package com.github.kd_gaming1.skyblockenhancements.mixin.tooltipscroll;

import net.minecraft.class_5481;
import net.minecraft.class_5683;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Provides read access to the {@code text} field of {@link class_5683}.
 */
@Mixin(class_5683.class)
public interface ClientTextTooltipAccessor {

    @Accessor
    class_5481 getText();
}