package com.github.kd_gaming1.skyblockenhancements.mixin.rrv.itemlist;

import cc.cassian.rrv.api.recipe.ItemView;
import cc.cassian.rrv.common.overlay.itemlist.view.ItemFilters;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.injection.FullStackListCache;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

@Mixin(ItemFilters.class)
public class ItemFiltersMixin {

    // ── Tooltip cache ────────────────────────────────────────────────────────────

    @Unique
    private static final Map<class_1799, List<class_2561>> sbe$tooltipCache =
            new IdentityHashMap<>(8192);

    /**
     * Caches tooltip lookups performed by {@code ItemFilters.getTooltipMatch()}.
     * Targeted explicitly at that method rather than a wildcard so the mixin stays
     * stable if RRV refactors other methods in this class.
     */
    @Redirect(
            method = "getTooltipMatch",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screens/Screen;getTooltipFromItem"
                            + "(Lnet/minecraft/client/Minecraft;Lnet/minecraft/world/item/ItemStack;)"
                            + "Ljava/util/List;")
    )
    private static List<class_2561> sbe$cachedTooltip(class_310 mc, class_1799 stack) {
        List<class_2561> cached = sbe$tooltipCache.get(stack);
        if (cached != null) return cached;
        List<class_2561> built = class_437.method_25408(mc, stack);
        sbe$tooltipCache.put(stack, built);
        return built;
    }

    // ── Display name cache ───────────────────────────────────────────────────────

    @WrapOperation(
            method = "defaultFilter",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/item/ItemStack;getDisplayName()"
                            + "Lnet/minecraft/network/chat/Component;")
    )
    private static class_2561 sbe$cachedDisplayName(
            class_1799 stack, Operation<class_2561> original) {
        return class_2561.method_43470(FullStackListCache.getLowercaseName(stack));
    }

    // ── Query pre-lowercasing ────────────────────────────────────────────────────

    @SuppressWarnings("ModifyVariableMayUseName")
    @ModifyVariable(
            method = "defaultFilter",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0,
            remap = false)
    private static String sbe$preLowercaseQuery(String query) {
        return query.toLowerCase();
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────────

    static {
        // Clear on RRV reload — stacks are replaced, old identity keys become stale
        ItemView.addClientReloadCallback(sbe$tooltipCache::clear);
    }
}