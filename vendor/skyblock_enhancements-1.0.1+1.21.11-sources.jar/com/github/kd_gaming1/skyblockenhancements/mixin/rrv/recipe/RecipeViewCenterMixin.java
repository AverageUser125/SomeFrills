package com.github.kd_gaming1.skyblockenhancements.mixin.rrv.recipe;

import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.internal.RrvViewTypeButtonReflection;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Centers the recipe viewer vertically on screen instead of pinning it to the top.
 *
 * <p>RRV hardcodes {@code topPos = 32} in {@code checkGui()}. This mixin replaces
 * that constant with {@code (height - imageHeight) / 2}.
 *
 * <p>Button repositioning is delegated to {@link RrvViewTypeButtonReflection} so the
 * mixin stays focused on layout policy, not reflection mechanics.
 *
 * <p>TODO: Remove when updating to 26.1.
 */
@Mixin(RecipeViewScreen.class)
public abstract class RecipeViewCenterMixin extends class_465<class_1703> {

    /** Tracks the last known topPos to avoid rebuilding buttons every frame. */
    @Unique
    private int sbe$lastTopPos = -1;

    /** Latches true after the first reflection failure so we log once and stop trying. */
    @Unique
    private static boolean sbe$reflectionFailed = false;

    private RecipeViewCenterMixin() {
        super(null, null, class_2561.method_43473());
    }

    @ModifyConstant(method = "checkGui", constant = @Constant(intValue = 32), remap = false)
    private int sbe$centerTopPos(int original) {
        int centered = (this.field_22790 - this.field_2779) / 2;
        return Math.max(centered, 32);
    }

    @Inject(method = "checkGui", at = @At("TAIL"), remap = false)
    private void sbe$fixViewTypeButtonPositions(CallbackInfo ci) {
        if (sbe$reflectionFailed || this.field_2800 == sbe$lastTopPos) return;
        sbe$lastTopPos = this.field_2800;

        try {
            RrvViewTypeButtonReflection.rebuild(
                    (RecipeViewScreen) (Object) this,
                    (RecipeViewMenu) this.method_17577(),
                    this.field_22789, this.field_2800);
        } catch (RrvViewTypeButtonReflection.ReflectionFailure e) {
            SkyblockEnhancements.LOGGER.error(
                    "[SBE] Failed to reposition RRV buttons. This usually means RRV updated "
                            + "and changed internal names. Please report it on: "
                            + "https://fluxer.gg/3jJy9cp6");
            SkyblockEnhancements.LOGGER.error("[SBE] Error details: ", e);
            sbe$reflectionFailed = true;
        }
    }
}
