package com.github.kd_gaming1.skyblockenhancements.mixin.rrv.itemlist;

import cc.cassian.rrv.common.overlay.OverlayManager;
import cc.cassian.rrv.common.overlay.itemlist.view.ItemViewOverlay;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.RrvCompat;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.category.SkyblockCategoryFilter;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.category.SkyblockCategoryState;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.injection.FullStackListCache;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;

/**
 * Per-stack highlighting for RRV item-filter mode.
 *
 * <p>A slot is dimmed unless it passes <b>all</b> active filters:
 * <ol>
 *   <li>Category button / search-prefix category (if active)</li>
 *   <li>Text query — name + SkyBlock ID, plus optional full-tooltip scan</li>
 * </ol>
 *
 * <p>Tooltip generation is skipped entirely when the config is {@code NAME_AND_ID}.
 * When {@code FULL_TOOLTIP} is active, results are memoised per {@link class_1799}
 * instance so duplicate slots only pay the cost once per frame.
 */
@Mixin(value = ItemViewOverlay.class, remap = false)
public abstract class RrvItemHighlightMixin {

    @Unique private static final int SLOT_SIZE = 18;
    @Unique private static final int DIM_OVERLAY_COLOR = 0x80000000;
    @Unique private static final char FORMATTING_CHAR = '§';

    @Unique private final IdentityHashMap<class_1799, String> sbe$nameCache = new IdentityHashMap<>();
    @Unique private final IdentityHashMap<class_1799, Boolean> sbe$tooltipCache = new IdentityHashMap<>();

    @Inject(method = "renderItemHighlighting", at = @At("HEAD"), cancellable = true, remap = false)
    private void sbe$renderItemHighlighting(
            class_465<?> screen,
            class_332 guiGraphics,
            int mouseX, int mouseY, float partialTicks,
            CallbackInfo ci) {

        if (!RrvCompat.isActive()) return;

        ItemViewOverlay self = (ItemViewOverlay) (Object) this;
        if (!self.isItemFilterMode()) return;

        String query    = self.getCurrentQuery();
        var category    = SkyblockCategoryState.getActiveCategory();
        String subCat   = SkyblockCategoryState.getActiveSubCategory();

        boolean hasQuery    = query != null && !query.isBlank();
        boolean hasCategory = category != null;

        if (!hasQuery && !hasCategory) return;

        // Pre-lowercase once; all haystack comparisons use String.contains() directly.
        String normalized = hasQuery ? query.toLowerCase(Locale.ROOT).trim() : null;

        class_310 mc  = class_310.method_1551();
        int left      = OverlayManager.INSTANCE.currentInfo().leftPos() - 1;
        int top       = OverlayManager.INSTANCE.currentInfo().topPos() - 1;

        // Clear reused maps rather than allocating new ones each frame.
        sbe$nameCache.clear();
        sbe$tooltipCache.clear();

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(left, top);

        for (class_1735 slot : screen.method_17577().field_7761) {
            if (!slot.method_7682() || !slot.method_51306()) continue;

            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) {
                guiGraphics.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + SLOT_SIZE, slot.field_7872 + SLOT_SIZE, DIM_OVERLAY_COLOR);
                continue;
            }

            boolean visible = !hasCategory || SkyblockCategoryFilter.matches(stack, category, subCat);
            if (visible && hasQuery && !sbe$matchesSearch(stack, normalized, mc)) {
                visible = false;
            }

            if (!visible) {
                guiGraphics.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + SLOT_SIZE, slot.field_7872 + SLOT_SIZE, DIM_OVERLAY_COLOR);
            }
        }

        guiGraphics.method_51448().popMatrix();
        ci.cancel();
    }

    // ── Search matching ──────────────────────────────────────────────────────────

    @Unique
    private boolean sbe$matchesSearch(class_1799 stack, String query, class_310 mc) {
        if (sbe$matchesNameOrId(stack, query)) return true;

        if (SkyblockEnhancementsConfig.rrvSearchMode
                == SkyblockEnhancementsConfig.RrvSearchMode.NAME_AND_ID) return false;

        return sbe$tooltipCache.computeIfAbsent(stack, s -> sbe$tooltipContains(s, query, mc));
    }

    @Unique
    private boolean sbe$matchesNameOrId(class_1799 stack, String query) {
        // computeIfAbsent pays stripFormatting + toLowerCase only once per stack per frame.
        String name = sbe$nameCache.computeIfAbsent(
                stack,
                s -> stripFormatting(s.method_7964().getString()).toLowerCase(Locale.ROOT));

        if (name.contains(query)) return true;

        String id = FullStackListCache.getCachedId(stack);
        // getCachedId may already return lowercase; if not, lowercase it once here too.
        return id != null && id.toLowerCase(Locale.ROOT).contains(query);
    }

    @Unique
    private boolean sbe$tooltipContains(class_1799 stack, String query, class_310 mc) {
        List<class_2561> lines;
        try {
            lines = class_437.method_25408(mc, stack);
        } catch (Exception e) {
            return false;
        }
        for (class_2561 line : lines) {
            if (stripFormatting(line.getString()).toLowerCase(Locale.ROOT).contains(query)) return true;
        }
        return false;
    }

    // ── Text utilities ────────────────────────────────────────────────────────────

    @Unique
    private static String stripFormatting(String text) {
        if (text == null || text.indexOf(FORMATTING_CHAR) == -1) {
            return text == null ? "" : text;
        }
        char[] chars = text.toCharArray();
        StringBuilder out = new StringBuilder(chars.length);
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == FORMATTING_CHAR && i + 1 < chars.length) {
                i++;
                continue;
            }
            out.append(chars[i]);
        }
        return out.toString();
    }
}