package com.github.kd_gaming1.skyblockenhancements.mixin.rrv.itemlist;

import cc.cassian.rrv.common.overlay.ItemSlot;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.RrvCompat;
import com.github.kd_gaming1.skyblockenhancements.repo.item.ItemStackBuilder;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import com.github.kd_gaming1.skyblockenhancements.feature.missingenchants.MissingEnchants;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Caches the tooltip generated for the hovered {@link ItemSlot} to avoid invoking all registered
 * {@code ItemTooltipCallback} listeners on every render frame for the same unchanged item.
 *
 * <p>Additionally triggers lazy skin loading for skull items on first tooltip build,
 * and sets {@link RrvCompat#enterOverlayTooltip()} for the duration so that features
 * like {@link MissingEnchants} can skip work not meaningful for overlay hovers.
 */
@Mixin(value = ItemSlot.class, remap = false)
public class ItemSlotTooltipMixin {

    @Unique private static class_1799 sbe$lastHoveredStack = null;
    @Unique private static List<class_2561> sbe$cachedTooltip = List.of();

    /**
     * Redirects the per-frame {@code Screen.getTooltipFromItem()} call inside {@code
     * ItemSlot.render()} to a single-entry identity cache. On a cache miss the tooltip
     * is rebuilt with the overlay-context flag set, and skull skins are lazily loaded.
     */
    @Redirect(
            method = "render",
            at =
            @At(
                    value = "INVOKE",
                    target =
                            "Lnet/minecraft/client/gui/screens/Screen;getTooltipFromItem"
                                    + "(Lnet/minecraft/client/Minecraft;Lnet/minecraft/world/item/ItemStack;)"
                                    + "Ljava/util/List;"),
            remap = true)
    private List<class_2561> sbe$cacheHoveredTooltip(class_310 minecraft, class_1799 itemStack) {
        if (!RrvCompat.isActive()) {
            return class_437.method_25408(minecraft, itemStack);
        }
        if (itemStack != sbe$lastHoveredStack) {
            sbe$lastHoveredStack = itemStack;

            // Trigger lazy skin fetch for skull items on first hover.
            ItemStackBuilder.ensureSkinLoaded(itemStack);

            RrvCompat.enterOverlayTooltip();
            try {
                sbe$cachedTooltip = class_437.method_25408(minecraft, itemStack);
            } finally {
                RrvCompat.exitOverlayTooltip();
            }
        }
        return sbe$cachedTooltip;
    }
}