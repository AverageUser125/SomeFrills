package com.github.kd_gaming1.skyblockenhancements.mixin.chat;

import com.github.kd_gaming1.skyblockenhancements.access.SBEChatAccess;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.menu.ChatContextMenu;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.menu.ChatMessageResolver;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Wires a right-click chat context menu into {@link class_408}. The actual menu lives in
 * {@link ChatContextMenu}; this mixin only forwards events.
 */
@Mixin(class_408.class)
public abstract class ChatContextMenuMixin extends class_437 {

    @Unique
    private static final int MOUSE_BUTTON_LEFT = 0;
    @Unique
    private static final int MOUSE_BUTTON_RIGHT = 1;

    @Unique private final ChatContextMenu sbe$contextMenu = new ChatContextMenu();

    protected ChatContextMenuMixin(class_2561 title) { super(title); }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void sbe$onMouseClicked(
            class_11909 event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {

        if (!SkyblockEnhancementsConfig.enableChatContextMenu) return;

        int button = event.method_74245();
        double x = event.comp_4798();
        double y = event.comp_4799();

        // Left-click inside an open menu: route to the menu's button dispatcher.
        if (button == MOUSE_BUTTON_LEFT && sbe$contextMenu.isOpen()) {
            if (sbe$contextMenu.mouseClicked(x, y, button)) {
                cir.setReturnValue(true);
            }
            return;
        }

        if (button != MOUSE_BUTTON_RIGHT) return;

        class_303 message = ChatMessageResolver.resolve(y);
        if (message == null) {
            sbe$contextMenu.close();
            return;
        }

        if (SkyblockEnhancementsConfig.rightClickChatCopies) {
            sbe$directCopy(message, (int) x, (int) y);
        } else {
            sbe$contextMenu.open(message, (int) x, (int) y, this.field_22789, this.field_22790);
        }
        cir.setReturnValue(true);
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void sbe$onKeyPressed(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (event.comp_4795() == GLFW.GLFW_KEY_ESCAPE && sbe$contextMenu.isOpen()) {
            sbe$contextMenu.close();
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void sbe$renderContextMenu(
            class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        sbe$contextMenu.render(graphics, mouseX, mouseY, partialTick);
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void sbe$closeMenuOnRemoved(CallbackInfo ci) {
        sbe$contextMenu.close();
    }

    /** Direct copy path: flash the outline briefly, copy raw text, show the toast. */
    @Unique
    private void sbe$directCopy(class_303 message, int x, int y) {
        class_310 mc = class_310.method_1551();
        SBEChatAccess access = (SBEChatAccess) mc.field_1705.method_1743();

        access.sbe$getLineTracker().setSelectedMessage(message);
        mc.field_1774.method_1455(ChatMessageResolver.toRawText(message.comp_893()));
        sbe$contextMenu.notifyCopied(x, y);

        // One-frame flash then clear — the selection is purely visual here.
        mc.method_63588(() -> access.sbe$getLineTracker().setSelectedMessage(null));
    }
}