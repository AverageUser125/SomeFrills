package com.github.kd_gaming1.skyblockenhancements.mixin.chat.search;

import com.github.kd_gaming1.skyblockenhancements.access.SBEChatAccess;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.ChatFeatureState;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.search.ChatSearchController;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.search.ChatSearchTheme;
import net.minecraft.class_11908;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds a borderless search bar to {@link class_408}, toggled with Ctrl+F or kept always-on
 * per config. Layout and colours live in {@link ChatSearchTheme}; query and filter state live
 * in {@link ChatSearchController}. This mixin is just the presentation layer.
 */
@Mixin(class_408.class)
public abstract class ChatSearchScreenMixin extends class_437 {

    @Unique
    private static final int SEARCH_INPUT_MAX_LEN = 128;

    @Shadow protected class_342 input;

    @Unique private class_342 sbe$searchBox;
    @Unique private String sbe$pendingQuery;
    @Unique private long sbe$hintShownAt = -1L;

    protected ChatSearchScreenMixin(class_2561 title) { super(title); }

    // ── Lifecycle ────────────────────────────────────────────────────────

    @Inject(method = "init", at = @At("TAIL"))
    private void sbe$initSearchBar(CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.enableChatSearch) return;

        ChatSearchController search = ChatFeatureState.get().search();

        if (!search.isActive()) {
            sbe$hintShownAt = class_156.method_658();
        }

        if (SkyblockEnhancementsConfig.alwaysShowChatSearch && !search.isActive()) {
            search.setActive(true);
        }

        if (!search.isActive()) return;

        sbe$searchBox = sbe$buildSearchBox(search);
        method_37063(sbe$searchBox);
        input.method_1856(true);
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void sbe$clearSearchOnClose(CallbackInfo ci) {
        ChatSearchController search = ChatFeatureState.get().search();
        if (search.isActive()) {
            search.setActive(false);
            sbe$refreshChat();
        }
    }

    // ── Keys ─────────────────────────────────────────────────────────────

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void sbe$handleSearchKeys(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (!SkyblockEnhancementsConfig.enableChatSearch) return;

        int key = event.comp_4795();
        ChatSearchController search = ChatFeatureState.get().search();

        if (key == GLFW.GLFW_KEY_F && event.method_74240()) {
            sbe$toggleSearch();
            cir.setReturnValue(true);
            return;
        }

        if (key == GLFW.GLFW_KEY_ESCAPE && search.isActive() && sbe$handleEscape(search)) {
            cir.setReturnValue(true);
        }
    }

    /** @return {@code true} if Esc was consumed; {@code false} to let the screen close. */
    @Unique
    private boolean sbe$handleEscape(ChatSearchController search) {
        // First press with text: clear the query but keep the bar open.
        if (sbe$searchBox != null && !sbe$searchBox.method_1882().isEmpty()) {
            sbe$searchBox.method_1852("");
            search.setQuery("");
            sbe$refreshChat();
            return true;
        }
        // Pinned bar with empty query: defer to the screen so Esc closes chat.
        if (SkyblockEnhancementsConfig.alwaysShowChatSearch) {
            return false;
        }
        sbe$closeSearch();
        return true;
    }

    // ── Rendering ────────────────────────────────────────────────────────

    @Inject(method = "render", at = @At("HEAD"))
    private void sbe$renderSearchBackground(
            class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.enableChatSearch) return;
        if (!ChatFeatureState.get().search().isActive() || sbe$searchBox == null) return;

        int y = ChatSearchTheme.searchBarY(field_22790);
        int x1 = 2, x2 = field_22789 - 2;
        int y1 = y - 2, y2 = y + ChatSearchTheme.SEARCH_BAR_HEIGHT + 2;

        graphics.method_25294(x1, y1, x2, y2, ChatSearchTheme.BACKGROUND);
        // 1px outline
        graphics.method_25294(x1, y1, x2, y1 + 1, ChatSearchTheme.BORDER);
        graphics.method_25294(x1, y2 - 1, x2, y2, ChatSearchTheme.BORDER);
        graphics.method_25294(x1, y1, x1 + 1, y2, ChatSearchTheme.BORDER);
        graphics.method_25294(x2 - 1, y1, x2, y2, ChatSearchTheme.BORDER);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void sbe$renderSearchHint(
            class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.enableChatSearch) return;
        if (ChatFeatureState.get().search().isActive() || sbe$hintShownAt < 0) return;

        long elapsed = class_156.method_658() - sbe$hintShownAt;
        if (elapsed >= ChatSearchTheme.HINT_DURATION_MS) return;

        int alpha = sbe$fadeAlpha(elapsed);
        String hintText = "Ctrl+F to search";
        int textWidth = field_22793.method_1727(hintText);
        int inputY = field_22790 - 14;
        int x = field_22789 - textWidth - 6;
        int y = inputY - field_22793.field_2000 - 3;

        graphics.method_25294(x - 3, y - 2, x + textWidth + 3, y + field_22793.field_2000 + 2, (alpha / 2) << 24);
        int color = (alpha << 24) | ChatSearchTheme.HINT_RGB;
        graphics.method_51433(field_22793, hintText, x, y, color, false);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void sbe$renderMatchCount(
            class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.enableChatSearch) return;

        ChatSearchController search = ChatFeatureState.get().search();
        if (!search.isActive() || sbe$searchBox == null || !search.isFiltering()) return;

        SBEChatAccess access = (SBEChatAccess) class_310.method_1551().field_1705.method_1743();
        int total = access.sbe$getAllMessages().size();
        int matching = search.countMatching(access.sbe$getAllMessages(), access.sbe$getLineTracker());
        String info = matching + "/" + total;
        int infoWidth = field_22793.method_1727(info);
        int infoX = sbe$searchBox.method_46426() + sbe$searchBox.method_25368() - infoWidth - 4;
        int infoY = ChatSearchTheme.searchBarY(field_22790)
                + (ChatSearchTheme.SEARCH_BAR_HEIGHT - 8) / 2;
        graphics.method_51433(field_22793, info, infoX, infoY, ChatSearchTheme.MATCH_COUNT_TEXT, false);
    }

    @Unique
    private static int sbe$fadeAlpha(long elapsed) {
        long fadeStart = ChatSearchTheme.HINT_DURATION_MS - ChatSearchTheme.HINT_FADE_MS;
        float alpha = elapsed < fadeStart
                ? 1f
                : 1f - (elapsed - fadeStart) / (float) ChatSearchTheme.HINT_FADE_MS;
        return (int) (alpha * 0xFF) & 0xFF;
    }

    // ── Internal state changes ───────────────────────────────────────────

    @Unique
    private class_342 sbe$buildSearchBox(ChatSearchController search) {
        class_310 mc = class_310.method_1551();
        int y = ChatSearchTheme.searchBarY(field_22790);

        class_342 box = new class_342(
                mc.field_1772, 4, y, field_22789 - 8, ChatSearchTheme.SEARCH_BAR_HEIGHT,
                class_2561.method_43470("Search chat..."));
        box.method_47404(class_2561.method_43470("Search chat... (Ctrl+F)"));
        box.method_1880(SEARCH_INPUT_MAX_LEN);
        box.method_1863(value -> sbe$onQueryChanged(search, value));
        box.method_1858(false);
        box.method_1856(true);

        if (sbe$pendingQuery != null) {
            box.method_1852(sbe$pendingQuery);
            sbe$pendingQuery = null;
        } else {
            box.method_1852(search.getQuery());
        }
        return box;
    }

    @Unique
    private void sbe$toggleSearch() {
        ChatSearchController search = ChatFeatureState.get().search();
        if (!search.isActive()) {
            sbe$openSearch();
            return;
        }
        if (!SkyblockEnhancementsConfig.alwaysShowChatSearch) {
            sbe$closeSearch();
            return;
        }
        sbe$pingPongFocus();
    }

    @Unique
    private void sbe$openSearch() {
        ChatFeatureState.get().search().setActive(true);
        sbe$pendingQuery = "";
        method_41843();
        sbe$focusSearchBox();
    }

    @Unique
    private void sbe$closeSearch() {
        ChatSearchController search = ChatFeatureState.get().search();
        search.setActive(false);
        search.setQuery("");
        sbe$pendingQuery = null;
        sbe$refreshChat();
        method_41843();
        input.method_1856(false);
        sbe$focusInput();
    }

    @Unique
    private void sbe$onQueryChanged(ChatSearchController search, String query) {
        search.setQuery(query);
        sbe$refreshChat();
    }

    @Unique
    private void sbe$refreshChat() {
        class_310 mc = class_310.method_1551();
        mc.field_1705.method_1743().method_1820();
        ((SBEChatAccess) mc.field_1705.method_1743()).sbe$refreshMessages();
    }

    // ── Focus helpers ────────────────────────────────────────────────────

    @Unique
    private void sbe$focusSearchBox() {
        if (sbe$searchBox == null) return;
        method_25395(sbe$searchBox);
        sbe$searchBox.method_25365(true);
        input.method_25365(false);
    }

    @Unique
    private void sbe$focusInput() {
        method_25395(input);
        input.method_25365(true);
        if (sbe$searchBox != null) sbe$searchBox.method_25365(false);
    }

    @Unique
    private void sbe$pingPongFocus() {
        if (sbe$searchBox == null) return;
        if (sbe$searchBox.method_25370()) sbe$focusInput();
        else sbe$focusSearchBox();
    }
}