package com.github.kd_gaming1.skyblockenhancements.mixin.chat;

import com.github.kd_gaming1.skyblockenhancements.compat.rrv.RrvCompat;
import net.minecraft.class_2561;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Suppresses the Firmament "RoughlyEnoughItems" download warning when RRV is present.
 *
 * This mixin cancels the chat addMessage call for messages that look like the Firmament
 * REI prompt. We only do this when RRV is installed so other users still see the warning.
 */
@Mixin(value = class_338.class, priority = 2000)
public abstract class FirmamentWarningMixin {

    @Inject(
            method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("HEAD"),
            cancellable = true)
    private void sbe$maybeSuppressFirmament(class_2561 message, class_7469 signature, class_7591 tag, CallbackInfo ci) {
        // Only suppress when RRV is installed — otherwise leave Firmament's warning alone.
        if (!RrvCompat.isRrvPresent()) return;

        if (message == null) return;

        String text = message.getString();

        // Match the unique prefix used by Firmament's warning. Keep this check simple and
        // forgiving (contains) to handle minor formatting/localization differences.
        if (text.contains("Firmament needs RoughlyEnoughItems")) {
            ci.cancel();
        }
    }
}

