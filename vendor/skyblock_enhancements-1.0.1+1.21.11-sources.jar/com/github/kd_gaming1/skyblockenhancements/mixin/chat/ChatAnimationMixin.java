package com.github.kd_gaming1.skyblockenhancements.mixin.chat;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Slides newly-arriving chat messages up into view instead of popping them in instantly.
 *
 * <p>Only triggers when the chat is scrolled to the bottom and the incoming message actually
 * added visible lines (filtered-out messages don't animate).
 *
 * <p>Inspired by Ezzenix's ChatAnimation (CC-BY-NC-SA 4.0); this is an original implementation.
 */
@Mixin(class_338.class)
public abstract class ChatAnimationMixin {

    @Unique
    private static final float ANIMATION_LINE_FACTOR = 0.8f;

    @Shadow private int chatScrollbarPos;
    @Shadow @Final private List<class_303.class_7590> trimmedMessages;
    @Shadow protected abstract int getLineHeight();

    @Unique private long sbe$lastMessageTime;
    @Unique private int sbe$displaySizeBefore;
    @Unique private boolean sbe$animationIdle = true;

    @Unique
    private float sbe$displacement() {
        if (!SkyblockEnhancementsConfig.enableChatAnimation || chatScrollbarPos != 0) return 0f;
        if (sbe$animationIdle) return 0f;

        int duration = SkyblockEnhancementsConfig.chatAnimationDurationMs;
        float elapsed = System.currentTimeMillis() - sbe$lastMessageTime;
        if (elapsed >= duration) {
            sbe$animationIdle = true;
            return 0f;
        }
        float progress = elapsed / (float) duration;
        float eased = 1f - (1f - progress) * (1f - progress); // ease-out quadratic
        return getLineHeight() * ANIMATION_LINE_FACTOR * (1f - eased);
    }

    @WrapOperation(
            method = "render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/gui/Font;IIIZZ)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/ChatComponent;"
                            + "render(Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;IIZ)V"))
    private void sbe$animateRender(
            class_338 instance,
            class_338.class_12233 access,
            int i, int j, boolean bl,
            Operation<Void> original,
            @Local(argsOnly = true) class_332 graphics) {

        float dy = sbe$displacement();
        if (dy != 0f) {
            graphics.method_51448().pushMatrix();
            graphics.method_51448().translate(0f, dy);
        }
        original.call(instance, access, i, j, bl);
        if (dy != 0f) graphics.method_51448().popMatrix();
    }

    @Inject(
            method = "addMessage(Lnet/minecraft/network/chat/Component;"
                    + "Lnet/minecraft/network/chat/MessageSignature;"
                    + "Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("HEAD"))
    private void sbe$snapshotDisplaySize(
            class_2561 message, class_7469 sig, class_7591 tag, CallbackInfo ci) {
        sbe$displaySizeBefore = trimmedMessages.size();
    }

    @Inject(
            method = "addMessage(Lnet/minecraft/network/chat/Component;"
                    + "Lnet/minecraft/network/chat/MessageSignature;"
                    + "Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("TAIL"))
    private void sbe$recordMessageTime(
            class_2561 message, class_7469 sig, class_7591 tag, CallbackInfo ci) {
        // Only start a new animation if the message actually produced visible lines.
        if (trimmedMessages.size() > sbe$displaySizeBefore) {
            sbe$lastMessageTime = System.currentTimeMillis();
            sbe$animationIdle = false;
        }
    }
}