package com.github.kd_gaming1.skyblockenhancements.mixin.chat.tab;

import com.daqem.uilib.gui.widget.CustomButtonWidget;
import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.ChatFeatureState;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.search.ChatSearchTheme;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.tabs.ChatTab;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.tabs.ChatTabController;
import com.github.kd_gaming1.skyblockenhancements.feature.chat.tabs.ChatTabSprites;
import com.github.kd_gaming1.skyblockenhancements.util.HypixelLocationState;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_8666;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Adds Hypixel channel tab buttons above the chat input field. */
@Mixin(class_408.class)
public abstract class ChatTabScreenMixin extends class_437 {

    @Unique
    private static final int TAB_HEIGHT = 15;
    @Unique
    private static final int TAB_SPACING = 1;
    @Unique
    private static final int TAB_LABEL_PADDING = 10;
    @Unique
    private static final int TAB_BOTTOM_MARGIN = 14;

    @Shadow protected class_342 input;

    protected ChatTabScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void sbe$addTabButtons(CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.enableChatTabs || !HypixelLocationState.isOnHypixel()) {
            return;
        }

        class_310 mc = class_310.method_1551();
        class_338 chat = mc.field_1705.method_1743();
        ChatTabController tabs = ChatFeatureState.get().tabs();

        int tabY = field_22790 - TAB_BOTTOM_MARGIN - TAB_HEIGHT - ChatSearchTheme.extraOffset();
        int x = 2;

        for (ChatTab tab : ChatTab.values()) {
            int width = Math.max(TAB_HEIGHT, mc.field_1772.method_1727(tab.label()) + TAB_LABEL_PADDING);
            method_37063(sbe$buildTabButton(tab, tabs, chat, mc, x, tabY, width));
            x += width + TAB_SPACING;
        }
    }

    @Inject(method = "keyPressed", at = @At("RETURN"))
    private void sbe$restoreInputFocusAfterHistoryNav(
            class_11908 keyEvent, CallbackInfoReturnable<Boolean> cir) {
        int key = keyEvent.comp_4795();
        if ((key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN) && method_25399() != input) {
            method_25395(input);
        }
    }

    // ---------------------------------------------------------------------
    // Button factory
    // ---------------------------------------------------------------------

    @Unique
    private CustomButtonWidget sbe$buildTabButton(
            ChatTab tab, ChatTabController tabs, class_338 chat, class_310 mc,
            int x, int y, int width) {

        boolean active = tabs.getActiveTab() == tab;
        class_8666 sprites = active ? ChatTabSprites.ACTIVE : ChatTabSprites.INACTIVE;

        CustomButtonWidget button = new CustomButtonWidget(
                x, y, width, TAB_HEIGHT,
                class_2561.method_43470(tab.label()),
                sprites,
                ignored -> sbe$onTabClicked(tab, tabs, chat, mc));

        button.method_48591(Integer.MAX_VALUE);
        return button;
    }

    @Unique
    private void sbe$onTabClicked(
            ChatTab tab, ChatTabController tabs, class_338 chat, class_310 mc) {
        boolean wasAlreadyActive = tabs.getActiveTab() == tab;
        tabs.setActiveTab(tab);
        chat.method_1817();
        method_41843();

        if (!ChatFeatureState.get().search().isActive()
                || SkyblockEnhancementsConfig.alwaysShowChatSearch) {
            mc.method_63588(() -> method_25395(input));
        }

        if (wasAlreadyActive) return;

        String cmd = tab.command();
        if (!cmd.isEmpty() && mc.field_1724 != null) {
            if (cmd.startsWith("/")) {
                mc.field_1724.field_3944.method_45730(cmd.substring(1));
            } else {
                mc.field_1724.field_3944.method_45729(cmd);
            }
        }
    }
}