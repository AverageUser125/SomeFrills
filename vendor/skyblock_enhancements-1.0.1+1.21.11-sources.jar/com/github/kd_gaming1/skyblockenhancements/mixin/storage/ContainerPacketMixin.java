package com.github.kd_gaming1.skyblockenhancements.mixin.storage;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.StorageData;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.StorageOverlayLifecycle;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.StoragePageSlot;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.StorageTitleParser;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.VirtualInventory;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2649;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Re-captures storage page data when the server sends a full container contents update.
 * This fixes the race condition where {@code init} fires before slot items have arrived.
 */
@Mixin(class_634.class)
public class ContainerPacketMixin {

    @Inject(method = "handleContainerContent", at = @At("TAIL"))
    private void sbe$onContainerContent(class_2649 packet, CallbackInfo ci) {
        if (!SkyblockEnhancementsConfig.enableStorageDashboard_Test) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;

        if (!(mc.field_1755 instanceof class_465<?> screen)) return;
        if (screen.method_17577().field_7763 != packet.comp_3837()) return;

        String rawTitle = screen.method_25440().getString();
        Optional<StorageTitleParser.ParsedTitle> parsed = StorageTitleParser.parse(rawTitle);
        if (parsed.isEmpty()) return;

        if (parsed.get().isOverview()) {
            StorageOverlayLifecycle.onOverviewPacketReceived(screen);
            return;
        }

        StoragePageSlot slot = parsed.get().slot();
        if (slot == null) return;

        List<class_1799> stacks = new ArrayList<>();
        for (class_1735 s : screen.method_17577().field_7761) {
            if (s.field_7871 != mc.field_1724.method_31548()) {
                while (stacks.size() <= s.field_7874) stacks.add(class_1799.field_8037);
                stacks.set(s.field_7874, s.method_7677().method_7972());
            }
        }
        int rows = Math.clamp((stacks.size() + 8) / 9, 1, 6);
        int target = rows * 9;
        while (stacks.size() < target) stacks.add(class_1799.field_8037);
        if (stacks.size() > target) stacks = stacks.subList(0, target);

        VirtualInventory vinv = new VirtualInventory(stacks);
        StorageData.INSTANCE.updateInventory(slot, rawTitle, vinv);
        StorageData.INSTANCE.markDirty(vinv.getSerializationFuture());
    }
}
