package com.github.kd_gaming1.skyblockenhancements.gui.storage;

import java.util.List;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * Delegate attached to a vanilla {@link net.minecraft.class_465}
 * to overlay custom storage rendering and input handling.
 *
 * <p>The mixin calls into this delegate at key moments instead of drawing the
 * vanilla chest foreground.
 */
public abstract class ContainerOverlay {

    /** Called once when the screen initializes (and on resize). */
    public abstract void onInit(int screenWidth, int screenHeight);

    /** Called at the start of render() before vanilla evaluates hoveredSlot. */
    public void preRender(int mouseX, int mouseY) {}

    /** Called from render() instead of drawing the vanilla foreground. */
    public abstract void render(class_332 graphics, float delta, int mouseX, int mouseY);

    /** Return false to suppress the default foreground (slot backgrounds, etc.). */
    public boolean shouldDrawForeground() {
        return false;
    }

    /** Restrict slot hit-testing. Return false to disable interaction for a slot. */
    public boolean isPointOverSlot(class_1735 slot, double pointX, double pointY) {
        return true;
    }

    /** Input delegation. Return true if consumed. */
    public boolean mouseClicked(class_11909 event, boolean doubleClick) {
        return false;
    }

    public boolean mouseReleased(class_11909 event) {
        return false;
    }

    public boolean mouseDragged(class_11909 event, double dx, double dy) {
        return false;
    }

    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        return false;
    }

    public boolean keyPressed(class_11908 event) {
        return false;
    }

    public boolean charTyped(class_11905 event) {
        return false;
    }

    /** Return the search field widget so the mixin can register it with the screen. */
    public class_342 getSearchField() {
        return null;
    }

    /** REI/JEI exclusion zones. Return rectangles the overlay occupies. */
    public abstract List<Rect> getBounds();
}
