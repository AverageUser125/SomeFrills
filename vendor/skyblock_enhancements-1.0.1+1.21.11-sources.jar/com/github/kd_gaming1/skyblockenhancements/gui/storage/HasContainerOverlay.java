package com.github.kd_gaming1.skyblockenhancements.gui.storage;

import net.minecraft.class_465;

/**
 * Interface that allows attaching a {@link ContainerOverlay} to any
 * {@link class_465} without requiring a dedicated accessor class.
 */
@SuppressWarnings("unused")
public interface HasContainerOverlay {
    ContainerOverlay skyBlock_Enhancements$getSbeOverlay();

    void skyBlock_Enhancements$setSbeOverlay(ContainerOverlay overlay);
}
