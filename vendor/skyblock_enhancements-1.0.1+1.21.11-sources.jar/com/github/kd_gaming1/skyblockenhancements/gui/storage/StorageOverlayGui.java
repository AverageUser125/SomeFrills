package com.github.kd_gaming1.skyblockenhancements.gui.storage;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.StorageData;
import com.github.kd_gaming1.skyblockenhancements.feature.storage.StoragePageSlot;
import com.github.kd_gaming1.skyblockenhancements.mixin.access.AbstractContainerScreenAccessor;
import com.github.kd_gaming1.skyblockenhancements.mixin.access.SlotAccessor;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_465;

public class StorageOverlayGui extends ContainerOverlay {

    // ── Layout constants ──────────────────────────────────────────────────────
    private static final int SLOT_SIZE     = 18;
    private static final int PAGE_WIDTH    = SLOT_SIZE * 9 + 4;
    private static final int PADDING       = 8;
    private static final int TOP_BAR_H     = 26;
    private static final int SCROLL_BAR_W  = 6;
    private static final int MIN_OVERLAY_H = 60;
    private static final int OVERVIEW_TOP  = SLOT_SIZE;
    private static final int INV_SLOTS_TOP = 18; // vertical space reserved for the "Inventory" label

    /**
     * Distance from the bottom of the screen to the bottom edge of the inventory section.
     * Increase to move the inventory section upward.
     */
    private static final int BOTTOM_PADDING = 20;

    // ── Colours ───────────────────────────────────────────────────────────────
    private static final int COL_OVERLAY_BG   = 0xD4080810;
    private static final int COL_PANEL_BORDER = 0xFF2E2E4A;
    private static final int COL_PAGE_BG      = 0xFF141422;
    private static final int COL_SLOT_ITEM    = 0xFF22223A;
    private static final int COL_SLOT_TL      = 0xFF0F0F1E;
    private static final int COL_SLOT_BR      = 0xFF3A3A5C;
    private static final int COL_SLOT_HOVER   = 0x60FFFFFF;
    private static final int COL_TITLE_ACTIVE = 0xFFFFD700;
    private static final int COL_TITLE_IDLE   = 0xFFAAAAAA;
    private static final int COL_PLACEHOLDER  = 0xFF55556A;

    // ── References ────────────────────────────────────────────────────────────
    private final class_465<?> screen;
    private final AbstractContainerScreenAccessor accessor;
    private final StoragePageSlot activeSlot;
    private final class_310 mc;

    /**
     * Vanilla's topPos at init time. All screen-space Y calculations anchor here.
     * Never mutated — we push slots via slot.y instead.
     */
    private int baseTopPos;

    /**
     * Captured slot.y values (relative to topPos) before any push, preserving
     * the vanilla hotbar gap between the main grid and hotbar rows.
     */
    private int[] originalPlayerSlotRelY;

    /** Pixels added to each player slot.y so vanilla renders items inside our panel. */
    private int playerPush;

    // ── Layout state ──────────────────────────────────────────────────────────
    private int pageWidthCount;
    private int overviewX, overviewWidth, overviewHeight;
    private int innerScrollPanelWidth, innerScrollPanelHeight;
    private int invPanelX, invPanelY, invPanelW, invPanelH;

    // ── Scroll state ──────────────────────────────────────────────────────────
    private float scroll;
    private int lastRenderedContentH;
    private boolean knobGrabbed;

    // ── Search state ──────────────────────────────────────────────────────────
    private class_342 searchField;
    private String searchQuery = "";
    private String cachedSearchQuery;
    private Set<StoragePageSlot> cachedFilteredPages = Set.of();

    // ─────────────────────────────────────────────────────────────────────────

    public StorageOverlayGui(class_465<?> screen, StoragePageSlot activeSlot) {
        this.screen     = screen;
        this.accessor   = (AbstractContainerScreenAccessor) screen;
        this.activeSlot = activeSlot;
        this.mc         = class_310.method_1551();
    }

    // ── ContainerOverlay ──────────────────────────────────────────────────────

    @Override
    public void onInit(int screenWidth, int screenHeight) {
        ensureAllSlotsRegistered();
        baseTopPos             = accessor.sbe$getTopPos();
        originalPlayerSlotRelY = capturePlayerSlotRelY();
        recalculateMeasurements();
        scroll = clampScroll(scroll);
        initSearchField();
    }

    /**
     * Repositions chest slots onto the overlay and pushes player slots into the
     * inventory section. Vanilla renders items at (leftPos+slot.x, topPos+slot.y),
     * so adjusting slot.y is sufficient — no topPos mutation required.
     */
    @Override
    public void preRender(int mouseX, int mouseY) {
        pushPlayerSlots();
        repositionChestSlots();
    }

    @Override
    public void render(class_332 gfx, float delta, int mouseX, int mouseY) {
        drawPanel(gfx);
        drawScrollableContent(gfx, mouseX, mouseY);
        drawScrollbar(gfx);
        drawInventoryPanel(gfx);
        if (searchField != null) searchField.method_25394(gfx, mouseX, mouseY, delta);
    }

    @Override public boolean shouldDrawForeground() { return false; }

    @Override
    public List<Rect> getBounds() {
        return List.of(
                new Rect(overviewX, OVERVIEW_TOP, overviewWidth, overviewHeight),
                new Rect(invPanelX - 1, invPanelY, invPanelW + 2, invPanelH + 1));
    }

    @Override public class_342 getSearchField() { return searchField; }

    @Override
    public boolean mouseClicked(class_11909 event, boolean doubleClick) {
        if (handleSearchFieldClick(event, doubleClick)) return true;
        if (handleScrollbarClick(event)) return true;
        return handlePageClick(event);
    }

    @Override
    public boolean mouseReleased(class_11909 event) {
        if (knobGrabbed) { knobGrabbed = false; return true; }
        return false;
    }

    @Override
    public boolean mouseDragged(class_11909 event, double dx, double dy) {
        if (!knobGrabbed) return false;
        scroll = scrollForKnobY(event.comp_4799());
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        if (!getScrollPanel().contains(x, y)) return false;
        float dir = SkyblockEnhancementsConfig.storageInverseScroll ? 1f : -1f;
        scroll = clampScroll(scroll + (float) (scrollY * SkyblockEnhancementsConfig.storageScrollSpeed * dir));
        return true;
    }

    @Override
    public boolean keyPressed(class_11908 event) {
        return searchField != null && searchField.method_25370() && searchField.method_25404(event);
    }

    @Override
    public boolean charTyped(class_11905 event) {
        return searchField != null && searchField.method_25370() && searchField.method_25400(event);
    }

    // ── Layout ────────────────────────────────────────────────────────────────

    private void recalculateMeasurements() {
        pageWidthCount = Math.clamp(
                (screen.field_22789 - PADDING * 2) / (PAGE_WIDTH + PADDING),
                1, SkyblockEnhancementsConfig.storageOverlayColumns);

        innerScrollPanelWidth = PAGE_WIDTH * pageWidthCount + (pageWidthCount - 1) * PADDING;
        overviewWidth         = innerScrollPanelWidth + SCROLL_BAR_W + PADDING * 3;
        overviewX             = screen.field_22789 / 2 - overviewWidth / 2;

        invPanelX = accessor.sbe$getLeftPos();
        invPanelW = accessor.sbe$getImageWidth();

        int slotsH = originalPlayerSlotRelY[originalPlayerSlotRelY.length - 1]
                - originalPlayerSlotRelY[0] + SLOT_SIZE;
        invPanelH = INV_SLOTS_TOP + slotsH + 4;
        invPanelY = screen.field_22790 - BOTTOM_PADDING - invPanelH;

        overviewHeight         = Math.max(MIN_OVERLAY_H, invPanelY - OVERVIEW_TOP);
        innerScrollPanelHeight = overviewHeight - TOP_BAR_H - PADDING * 2;

        int targetFirstSlotScreenY  = invPanelY + INV_SLOTS_TOP;
        int vanillaFirstSlotScreenY = baseTopPos + originalPlayerSlotRelY[0];
        playerPush = targetFirstSlotScreenY - vanillaFirstSlotScreenY;
    }

    private Rect getScrollPanel() {
        return new Rect(overviewX + PADDING, OVERVIEW_TOP + TOP_BAR_H,
                innerScrollPanelWidth, innerScrollPanelHeight);
    }

    private Rect getScrollbarTrack() {
        return new Rect(overviewX + overviewWidth - PADDING - SCROLL_BAR_W,
                OVERVIEW_TOP + TOP_BAR_H, SCROLL_BAR_W, innerScrollPanelHeight);
    }

    // ── Slot repositioning ────────────────────────────────────────────────────

    private void pushPlayerSlots() {
        List<class_1735> playerSlots = getPlayerSlots();
        for (int i = 0; i < Math.min(playerSlots.size(), originalPlayerSlotRelY.length); i++) {
            ((SlotAccessor) playerSlots.get(i)).setY(originalPlayerSlotRelY[i] + playerPush);
        }
    }

    private void repositionChestSlots() {
        Rect panel      = getScrollPanel();
        Rect activeRect = findPageRect(activeSlot);
        int leftPos     = accessor.sbe$getLeftPos();

        for (class_1735 slot : screen.method_17577().field_7761) {
            if (slot.field_7871 == mc.field_1724.method_31548()) continue;

            if (activeSlot == null || activeRect == null) {
                hideSlot(slot);
                continue;
            }

            int screenX = activeRect.x + 2 + (slot.field_7874 % 9) * SLOT_SIZE;
            int screenY = activeRect.y + mc.field_1772.field_2000 + 6 + (slot.field_7874 / 9) * SLOT_SIZE - (int) scroll;
            boolean inPanel = screenY >= panel.y && screenY + SLOT_SIZE <= panel.y + panel.height;

            if (inPanel) {
                ((SlotAccessor) slot).setX(screenX - leftPos);
                ((SlotAccessor) slot).setY(screenY - baseTopPos);
            } else {
                hideSlot(slot);
            }
        }
    }

    private static void hideSlot(class_1735 slot) {
        ((SlotAccessor) slot).setX(-9999);
        ((SlotAccessor) slot).setY(-9999);
    }

    // ── Rendering ─────────────────────────────────────────────────────────────

    /**
     * Draws a stepped/T-shaped panel: the top section spans the full overlay width,
     * then steps inward at invPanelY to match the inventory width below.
     * The bottom border of the top section doubles as the horizontal step cap,
     * so no separate divider fill is needed.
     */
    private void drawPanel(class_332 gfx) {
        // Top section
        gfx.method_25294(overviewX,     OVERVIEW_TOP,     overviewX + overviewWidth,     invPanelY + 1, COL_PANEL_BORDER);
        gfx.method_25294(overviewX + 1, OVERVIEW_TOP + 1, overviewX + overviewWidth - 1, invPanelY,     COL_OVERLAY_BG);

        // Inventory section — left/right/bottom borders only; top is shared with the step above
        int iL = invPanelX - 1;
        int iR = invPanelX + invPanelW + 1;
        int iB = invPanelY + invPanelH + 1;
        gfx.method_25294(iL,     invPanelY, iR,     iB,     COL_PANEL_BORDER);
        gfx.method_25294(iL + 1, invPanelY, iR - 1, iB - 1, COL_OVERLAY_BG);
    }

    private void drawScrollableContent(class_332 gfx, int mouseX, int mouseY) {
        Rect panel = getScrollPanel();
        gfx.method_44379(panel.x, panel.y, panel.x + panel.width, panel.y + panel.height);
        gfx.method_51448().pushMatrix();
        gfx.method_51448().translate(0f, -scroll);

        forEachPage(getFilteredPages(), (rect, slot, inv) ->
                drawPage(gfx, rect, slot, inv, slot.equals(activeSlot), mouseX, mouseY, panel));

        gfx.method_51448().popMatrix();
        gfx.method_44380();
    }

    private void drawPage(class_332 gfx, Rect rect, StoragePageSlot pageSlot,
                          StorageData.StorageInventory inv, boolean isActive,
                          int mouseX, int mouseY, Rect panel) {
        int rows    = pageRows(pageSlot, inv, isActive);
        int cardH   = rows * SLOT_SIZE + mc.field_1772.field_2000 + 10;
        int cardTop = rect.y + mc.field_1772.field_2000 + 4;

        int borderColor = parseColor(isActive
                ? SkyblockEnhancementsConfig.storageActivePageOutlineColor
                : SkyblockEnhancementsConfig.storageInactivePageBorderColor);
        gfx.method_25294(rect.x,     cardTop,     rect.x + PAGE_WIDTH,     rect.y + cardH,     borderColor);
        gfx.method_25294(rect.x + 1, cardTop + 1, rect.x + PAGE_WIDTH - 1, rect.y + cardH - 1, COL_PAGE_BG);

        String title = inv != null && inv.title() != null ? inv.title() : pageSlot.defaultName();
        gfx.method_51433(mc.field_1772, title, rect.x + 4, rect.y + 2,
                isActive ? COL_TITLE_ACTIVE : COL_TITLE_IDLE, true);

        if (inv == null || inv.inventory() == null) {
            gfx.method_25300(mc.field_1772, "Not yet opened",
                    rect.x + PAGE_WIDTH / 2, rect.y + cardH / 2, COL_PLACEHOLDER);
            return;
        }

        drawSlotBackgrounds(gfx, rect, rows, isActive);

        if (!isActive) {
            drawFakeItems(gfx, rect, inv.inventory().stacks(), rows, panel, mouseX, mouseY);
        }
    }

    /**
     * @param vanillaRendered true for the active page, where vanilla places items at (x, y).
     *                        false for cached pages, where we render fake items at (x+1, y+1).
     *                        The background must be offset so the inner fill aligns with where
     *                        items and hover highlights actually land.
     */
    private void drawSlotBackgrounds(class_332 gfx, Rect pageRect, int rows, boolean vanillaRendered) {
        for (int i = 0; i < rows * 9; i++) {
            int x = pageRect.x + 2 + (i % 9) * SLOT_SIZE;
            int y = pageRect.y + mc.field_1772.field_2000 + 6 + (i / 9) * SLOT_SIZE;
            drawSlotBackground(gfx, vanillaRendered ? x - 1 : x, vanillaRendered ? y - 1 : y);
        }
    }

    private void drawFakeItems(class_332 gfx, Rect pageRect, List<class_1799> stacks,
                               int rows, Rect panel, int mouseX, int mouseY) {
        int count         = Math.min(stacks.size(), rows * 9);
        int contentMouseY = mouseY + (int) scroll;

        for (int i = 0; i < count; i++) {
            class_1799 stack = stacks.get(i);
            if (stack.method_7960()) continue;

            int slotX = pageRect.x + 2 + (i % 9) * SLOT_SIZE;
            int slotY = pageRect.y + mc.field_1772.field_2000 + 6 + (i / 9) * SLOT_SIZE;

            gfx.method_51445(stack, slotX + 1, slotY + 1);
            gfx.method_51431(mc.field_1772, stack, slotX + 1, slotY + 1);

            if (!searchQuery.isBlank() && matchesSearch(stack, searchQuery)) {
                gfx.method_25294(slotX + 1, slotY + 1, slotX + SLOT_SIZE - 1, slotY + SLOT_SIZE - 1,
                        parseColor(SkyblockEnhancementsConfig.storageSearchHighlightColor));
            }

            if (isSlotHovered(slotX, slotY, mouseX, contentMouseY, panel)) {
                gfx.method_25294(slotX + 1, slotY + 1, slotX + SLOT_SIZE - 1, slotY + SLOT_SIZE - 1, COL_SLOT_HOVER);
                gfx.method_51446(mc.field_1772, stack, mouseX, mouseY);
            }
        }
    }

    private void drawInventoryPanel(class_332 gfx) {
        gfx.method_51439(mc.field_1772, class_2561.method_43471("container.inventory"),
                invPanelX + PADDING, invPanelY + PADDING - 2, COL_TITLE_IDLE, false);

        // Vanilla places items at (leftPos + slot.x, topPos + slot.y), which is the 16x16 item
        // area. Pass (screenX - 1, screenY - 1) so the 1px border is drawn outside that area,
        // keeping the inner fill aligned with where items and the hover highlight land.
        int leftPos = accessor.sbe$getLeftPos();
        List<class_1735> playerSlots = getPlayerSlots();
        for (int i = 0; i < Math.min(playerSlots.size(), originalPlayerSlotRelY.length); i++) {
            class_1735 slot = playerSlots.get(i);
            int screenX = leftPos + slot.field_7873;
            int screenY = baseTopPos + slot.field_7872;
            drawSlotBackground(gfx, screenX - 1, screenY - 1);
        }
    }

    /**
     * Draws an 18×18 sunken slot with (x, y) as the outer top-left corner.
     * The inner 16×16 fill — where items and hover highlights land — starts at (x+1, y+1).
     */
    private void drawSlotBackground(class_332 gfx, int x, int y) {
        gfx.method_25294(x,                 y,                 x + SLOT_SIZE,     y + 1,             COL_SLOT_TL);
        gfx.method_25294(x,                 y,                 x + 1,             y + SLOT_SIZE,     COL_SLOT_TL);
        gfx.method_25294(x,                 y + SLOT_SIZE - 1, x + SLOT_SIZE,     y + SLOT_SIZE,     COL_SLOT_BR);
        gfx.method_25294(x + SLOT_SIZE - 1, y,                 x + SLOT_SIZE,     y + SLOT_SIZE,     COL_SLOT_BR);
        gfx.method_25294(x + 1,             y + 1,             x + SLOT_SIZE - 1, y + SLOT_SIZE - 1, COL_SLOT_ITEM);
    }

    private void drawScrollbar(class_332 gfx) {
        Rect track = getScrollbarTrack();
        gfx.method_25294(track.x, track.y, track.x + track.width, track.y + track.height, 0x30FFFFFF);

        float max = maxScroll();
        if (max <= 0) return;

        float ratio = (float) innerScrollPanelHeight / Math.max(lastRenderedContentH, 1);
        int knobH   = Math.max(20, (int) (track.height * ratio));
        int knobY   = track.y + (int) ((scroll / max) * (track.height - knobH));
        gfx.method_25294(track.x,     knobY,     track.x + track.width,     knobY + knobH,     0xC0FFFFFF);
        gfx.method_25294(track.x + 1, knobY + 1, track.x + track.width - 1, knobY + knobH - 1, 0x80AAAAAA);
    }

    // ── Hover guard ───────────────────────────────────────────────────────────

    /**
     * Guards fake-item hover so slots that have scrolled outside the viewport
     * don't match the mouse position in content-space.
     */
    private boolean isSlotHovered(int slotX, int slotY, int mouseX, int contentMouseY, Rect panel) {
        int screenSlotY = slotY - (int) scroll;
        boolean inViewport = screenSlotY >= panel.y
                && screenSlotY + SLOT_SIZE <= panel.y + panel.height
                && slotX >= panel.x
                && slotX + SLOT_SIZE <= panel.x + panel.width;
        return inViewport
                && mouseX        >= slotX && mouseX        < slotX + SLOT_SIZE
                && contentMouseY >= slotY && contentMouseY < slotY + SLOT_SIZE;
    }

    // ── Page iteration ────────────────────────────────────────────────────────

    @FunctionalInterface
    private interface PageConsumer {
        void accept(Rect rect, StoragePageSlot slot, StorageData.StorageInventory inv);
    }

    private void forEachPage(Set<StoragePageSlot> filter, PageConsumer consumer) {
        int col = 0, maxRowH = 0, totalH = 0;
        for (var entry : StorageData.INSTANCE.getInventories().entrySet()) {
            if (!filter.contains(entry.getKey())) continue;
            StorageData.StorageInventory inv = entry.getValue();

            int pageH = pageRows(entry.getKey(), inv, entry.getKey().equals(activeSlot)) * SLOT_SIZE
                    + mc.field_1772.field_2000 + 10;
            maxRowH = Math.max(maxRowH, pageH);

            consumer.accept(
                    new Rect(overviewX + PADDING + (PAGE_WIDTH + PADDING) * col,
                            OVERVIEW_TOP + TOP_BAR_H + totalH, PAGE_WIDTH, pageH),
                    entry.getKey(), inv);

            if (++col >= pageWidthCount) {
                totalH += maxRowH + PADDING;
                col = 0;
                maxRowH = 0;
            }
        }
        lastRenderedContentH = totalH + maxRowH;
    }

    private int pageRows(StoragePageSlot slot, StorageData.StorageInventory inv, boolean isActive) {
        if (isActive) return Math.max(1, (screen.method_17577().field_7761.size() - 36) / 9);
        if (inv != null && inv.inventory() != null) return inv.inventory().rows();
        return 1;
    }

    // ── Hit-testing ───────────────────────────────────────────────────────────

    private Rect findPageRect(StoragePageSlot target) {
        if (target == null) return null;
        Rect[] result = {null};
        forEachPage(getFilteredPages(), (rect, slot, inv) -> {
            if (result[0] == null && slot.equals(target)) result[0] = rect;
        });
        return result[0];
    }

    private StoragePageSlot pageAt(int screenX, int screenY) {
        StoragePageSlot[] result = {null};
        forEachPage(getFilteredPages(), (rect, slot, inv) -> {
            if (result[0] == null && rect.contains(screenX, screenY + (int) scroll)) result[0] = slot;
        });
        return result[0];
    }

    // ── Input handlers ────────────────────────────────────────────────────────

    private boolean handleSearchFieldClick(class_11909 event, boolean doubleClick) {
        if (searchField == null) return false;
        if (searchField.method_25402(event, doubleClick)) {
            searchField.method_25365(true);
            return true;
        }
        searchField.method_25365(false);
        return false;
    }

    private boolean handleScrollbarClick(class_11909 event) {
        if (!getScrollbarTrack().contains(event.comp_4798(), event.comp_4799())) return false;
        knobGrabbed = true;
        scroll = scrollForKnobY(event.comp_4799());
        return true;
    }

    private boolean handlePageClick(class_11909 event) {
        if (!getScrollPanel().contains(event.comp_4798(), event.comp_4799())) return false;
        StoragePageSlot clicked = pageAt((int) event.comp_4798(), (int) event.comp_4799());
        if (clicked != null && !clicked.equals(activeSlot)) {
            clicked.navigateTo();
            return true;
        }
        return false;
    }

    private float scrollForKnobY(double mouseY) {
        Rect track = getScrollbarTrack();
        return clampScroll((float) ((mouseY - track.y) / track.height) * maxScroll());
    }

    // ── Search ────────────────────────────────────────────────────────────────

    private void initSearchField() {
        if (searchField == null) {
            searchField = new class_342(mc.field_1772, 0, 0, 140, 16, class_2561.method_43470("Search items..."));
            searchField.method_1880(64);
            searchField.method_1863(this::onSearchChanged);
            searchField.method_1858(true);
        }
        searchField.method_46421(overviewX + PADDING);
        searchField.method_46419(OVERVIEW_TOP + 5);
        searchField.method_25358(Math.max(80, overviewWidth - SCROLL_BAR_W - PADDING * 4));
    }

    private void onSearchChanged(String query) {
        searchQuery       = query != null ? query : "";
        cachedSearchQuery = null;
        scroll = 0f;
    }

    private Set<StoragePageSlot> getFilteredPages() {
        if (searchQuery.isBlank()) return StorageData.INSTANCE.getInventories().keySet();
        if (searchQuery.equals(cachedSearchQuery)) return cachedFilteredPages;

        cachedFilteredPages = StorageData.INSTANCE.getInventories().entrySet().stream()
                .filter(e -> e.getValue() == null
                        || e.getValue().inventory() == null
                        || e.getValue().inventory().stacks().stream()
                        .anyMatch(s -> matchesSearch(s, searchQuery)))
                .map(java.util.Map.Entry::getKey)
                .collect(java.util.stream.Collectors.toSet());
        cachedSearchQuery = searchQuery;
        return cachedFilteredPages;
    }

    private boolean matchesSearch(class_1799 stack, String query) {
        if (stack.method_7960()) return false;
        Set<String> words = new TreeSet<>(Arrays.asList(query.toLowerCase().split("\\s+")));
        words.removeIf(stack.method_7964().getString().toLowerCase()::contains);
        if (words.isEmpty()) return true;
        for (class_2561 line : stack.method_7950(
                net.minecraft.class_1792.class_9635.method_59528(mc.field_1687),
                mc.field_1724, class_1836.class_1837.field_41070)) {
            words.removeIf(line.getString().toLowerCase()::contains);
            if (words.isEmpty()) return true;
        }
        return false;
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private void ensureAllSlotsRegistered() {
        for (int i = 0; i < StoragePageSlot.COUNT; i++) {
            StoragePageSlot s = new StoragePageSlot(i);
            if (!StorageData.INSTANCE.hasInventory(s)) {
                StorageData.INSTANCE.updateInventory(s, s.defaultName(), null);
            }
        }
    }

    private int[] capturePlayerSlotRelY() {
        List<class_1735> slots = getPlayerSlots();
        int[] relY = new int[slots.size()];
        for (int i = 0; i < slots.size(); i++) relY[i] = slots.get(i).field_7872;
        return relY;
    }

    private List<class_1735> getPlayerSlots() {
        return screen.method_17577().field_7761.stream()
                .filter(s -> s.field_7871 == mc.field_1724.method_31548())
                .toList();
    }

    private float maxScroll()          { return Math.max(0f, lastRenderedContentH - innerScrollPanelHeight); }
    private float clampScroll(float v) { return class_3532.method_15363(v, 0f, maxScroll()); }

    private static int parseColor(String hex) {
        try {
            if (hex.startsWith("#")) hex = hex.substring(1);
            if (hex.length() == 6) return 0xFF000000 | Integer.parseInt(hex, 16);
            if (hex.length() == 8) { int v = (int) Long.parseLong(hex, 16); return (v >> 8) | ((v & 0xFF) << 24); }
        } catch (NumberFormatException ignored) {}
        return 0xFFFFFFFF;
    }
}