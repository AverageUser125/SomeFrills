package com.github.kd_gaming1.skyblockenhancements.access;

import com.github.kd_gaming1.skyblockenhancements.feature.chat.ChatLineTracker;
import java.util.List;
import net.minecraft.class_303;

/**
 * Duck interface mixed into {@link net.minecraft.class_338}.
 * Exposes the collaborators external chat features need: raw/display history, scroll state,
 * scaled geometry, and the per-instance {@link ChatLineTracker}.
 */
public interface SBEChatAccess {

    List<class_303> sbe$getAllMessages();

    List<class_303.class_7590> sbe$getTrimmedMessages();

    int sbe$getChatScrollbarPos();

    int sbe$getScaledWidth();

    void sbe$refreshMessages();

    ChatLineTracker sbe$getLineTracker();
}