package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.reforge;

import cc.cassian.rrv.common.rendering.RrvGuiRenderHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Renders a temporary Villager entity as the blacksmith preview.
 * Falls back to a villager spawn egg if entity creation fails.
 */
public class BlacksmithPreviewRenderer {

    private static final int PREVIEW_SIZE = 36;
    private static final int PREVIEW_X = 4;
    private static final int PREVIEW_Y = 4;

    private static final float BASE_SCALE = 15.0F;
    private static final float MAX_HEIGHT = PREVIEW_SIZE - 4.0F;
    private static final float ROT_X_DEG = 180.0F;
    private static final int ROTATION_PERIOD = 360;

    @Nullable private class_1309 villager;
    private int animationTick;
    private boolean initFailed;

    public void init(class_638 level) {
        if (villager != null || initFailed) return;
        try {
            class_1297 entity = class_1299.field_6077.method_5883(level, class_3730.field_52444);
            if (entity instanceof class_1309 v) {
                v.method_5636(30.0F);
                v.method_5847(30.0F);
                this.villager = v;
            } else {
                initFailed = true;
            }
        } catch (Exception e) {
            initFailed = true;
        }
    }

    public void fade() {
        if (villager != null) {
            villager.method_5650(class_1297.class_5529.field_26999);
            villager = null;
        }
    }

    public void tick() {
        animationTick++;
        if (animationTick >= ROTATION_PERIOD) animationTick = 0;
    }

    public void render(class_332 gfx, int recipeLeft, int recipeTop, float partialTicks) {
        if (villager == null) {
            renderSpawnEggFallback(gfx, recipeLeft, recipeTop);
            return;
        }

        float scale = BASE_SCALE;
        class_238 bb = villager.method_5829();
        if (bb.method_17940() * scale > MAX_HEIGHT) {
            scale = (float) (MAX_HEIGHT / bb.method_17940());
        }

        int x0 = recipeLeft + PREVIEW_X;
        int y0 = recipeTop + PREVIEW_Y;
        int x1 = x0 + PREVIEW_SIZE;
        int y1 = y0 + PREVIEW_SIZE;

        Quaternionf rotation = new Quaternionf().rotationXYZ(
                (float) Math.toRadians(ROT_X_DEG),
                (animationTick + partialTicks) / 180.0F * class_3532.field_29844,
                0.0F);

        RrvGuiRenderHelper.renderEntityOnScreen(
                gfx, villager, x0, y0, x1, y1, scale,
                new Vector3f(0.0F, PREVIEW_SIZE / scale / 2.0F, 0.0F),
                rotation, null);
    }

    private void renderSpawnEggFallback(class_332 gfx, int recipeLeft, int recipeTop) {
        class_1799 egg = new class_1799(class_1802.field_8086);
        int x = recipeLeft + PREVIEW_X + (PREVIEW_SIZE - 16) / 2;
        int y = recipeTop + PREVIEW_Y + (PREVIEW_SIZE - 16) / 2;
        gfx.method_51427(egg, x, y);
    }
}
