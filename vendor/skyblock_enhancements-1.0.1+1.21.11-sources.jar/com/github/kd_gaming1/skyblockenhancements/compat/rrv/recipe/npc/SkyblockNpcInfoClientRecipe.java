package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipePriority;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipeUtil;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockClientRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeColors;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5481;
import org.jetbrains.annotations.Nullable;

public class SkyblockNpcInfoClientRecipe extends AbstractSkyblockClientRecipe
        implements ReliableClientRecipe {

    /** Adds a §⬈ Navigate§ button that delegates to SkyHanni's {@code /shnav} command. */
    private static final boolean SKYHANNI_PRESENT =
            FabricLoader.getInstance().isModLoaded("skyhanni");

    private static final int RECIPE_HEIGHT     = 100;
    private static final int BUTTON_ROW_HEIGHT = 18;
    private static final int LINE_HEIGHT       = 10;
    private static final int TEXT_X            = 22;
    private static final int TEXT_RIGHT_LIMIT  = 130;
    private static final int NAV_BUTTON_W      = 60;

    private final @Nullable SlotContent npcHead;
    private final String npcId;
    private final String npcDisplayName;
    private final String island;
    private final int x, y, z;
    private final String[] loreLines;

    /**
     * Creates an NPC info client recipe and registers it in {@link SkyblockNpcInfoRegistry}
     * so that the "NPC Info" button in shop recipes can resolve it.
     */
    public static SkyblockNpcInfoClientRecipe createAndRegister(SkyblockNpcInfoServerRecipe r) {
        SkyblockNpcInfoClientRecipe recipe = new SkyblockNpcInfoClientRecipe(
                r.getNpcHead(), r.getNpcId(), r.getNpcDisplayName(),
                r.getIsland(), r.getX(), r.getY(), r.getZ(),
                r.getLoreLines(), r.getWikiUrls());
        SkyblockNpcInfoRegistry.register(r.getNpcId(), recipe);
        return recipe;
    }

    public SkyblockNpcInfoClientRecipe(class_1799 npcHead, String npcId, String npcDisplayName,
                                       String island, int x, int y, int z,
                                       String[] loreLines, String[] wikiUrls) {
        super(wikiUrls);
        this.npcHead = (npcHead != null && !npcHead.method_7960()) ? SlotContent.of(npcHead) : null;
        this.npcId = npcId != null ? npcId : "";
        this.npcDisplayName = npcDisplayName != null ? npcDisplayName : "";
        this.island = island != null ? island : "";
        this.x = x; this.y = y; this.z = z;
        this.loreLines = loreLines != null ? loreLines : new String[0];
    }

    public String getNpcId() {
        return npcId;
    }

    @Override
    public ReliableClientRecipeType getViewType() {
        return SkyblockNpcInfoRecipeType.INSTANCE;
    }

    @Override
    public void bindSlots(RecipeViewMenu.SlotFillContext ctx) {
        if (npcHead != null) ctx.bindSlot(0, npcHead);
    }

    @Override
    public List<SlotContent> getIngredients() {
        return List.of();
    }

    @Override
    public List<SlotContent> getResults() {
        return npcHead != null ? List.of(npcHead) : List.of();
    }

    @Override
    public boolean isVisualOnly() {
        return true;
    }

    @Override
    public void renderRecipe(RecipeViewScreen screen, RecipePosition pos, class_332 gfx,
                             int mouseX, int mouseY, float partialTicks) {
        int cursorY = renderLocationHeader(gfx, font());
        renderLoreLines(gfx, font(), cursorY);
        maintainButtons(screen, pos);
    }

    private int renderLocationHeader(class_332 gfx, class_327 font) {
        if (island.isEmpty()) return 2;

        int cursorY = 2;
        gfx.method_51439(font, SkyblockRecipeUtil.gray(formatIsland(island)),
                TEXT_X, cursorY, RecipeColors.PLACEHOLDER, false);
        cursorY += LINE_HEIGHT;
        gfx.method_51439(font, SkyblockRecipeUtil.darkGray(x + ", " + y + ", " + z),
                TEXT_X, cursorY, RecipeColors.NPC_COORDS, false);
        return cursorY + LINE_HEIGHT + 2;
    }

    private void renderLoreLines(class_332 gfx, class_327 font, int cursorY) {
        int maxTextY = RECIPE_HEIGHT - BUTTON_ROW_HEIGHT;
        int maxTextWidth = TEXT_RIGHT_LIMIT - TEXT_X;

        for (String line : loreLines) {
            if (line == null || line.isEmpty()) continue;
            if (cursorY + LINE_HEIGHT > maxTextY) break;

            for (class_5481 wrapped : font.method_1728(class_2561.method_43470(line), maxTextWidth)) {
                if (cursorY + LINE_HEIGHT > maxTextY) break;
                gfx.method_51430(font, wrapped, TEXT_X, cursorY, RecipeColors.WHITE, false);
                cursorY += LINE_HEIGHT;
            }
        }
    }

    @Override
    @Nullable
    protected class_4185 placeButtons(RecipeViewScreen screen, RecipePosition pos) {
        int btnY = pos.top() + RECIPE_HEIGHT - BUTTON_ROW_HEIGHT + 3;
        int btnX = pos.left() + 2;

        class_4185 sentinel = placeWikiButton(screen, btnX, btnY);
        if (sentinel != null) btnX += RecipeLayoutConstants.WIKI_BUTTON_WIDTH + RecipeLayoutConstants.BUTTON_GAP;

        if (SKYHANNI_PRESENT) {
            class_4185 navBtn = class_4185.method_46430(
                            class_2561.method_43470("⬈ Navigate"),
                            b -> sendNavigateCommand(npcDisplayName))
                    .method_46433(btnX, btnY)
                    .method_46437(NAV_BUTTON_W, RecipeLayoutConstants.WIKI_BUTTON_HEIGHT)
                    .method_46431();
            screen.addRecipeWidget(navBtn);
            if (sentinel == null) sentinel = navBtn;
        }

        return sentinel;
    }

    private static void sendNavigateCommand(String displayName) {
        SkyblockRecipeUtil.sendCommand("shnav " + stripFormatting(displayName));
    }

    private static String stripFormatting(String displayName) {
        String clean = displayName.replaceAll("§[0-9a-fk-orA-FK-OR]", "");
        if (clean.endsWith(" (NPC)")) clean = clean.substring(0, clean.length() - 6);
        return clean.trim();
    }

    private static String formatIsland(String island) {
        String[] words = island.split("_");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.isEmpty()) continue;
            if (!sb.isEmpty()) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    @Override
    public int getPriority() {
        return SkyblockRecipePriority.NPC_INFO;
    }
}