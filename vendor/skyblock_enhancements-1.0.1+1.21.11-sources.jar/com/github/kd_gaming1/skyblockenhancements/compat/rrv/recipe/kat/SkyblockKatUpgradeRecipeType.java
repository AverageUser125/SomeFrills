package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.kat;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/** Input pet (0) + up to 4 materials (1–4) → output pet (5); coins & duration in text. */
public class SkyblockKatUpgradeRecipeType implements ReliableClientRecipeType {

    public static final SkyblockKatUpgradeRecipeType INSTANCE = new SkyblockKatUpgradeRecipeType();

    

    private final class_1799 icon = new class_1799(class_1802.field_8606);

    @Override public class_2561  getDisplayName()   { return class_2561.method_43470("Kat Pet Upgrade"); }
    @Override public int        getDisplayWidth()  { return 140; }
    @Override public int        getDisplayHeight() { return 64; }
    @Override public class_2960 getGuiTexture()    { return null; }
    @Override public int        getSlotCount()     { return 6; }
    @Override public class_1799  getIcon()          { return icon; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        def.addItemSlot(0, 0, 18);
        def.addItemSlot(1, 36, 9);
        def.addItemSlot(2, 54, 9);
        def.addItemSlot(3, 36, 27);
        def.addItemSlot(4, 54, 27);
        def.addItemSlot(5, 118, 18);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_katgrade");
    }
}