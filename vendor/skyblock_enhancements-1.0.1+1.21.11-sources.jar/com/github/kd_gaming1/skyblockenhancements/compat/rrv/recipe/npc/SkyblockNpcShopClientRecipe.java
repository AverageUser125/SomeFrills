package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipePriority;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.ArraySlotRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeColors;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import org.jetbrains.annotations.Nullable;

public class SkyblockNpcShopClientRecipe extends ArraySlotRecipe
        implements ReliableClientRecipe {

    /** Arrow sits between the 5-column cost grid and the result slot, vertically on the shared center. */
    private static final int ARROW_X = 84;
    private static final int ARROW_Y = 25;
    private static final int BUTTON_ROW_Y_OFFSET = 52;

    /** Max costs bindable; mirrors SkyblockNpcShopServerRecipe.MAX_COSTS. */
    private static final int MAX_COSTS = 10;
    /** Result slot index (costs occupy 0..MAX_COSTS-1). */
    private static final int RESULT_SLOT = MAX_COSTS;

    private final SlotContent[] costs;
    private final SlotContent result;
    private final String npcId;
    private final String npcDisplayName;

    public SkyblockNpcShopClientRecipe(SlotContent[] costs, SlotContent result,
                                       String npcId, String npcDisplayName, String[] wikiUrls) {
        super(wikiUrls);
        this.costs = costs;
        this.result = result;
        this.npcId = npcId != null ? npcId : "";
        this.npcDisplayName = npcDisplayName != null ? npcDisplayName : "";
    }

    public String getNpcId() {
        return npcId;
    }

    @Override
    public ReliableClientRecipeType getViewType() {
        return SkyblockNpcShopRecipeType.INSTANCE;
    }

    @Override
    public void bindSlots(RecipeViewMenu.SlotFillContext ctx) {
        for (int i = 0; i < costs.length && i < MAX_COSTS; i++) {
            if (costs[i] != null) {
                ctx.bindOptionalSlot(i, costs[i], RecipeViewMenu.OptionalSlotRenderer.DEFAULT);
            }
        }
        if (result != null) ctx.bindSlot(RESULT_SLOT, result);
    }

    @Override
    protected SlotContent[] getInputSlots() {
        return costs;
    }

    @Override
    public List<SlotContent> getResults() {
        return result != null ? List.of(result) : List.of();
    }

    @Override
    public void renderRecipe(RecipeViewScreen screen, RecipePosition pos, class_332 gfx,
                             int mouseX, int mouseY, float partialTicks) {
        if (!npcDisplayName.isEmpty()) {
            gfx.method_51439(class_310.method_1551().field_1772,
                    class_2561.method_43470(npcDisplayName), 0, 0, RecipeColors.WHITE, true);
        }
        renderArrow(gfx, ARROW_X, ARROW_Y);
        maintainButtons(screen, pos);
    }

    @Override
    @Nullable
    protected class_4185 placeButtons(RecipeViewScreen screen, RecipePosition pos) {
        int btnY = pos.top() + BUTTON_ROW_Y_OFFSET;
        int leftX = pos.left();
        class_4185 sentinel = null;

        SkyblockNpcInfoClientRecipe infoRecipe = SkyblockNpcInfoRegistry.get(npcId);
        if (infoRecipe != null) {
            class_4185 infoBtn = class_4185.method_46430(
                            class_2561.method_43470("NPC Info"),
                            b -> RecipeViewOpener.open(infoRecipe))
                    .method_46433(leftX, btnY)
                    .method_46437(RecipeLayoutConstants.WIKI_BUTTON_WIDTH, RecipeLayoutConstants.WIKI_BUTTON_HEIGHT)
                    .method_46431();
            screen.addRecipeWidget(infoBtn);
            sentinel = infoBtn;
        }

        class_4185 wiki = placeWikiButton(screen, leftX + RecipeLayoutConstants.WIKI_BUTTON_WIDTH + RecipeLayoutConstants.BUTTON_GAP + 2, btnY);
        if (sentinel == null) sentinel = wiki;

        return sentinel;
    }

    @Override
    public int getPriority() {
        return SkyblockRecipePriority.NPC_SHOP;
    }
}