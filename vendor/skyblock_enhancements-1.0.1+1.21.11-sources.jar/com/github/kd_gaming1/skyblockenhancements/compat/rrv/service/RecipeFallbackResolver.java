package com.github.kd_gaming1.skyblockenhancements.compat.rrv.service;

import cc.cassian.rrv.api.ActionType;
import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.ClientRecipeCache;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc.SkyblockNpcInfoRecipeType;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc.SkyblockNpcShopRecipeType;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.reforge.SkyblockReforgeClientRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipeUtil;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_746;
import net.minecraft.class_9334;

/**
 * Resolves recipe-view fallback logic when RRV's default lookup doesn't find a match.
 *
 * <p>Handles three scenarios:
 * <ol>
 *   <li><b>NPC items</b> — detected by display name. Opens with the correct tab
 *       pre-selected (shop vs info).</li>
 *   <li><b>Reforge stones</b> — merges reforge recipes into the left-click (RESULT)
 *       view so stats appear alongside crafting and wiki tabs.</li>
 *   <li><b>Family item page-seek</b> — advances to the page whose recipe result
 *       matches the clicked item's exact SkyBlock ID.</li>
 * </ol>
 */
public final class RecipeFallbackResolver {

    private RecipeFallbackResolver() {}

    /**
     * Attempts to resolve and open a recipe view for the given stack.
     *
     * @return {@code true} if a fallback recipe view was opened and the caller should
     *         cancel the original RRV action
     */
    public static boolean tryOpen(class_1799 stack, ActionType openType) {
        if (stack.method_7960()) return false;

        if (tryOpenNpc(stack)) return true;
        if (openType == ActionType.RESULT && tryOpenMergedResult(stack)) return true;
        if (openType == ActionType.INPUT && tryOpenInput(stack)) return true;

        return false;
    }

    private static boolean tryOpenNpc(class_1799 stack) {
        NeuItem npcItem = findNpcItem(stack);
        if (npcItem == null) return false;

        List<ReliableClientRecipe> inputRecipes =
                ClientRecipeCache.INSTANCE.getRecipesForCraftingInput(stack);
        if (inputRecipes.isEmpty()) return false;

        ReliableClientRecipeType preferredTab = npcItem.hasNpcShopRecipes()
                ? SkyblockNpcShopRecipeType.INSTANCE
                : SkyblockNpcInfoRecipeType.INSTANCE;

        openWithTab(stack, inputRecipes, preferredTab, null, ActionType.ANY);
        return true;
    }

    private static boolean tryOpenMergedResult(class_1799 stack) {
        List<ReliableClientRecipe> resultRecipes =
                ClientRecipeCache.INSTANCE.getRecipesForCraftingOutput(stack);
        List<ReliableClientRecipe> inputRecipes =
                ClientRecipeCache.INSTANCE.getRecipesForCraftingInput(stack);

        List<ReliableClientRecipe> merged = appendReforgeRecipes(resultRecipes, inputRecipes);
        if (merged.isEmpty()) return false;

        String seekId = SkyblockRecipeUtil.extractSkyblockId(stack);
        ActionType actionType = resultRecipes.isEmpty() ? ActionType.INPUT : ActionType.RESULT;
        openWithTab(stack, merged, null, seekId, actionType);
        return true;
    }

    private static boolean tryOpenInput(class_1799 stack) {
        List<ReliableClientRecipe> inputRecipes =
                ClientRecipeCache.INSTANCE.getRecipesForCraftingInput(stack);
        if (inputRecipes.isEmpty()) return false;

        String seekId = SkyblockRecipeUtil.extractSkyblockId(stack);
        openWithTab(stack, inputRecipes, null, seekId, ActionType.INPUT);
        return true;
    }

    /**
     * Appends reforge recipes from {@code candidates} that are not already present
     * in {@code base}. Uses an {@link IdentityHashMap} set for O(1) containment checks
     * instead of the previous O(n²) {@link List#contains} approach.
     */
    private static List<ReliableClientRecipe> appendReforgeRecipes(
            List<ReliableClientRecipe> base,
            List<ReliableClientRecipe> candidates) {
        if (candidates.isEmpty()) return base;

        Set<ReliableClientRecipe> baseSet =
                Collections.newSetFromMap(new IdentityHashMap<>(base.size()));
        baseSet.addAll(base);

        List<ReliableClientRecipe> additions = candidates.stream()
                .filter(r -> r instanceof SkyblockReforgeClientRecipe)
                .filter(r -> !baseSet.contains(r))
                .toList();

        if (additions.isEmpty()) return base;

        List<ReliableClientRecipe> merged = new ArrayList<>(base.size() + additions.size());
        merged.addAll(base);
        merged.addAll(additions);
        return merged;
    }

    private static NeuItem findNpcItem(class_1799 stack) {
        class_2561 displayName = stack.method_58694(class_9334.field_49631);
        if (displayName == null) return null;
        return NeuItemRegistry.getNpcByDisplayName(displayName.getString());
    }

    private static void openWithTab(
            class_1799 stack,
            List<ReliableClientRecipe> recipes,
            ReliableClientRecipeType preferredTab,
            String seekId,
            ActionType actionType) {

        class_746 player = class_310.method_1551().field_1724;
        if (player == null) return;
        if (recipes == null || recipes.isEmpty()) return;

        class_437 parent = class_310.method_1551().field_1755;
        ArrayList<RecipeViewScreen> viewHistory = new ArrayList<>();

        if (parent instanceof RecipeViewScreen viewScreen) {
            parent = viewScreen.method_17577().getParentScreen();
            viewHistory = viewScreen.method_17577().getViewHistory();
        }

        int containerId = parent instanceof class_465<?> cs
                ? cs.method_17577().field_7763 : 0;

        RecipeViewMenu menu = preferredTab != null
                ? new RecipeViewMenu(parent, containerId, player.method_31548(),
                recipes, stack, actionType, viewHistory, preferredTab)
                : new RecipeViewMenu(parent, containerId, player.method_31548(),
                recipes, stack, actionType, viewHistory);

        if (seekId != null) {
            SkyblockRecipeUtil.seekToMatchingPage(menu, seekId);
        }

        class_310.method_1551().method_1507(
                new RecipeViewScreen(menu, player.method_31548(), class_2561.method_43473()));
    }
}
