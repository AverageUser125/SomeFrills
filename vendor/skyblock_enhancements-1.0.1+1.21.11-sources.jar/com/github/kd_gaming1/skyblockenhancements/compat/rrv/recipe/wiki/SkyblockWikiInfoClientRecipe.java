package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.wiki;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockClientRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeColors;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipePriority;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipeUtil;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import org.jetbrains.annotations.Nullable;

public class SkyblockWikiInfoClientRecipe extends AbstractSkyblockClientRecipe
        implements ReliableClientRecipe {
    
    private static final int NAME_X          = 22;
    private static final int NAME_Y          = 4;
    private static final int LINE_HEIGHT     = 10;
    private static final int LINE_GAP        = 1;
    private static final int MAX_NAME_LINES  = 2;
    private static final int RIGHT_PADDING   = 4;
    private static final int BUTTON_Y_OFFSET = 20;

    private static final String ELLIPSIS     = "…";

    private final @Nullable SlotContent displayItem;
    private final class_2561 itemName;

    public SkyblockWikiInfoClientRecipe(class_1799 displayItem, String displayName, String[] wikiUrls) {
        super(wikiUrls);
        boolean valid = displayItem != null && !displayItem.method_7960();
        this.displayItem = valid ? SlotContent.of(displayItem) : null;
        this.itemName    = resolveName(displayItem, displayName, valid);
    }

    /** Prefer the explicit displayName; fall back to the stack's hover name, then empty. */
    private static class_2561 resolveName(@Nullable class_1799 stack, @Nullable String displayName, boolean valid) {
        if (displayName != null && !displayName.isBlank()) {
            return class_2561.method_43470(displayName);
        }
        if (valid) {
            assert stack != null;
            return stack.method_7964();
        }
        return class_2561.method_43473();
    }

    @Override
    public ReliableClientRecipeType getViewType() {
        return SkyblockWikiInfoRecipeType.INSTANCE;
    }

    @Override
    public void bindSlots(RecipeViewMenu.SlotFillContext ctx) {
        if (displayItem != null) ctx.bindSlot(0, displayItem);
    }

    @Override
    public List<SlotContent> getIngredients() {
        return List.of();
    }

    @Override
    public List<SlotContent> getResults() {
        return displayItem != null ? List.of(displayItem) : List.of();
    }

    @Override
    public void renderRecipe(RecipeViewScreen screen, RecipePosition pos, class_332 gfx,
                             int mouseX, int mouseY, float partialTicks) {
        class_327 font = font();
        int wrapWidth = getViewType().getDisplayWidth() - NAME_X - RIGHT_PADDING;
        List<class_5481> lines = wrapName(font, itemName, wrapWidth);

        int startY = centeredStartY(lines.size());
        for (int i = 0; i < lines.size(); i++) {
            gfx.method_51430(font, lines.get(i), NAME_X, startY + i * LINE_HEIGHT, RecipeColors.DARK_TEXT, false);
        }
        maintainButtons(screen, pos);
    }

    /**
     * Y position for the first line so the whole block is centered between the
     * card top and the Wiki button. Keeps 1-line and 2-line entries visually balanced.
     */
    private static int centeredStartY(int lineCount) {
        int totalHeight = lineCount * LINE_HEIGHT - LINE_GAP;
        return Math.max(0, (BUTTON_Y_OFFSET - totalHeight) / 2);
    }

    /**
     * Splits the name to fit {@code wrapWidth}, capping at {@code maxLines}.
     * If the full text doesn't fit, the last visible line is truncated with an ellipsis.
     */
    private static List<class_5481> wrapName(class_327 font, class_2561 name, int wrapWidth) {
        var splitter = font.method_27527();
        List<class_5348> lines = splitter.method_27495(name, wrapWidth, net.minecraft.class_2583.field_24360);

        if (lines.size() <= MAX_NAME_LINES) {
            return lines.stream().map(net.minecraft.class_2477.method_10517()::method_30934).toList();
        }

        List<class_5481> trimmed = new java.util.ArrayList<>(MAX_NAME_LINES);
        for (int i = 0; i < MAX_NAME_LINES - 1; i++) {
            trimmed.add(net.minecraft.class_2477.method_10517().method_30934(lines.get(i)));
        }

        class_5348 lastLine = lines.get(MAX_NAME_LINES - 1);

        String ellipsis = "…";
        int available = Math.max(0, wrapWidth - font.method_1727(ellipsis));

        class_5348 head = font.method_1714(lastLine, available);
        class_5348 ellipsized = class_5348.method_29433(head, class_5348.method_29430(ellipsis));

        trimmed.add(net.minecraft.class_2477.method_10517().method_30934(ellipsized));
        return trimmed;
    }

    /** Truncates a single line to {@code wrapWidth} with a trailing ellipsis. */
    private static class_5481 ellipsize(class_327 font, class_5481 line, int wrapWidth) {
        return SkyblockRecipeUtil.ellipsize(font, line, wrapWidth);
    }

    @Override
    @Nullable
    protected class_4185 placeButtons(RecipeViewScreen screen, RecipePosition pos) {
        return placeWikiButton(screen, pos.left(), pos.top() + BUTTON_Y_OFFSET);
    }

    @Override
    public int getPriority() {
        return SkyblockRecipePriority.WIKI_INFO;
    }
}