package com.github.kd_gaming1.skyblockenhancements.compat.rrv.injection;

import com.github.kd_gaming1.skyblockenhancements.config.SkyblockEnhancementsConfig;
import com.github.kd_gaming1.skyblockenhancements.repo.item.ItemStackBuilder;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuConstantsRegistry;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9334;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.ItemFamilyHelper;

/**
 * Builds the sorted SkyBlock item list from the {@link NeuItemRegistry} for injection
 * into RRV. Handles compact mode filtering and multi-key sorting.
 *
 * <p>Extracted from {@link SkyblockInjectionCache} to keep the cache class focused
 * on state management only.
 */
public final class SkyblockItemListBuilder {

    private SkyblockItemListBuilder() {}

    /**
     * Builds the sorted item list from the NEU registry. When compact mode is enabled,
     * child items from {@code parents.json} are excluded — their recipes remain accessible
     * through the parent item.
     *
     * @return sorted, non-empty item list ready for RRV injection
     */
    public static List<class_1799> build() {
        boolean compact = SkyblockEnhancementsConfig.compactItemList;

        // Pair stacks with their NeuItem and pre-computed sort key for zero-allocation sorting.
        record StackWithMeta(class_1799 stack, NeuItem neuItem, SortKey sortKey) {}

        List<StackWithMeta> candidates = new ArrayList<>();

        for (Map.Entry<String, NeuItem> entry : NeuItemRegistry.getAll().entrySet()) {
            String itemId = entry.getKey();
            NeuItem neuItem = entry.getValue();

            if (compact && NeuConstantsRegistry.isChild(itemId)) {
                String parentId = NeuConstantsRegistry.getParent(itemId);
                if (ItemFamilyHelper.shouldCompactFamily(parentId)) {
                    continue;
                }
            }

            class_1799 stack = ItemStackBuilder.build(neuItem);
            if (compact && !stack.method_7960() && ItemFamilyHelper.shouldCompactFamily(itemId)) {
                String compactName = ItemFamilyHelper.buildCompactDisplayName(
                        itemId, neuItem.displayName);
                if (compactName != null) {
                    stack = stack.method_7972();
                    stack.method_57379(class_9334.field_49631, class_2561.method_43470(compactName));
                }
            }

            if (!stack.method_7960()) {
                SortKey key = new SortKey(neuItem);
                candidates.add(new StackWithMeta(stack, neuItem, key));
            }
        }

        // Sort using pre-computed keys — zero allocations during comparison.
        candidates.sort(Comparator.comparing(StackWithMeta::sortKey));

        List<class_1799> items = new ArrayList<>(candidates.size());
        for (StackWithMeta s : candidates) {
            items.add(s.stack());
        }
        return items;
    }

    // ── Sort key ────────────────────────────────────────────────────────────────

    /**
     * Immutable, pre-computed sort key for a {@link NeuItem}. All expensive string
     * operations (substring, color-code stripping) happen once at construction time,
     * so the comparator performs only zero-allocation field comparisons.
     */
    private record SortKey(
            String familyPrefix,
            int rarityOrdinal,
            String cleanDisplayName,
            String internalName
    ) implements Comparable<SortKey> {

        SortKey(NeuItem item) {
            this(
                    familyPrefixOf(item.internalName),
                    item.rarity != null ? item.rarity.ordinal() : Integer.MAX_VALUE,
                    stripColorCodes(item.displayName),
                    item.internalName != null ? item.internalName : ""
            );
        }

        @Override
        public int compareTo(SortKey other) {
            int c = this.familyPrefix.compareTo(other.familyPrefix);
            if (c != 0) return c;

            c = Integer.compare(this.rarityOrdinal, other.rarityOrdinal);
            if (c != 0) return c;

            c = this.cleanDisplayName.compareTo(other.cleanDisplayName);
            if (c != 0) return c;

            return this.internalName.compareTo(other.internalName);
        }
    }

    // ── Helpers ─────────────────────────────────────────────────────────────────

    /** Returns the substring before the first {@code ';'}, or {@code ""} if absent. */
    private static String familyPrefixOf(String internalName) {
        if (internalName == null) return "";
        int semi = internalName.indexOf(';');
        return semi >= 0 ? internalName.substring(0, semi) : "";
    }

    /**
     * Strips Minecraft color/formatting codes ({@code §x}) from a string.
     * Faster than {@code replaceAll("§.", "")} because it avoids regex compilation
     * and intermediate {@link String} objects.
     */
    private static String stripColorCodes(String raw) {
        if (raw == null) return "";
        int len = raw.length();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char ch = raw.charAt(i);
            if (ch == '§' && i + 1 < len) {
                i++; // skip the formatting code character
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }
}
