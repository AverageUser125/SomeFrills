package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockServerRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2960;

/**
 * Info card for an NPC: head, display name, island location, lore lines, and wiki URLs.
 * Generated for every NPC item. Shop NPCs are reached from the shop page's "NPC Info" button,
 * non-shop NPCs by clicking the NPC item directly.
 */
public class SkyblockNpcInfoServerRecipe extends AbstractSkyblockServerRecipe {

    public static final ReliableServerRecipeType<SkyblockNpcInfoServerRecipe> TYPE =
            ReliableServerRecipeType.register(
                    class_2960.method_60655("skyblock_enhancements", "skyblock_npc_info"),
                    () -> new SkyblockNpcInfoServerRecipe(
                            class_1799.field_8037, "", "", "", 0, 0, 0, new String[0], new String[0]));

    private class_1799 npcHead;
    private String npcId;
    private String npcDisplayName;
    private String island;
    private int x;
    private int y;
    private int z;
    private String[] loreLines;

    public SkyblockNpcInfoServerRecipe(class_1799 npcHead, String npcId, String npcDisplayName,
                                       String island, int x, int y, int z,
                                       String[] loreLines, String[] wikiUrls) {
        super(wikiUrls);
        this.npcHead = npcHead != null ? npcHead : class_1799.field_8037;
        this.npcId = npcId != null ? npcId : "";
        this.npcDisplayName = npcDisplayName != null ? npcDisplayName : "";
        this.island = island != null ? island : "";
        this.x = x;
        this.y = y;
        this.z = z;
        this.loreLines = loreLines != null ? loreLines : new String[0];
    }

    @Override
    protected ReliableServerRecipeType<?> getType() {
        return TYPE;
    }

    @Override
    protected void writeFields(class_2487 tag) {
        RecipeTagCodec.writeStack(tag, RecipeTagCodec.KEY_HEAD, npcHead);
        tag.method_10582(RecipeTagCodec.KEY_NPC, npcId);
        tag.method_10582(RecipeTagCodec.KEY_DISPLAY_NAME, npcDisplayName);
        tag.method_10582(RecipeTagCodec.KEY_ISLAND, island);
        tag.method_10569(RecipeTagCodec.KEY_X, x);
        tag.method_10569(RecipeTagCodec.KEY_Y, y);
        tag.method_10569(RecipeTagCodec.KEY_Z, z);
        RecipeTagCodec.writeStringArray(tag, RecipeTagCodec.KEY_LORE, loreLines);
    }

    @Override
    protected void readFields(class_2487 tag) {
        npcHead        = RecipeTagCodec.readStack(tag, RecipeTagCodec.KEY_HEAD);
        npcId          = tag.method_68564(RecipeTagCodec.KEY_NPC, "");
        npcDisplayName = tag.method_68564(RecipeTagCodec.KEY_DISPLAY_NAME, "");
        island         = tag.method_68564(RecipeTagCodec.KEY_ISLAND, "");
        x              = tag.method_68083(RecipeTagCodec.KEY_X, 0);
        y              = tag.method_68083(RecipeTagCodec.KEY_Y, 0);
        z              = tag.method_68083(RecipeTagCodec.KEY_Z, 0);

        class_2499 loreTag = tag.method_68569(RecipeTagCodec.KEY_LORE);
        loreLines = RecipeTagCodec.readStringArray(tag, RecipeTagCodec.KEY_LORE, loreTag.size());
    }

    public class_1799 getNpcHead()        { return npcHead; }
    public String    getNpcId()          { return npcId; }
    public String    getNpcDisplayName() { return npcDisplayName; }
    public String    getIsland()         { return island; }
    public int       getX()              { return x; }
    public int       getY()              { return y; }
    public int       getZ()              { return z; }
    public String[]  getLoreLines()      { return loreLines; }
}
