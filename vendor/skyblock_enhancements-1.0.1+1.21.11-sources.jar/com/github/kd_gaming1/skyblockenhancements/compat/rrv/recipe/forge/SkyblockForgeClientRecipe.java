package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.forge;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipePriority;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipeUtil;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.ArraySlotRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeColors;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import org.jetbrains.annotations.Nullable;

public class SkyblockForgeClientRecipe extends ArraySlotRecipe
        implements ReliableClientRecipe {

    /** 4-column grid: arrow sits between the grid (ends at 4*18=72) and the output. */
    private static final int ARROW_X = 74;
    private static final int ARROW_Y = 23;
    private static final int DURATION_X = 2;
    private static final int DURATION_Y = 46;
    private static final int BUTTON_ROW_Y_OFFSET = 56;
    /** Max inputs bindable; mirrors SkyblockForgeServerRecipe.MAX_INPUTS. */
    private static final int MAX_INPUTS = 8;
    /** Output slot index in the bound layout. */
    private static final int OUTPUT_SLOT = MAX_INPUTS;

    private final SlotContent[] inputs;
    private final SlotContent output;
    private final int durationSeconds;
    private final int tierOffset;

    public SkyblockForgeClientRecipe(SlotContent[] inputs, SlotContent output,
                                     int durationSeconds, String[] wikiUrls) {
        super(wikiUrls);
        this.inputs = inputs;
        this.output = output;
        this.durationSeconds = durationSeconds;
        this.tierOffset = SkyblockRecipeUtil.extractTierFromResults(getResults());
    }

    @Override
    public ReliableClientRecipeType getViewType() {
        return SkyblockForgeRecipeType.INSTANCE;
    }

    @Override
    public void bindSlots(RecipeViewMenu.SlotFillContext ctx) {
        for (int i = 0; i < inputs.length && i < MAX_INPUTS; i++) {
            if (inputs[i] != null) {
                ctx.bindOptionalSlot(i, inputs[i], RecipeViewMenu.OptionalSlotRenderer.DEFAULT);
            }
        }
        if (output != null) ctx.bindSlot(OUTPUT_SLOT, output);
    }

    @Override
    protected SlotContent[] getInputSlots() {
        return inputs;
    }

    @Override
    public List<SlotContent> getResults() {
        return output != null ? List.of(output) : List.of();
    }

    @Override
    public void renderRecipe(RecipeViewScreen screen, RecipePosition pos, class_332 gfx,
                             int mouseX, int mouseY, float partialTicks) {
        renderArrow(gfx, ARROW_X, ARROW_Y);
        if (durationSeconds > 0) {
            gfx.method_51439(font(), SkyblockRecipeUtil.gray(SkyblockRecipeUtil.formatDuration(durationSeconds)),
                    DURATION_X, DURATION_Y, RecipeColors.DURATION, false);
        }
        maintainButtons(screen, pos);
    }

    @Override
    @Nullable
    protected class_4185 placeButtons(RecipeViewScreen screen, RecipePosition pos) {
        return placeWikiButton(screen, pos.left(), pos.top() + BUTTON_ROW_Y_OFFSET);
    }



    @Override
    public int getPriority() {
        return SkyblockRecipePriority.FORGE + tierOffset;
    }
}