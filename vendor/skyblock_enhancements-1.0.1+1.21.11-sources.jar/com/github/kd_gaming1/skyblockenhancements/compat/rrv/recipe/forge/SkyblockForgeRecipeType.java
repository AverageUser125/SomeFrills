package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.forge;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;

/** 2×4 input grid → single output with duration text. */
public class SkyblockForgeRecipeType implements ReliableClientRecipeType {

    public static final SkyblockForgeRecipeType INSTANCE = new SkyblockForgeRecipeType();

    
    private static final int COLS = 4;
    private static final int ROWS = 2;
    private static final int OUTPUT_INDEX = COLS * ROWS;
    private static final int OUTPUT_X = COLS * RecipeLayoutConstants.SLOT_SIZE + 12;
    private static final int OUTPUT_Y = (ROWS * RecipeLayoutConstants.SLOT_SIZE) / 2;

    private final class_1799 icon = new class_1799(class_1802.field_8782);
    private final List<class_1799> craftReferences = List.of(icon);

    @Override public class_2561   getDisplayName()   { return class_2561.method_43470("SkyBlock Forge"); }
    @Override public int         getDisplayWidth()  { return OUTPUT_X + RecipeLayoutConstants.SLOT_SIZE; }
    @Override public int         getDisplayHeight() { return 64; }
    @Override public class_2960  getGuiTexture()    { return null; }
    @Override public int         getSlotCount()     { return OUTPUT_INDEX + 1; }
    @Override public class_1799   getIcon()          { return icon; }
    @Override public List<class_1799> getCraftReferences() { return craftReferences; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                def.addItemSlot(row * COLS + col, col * RecipeLayoutConstants.SLOT_SIZE, row * RecipeLayoutConstants.SLOT_SIZE + 9);
            }
        }
        def.addItemSlot(OUTPUT_INDEX, OUTPUT_X, OUTPUT_Y);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_forge");
    }
}