package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.drops;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/**
 * Resolves NEU's vanilla-name render strings ({@code "Spider"}, {@code "Mooshroom"},
 * {@code "Eisengolem"}, ...) into real {@link class_1299}s on 1.21.
 *
 * <p>NEU uses a historic mix of:
 * <ul>
 *   <li>1.8-era PascalCase ({@code MagmaCube}, {@code CaveSpider})</li>
 *   <li>Pre-rename entity names ({@code Mooshroom} → {@code mooshroom_cow}, {@code Snowman} → {@code snow_golem})</li>
 *   <li>Non-English names ({@code Eisengolem} → {@code iron_golem})</li>
 *   <li>Typos ({@code Salmom}, {@code SiNelverfish})</li>
 * </ul>
 *
 * <p>The lookup table is closed — anything not in the table falls back to a camelCase→snake_case
 * conversion and a registry lookup. Unresolvable strings return {@code null}; callers render a
 * text-only fallback.
 */
public final class VanillaEntityNames {

    private static final Map<String, class_1299<?>> ALIASES = new HashMap<>();

    static {
        alias("Mooshroom",     class_1299.field_6143);
        alias("CaveSpider",    class_1299.field_6084);
        alias("MagmaCube",     class_1299.field_6102);
        alias("GlowSquid",     class_1299.field_28402);
        alias("Snowman",       class_1299.field_6047);
        alias("Eisengolem",    class_1299.field_6147);
        alias("Pigman",        class_1299.field_6050);
        alias("SkeletonHorse", class_1299.field_6075);
        alias("Dragon",        class_1299.field_6116);
        alias("Salmom",        class_1299.field_6073);
        alias("SiNelverfish",  class_1299.field_6125);
    }

    private static void alias(String neuName, class_1299<?> type) {
        ALIASES.put(neuName, type);
    }

    private VanillaEntityNames() {}

    @Nullable
    public static class_1299<?> resolve(String neuName) {
        if (neuName == null || neuName.isEmpty()) return null;

        class_1299<?> aliased = ALIASES.get(neuName);
        if (aliased != null) return aliased;

        class_2960 id = class_2960.method_43902("minecraft", toSnakeCase(neuName));
        if (id == null) return null;

        return class_7923.field_41177.method_17966(id).orElse(null);
    }

    /** {@code "MagmaCube"} → {@code "magma_cube"}. */
    private static String toSnakeCase(String name) {
        StringBuilder sb = new StringBuilder(name.length() + 4);
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (Character.isUpperCase(c) && i > 0 && !Character.isUpperCase(name.charAt(i - 1))) {
                sb.append('_');
            }
            sb.append(Character.toLowerCase(c));
        }
        return sb.toString().toLowerCase(Locale.ROOT);
    }
}