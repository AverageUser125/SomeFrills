package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.wiki;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/** Single item slot + wiki button; shown for items whose only metadata is wiki URLs. */
public class SkyblockWikiInfoRecipeType implements ReliableClientRecipeType {

    public static final SkyblockWikiInfoRecipeType INSTANCE = new SkyblockWikiInfoRecipeType();

    private final class_1799 icon = new class_1799(class_1802.field_8361);

    @Override public class_2561  getDisplayName()   { return class_2561.method_43470("SkyBlock Wiki"); }
    @Override public int        getDisplayWidth()  { return 130; }
    @Override public int        getDisplayHeight() { return 36; }
    @Override public class_2960 getGuiTexture()    { return null; }
    @Override public int        getSlotCount()     { return 1; }
    @Override public class_1799  getIcon()          { return icon; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        def.addItemSlot(0, 0, 0);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_wiki_info");
    }
}