package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import com.github.kd_gaming1.skyblockenhancements.repo.item.ItemStackBuilder;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1799;

/**
 * Shared logic for collecting NPC {@link class_1799} references used as craft-reference
 * sidebars in RRV recipe views.
 *
 * <p>Both {@link SkyblockNpcInfoRecipeType} and {@link SkyblockNpcShopRecipeType} iterate
 * the full NEU registry looking for {@code _NPC} items; only the filter predicate differs.
 */
final class NpcReferenceCollector {

    private NpcReferenceCollector() {}

    /**
     * Collects all NPC items matching {@code filter} into {@link class_1799} prototypes.
     *
     * @param filter decides whether a given NPC item should be included
     * @return a new list on every call; callers are responsible for caching
     */
    static List<class_1799> collect(Predicate<NeuItem> filter) {
        if (!NeuItemRegistry.isLoaded()) return List.of();

        List<class_1799> npcs = new ArrayList<>();
        for (NeuItem item : NeuItemRegistry.getAll().values()) {
            if (item.internalName != null && item.internalName.endsWith("_NPC") && filter.test(item)) {
                class_1799 stack = ItemStackBuilder.build(item);
                if (!stack.method_7960()) npcs.add(stack);
            }
        }
        return npcs;
    }
}
