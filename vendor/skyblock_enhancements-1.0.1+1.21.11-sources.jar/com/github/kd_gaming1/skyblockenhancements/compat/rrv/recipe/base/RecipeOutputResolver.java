package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base;

import com.github.kd_gaming1.skyblockenhancements.repo.item.ItemStackBuilder;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import com.google.gson.JsonObject;
import net.minecraft.class_1799;

/**
 * Resolves the result {@link class_1799} for a recipe entry, honouring the NEU
 * {@code overrideOutputId} and {@code count} fields.
 *
 * <p>Shared between crafting and forge parsers so the override semantics live in one place.
 */
public final class RecipeOutputResolver {

    private RecipeOutputResolver() {}

    /**
     * Returns the output stack for a recipe entry. Falls back to the owning item's stack when
     * no override is specified or the override doesn't resolve.
     */
    public static class_1799 resolve(JsonObject recipe, NeuItem owner) {
        NeuItem resolved = owner;
        if (recipe.has("overrideOutputId") && recipe.get("overrideOutputId").isJsonPrimitive()) {
            NeuItem override = NeuItemRegistry.get(recipe.get("overrideOutputId").getAsString());
            if (override != null) resolved = override;
        }

        class_1799 stack = ItemStackBuilder.build(resolved).method_7972();
        int count = recipe.has("count") ? recipe.get("count").getAsInt() : 1;
        if (count > 1) stack.method_7939(count);
        return stack;
    }
}