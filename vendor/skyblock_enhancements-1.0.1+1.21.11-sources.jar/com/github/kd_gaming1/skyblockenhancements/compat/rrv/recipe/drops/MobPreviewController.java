package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.drops;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_332;
import net.minecraft.class_3730;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

/**
 * Owns the entity lifecycle, animation, and rendering for a drop-recipe mob preview.
 * Extracted from {@link SkyblockDropsClientRecipe} so the recipe class can focus on
 * slot binding and UI rather than entity spawn/dispose bookkeeping.
 */
public class MobPreviewController {

    private final MobPreview preview;
    private final List<class_1309> entityStack = new ArrayList<>();

    private int animationTick;
    private boolean hovered;

    public MobPreviewController(@Nullable MobPreview preview) {
        this.preview = preview;
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────────

    /** Spawns living entities when the recipe becomes visible. Safe to call when {@code preview} is null. */
    public void init(class_638 level) {
        if (preview == null || !preview.needsLivingEntity()) return;
        spawnRecursive(level, preview, null);
    }

    private void spawnRecursive(class_638 level, MobPreview current, @Nullable class_1309 mount) {
        class_1309 entity = spawnForLayer(level, current.entityType());
        if (entity != null) {
            if (mount != null) {
                entity.method_5804(mount);
                mount.method_24201(entity);
            }
            entityStack.add(entity);
        }
        if (current.rider() != null) {
            spawnRecursive(level, current.rider(), entity != null ? entity : mount);
        }
    }

    @Nullable
    private static class_1309 spawnForLayer(class_638 level, @Nullable class_1299<?> type) {
        if (type == null) return null;
        class_1297 entity = type.method_5883(level, class_3730.field_52444);
        if (!(entity instanceof class_1309 living)) return null;
        living.method_5636(30.0F);
        living.method_5847(30.0F);
        return living;
    }

    /** Discards spawned entities when the recipe is hidden. */
    public void fade() {
        for (class_1309 entity : entityStack) {
            entity.method_5650(class_1297.class_5529.field_26999);
        }
        entityStack.clear();
    }

    // ── Animation ────────────────────────────────────────────────────────────────

    /** Advances the preview rotation animation. Call from the recipe's {@code tick()}. */
    public void tick() {
        if (hovered) return;
        animationTick++;
        if (animationTick >= MobPreviewRenderer.rotationPeriod()) animationTick = 0;
    }

    // ── Rendering ────────────────────────────────────────────────────────────────

    /**
     * Updates hover state, then renders the preview box (entity or placeholder).
     *
     * @param mouseX mouse X relative to the recipe card
     * @param mouseY mouse Y relative to the recipe card
     */
    public void render(class_332 gfx, int x, int y, int mouseX, int mouseY, float partialTicks) {
        hovered = MobPreviewRenderer.isPointInPreviewBox(mouseX, mouseY);
        syncPassengerPositions();

        if (preview != null) {
            MobPreviewRenderer.render(preview, gfx, x, y, entityStack, animationTick, partialTicks);
        } else {
            MobPreviewRenderer.renderPlaceholder(gfx, x, y);
        }
    }

    /** Re-applies vanilla passenger positioning so riders sit at the correct attachment point. */
    private void syncPassengerPositions() {
        for (int i = 0; i < entityStack.size() - 1; i++) {
            class_1309 mount = entityStack.get(i);
            class_1309 rider = entityStack.get(i + 1);
            if (rider.method_5854() == mount) {
                mount.method_24201(rider);
            }
        }
    }

    /** Whether the mouse is currently inside the preview hit-box. */
    public boolean isHovered() {
        return hovered;
    }

    @Nullable
    public MobPreview getPreview() {
        return preview;
    }
}
