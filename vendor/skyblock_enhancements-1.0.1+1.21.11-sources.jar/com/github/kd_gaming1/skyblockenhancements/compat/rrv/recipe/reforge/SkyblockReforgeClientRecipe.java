package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.reforge;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockClientRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.SlotRefParser;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeColors;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipePriority;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipeUtil;
import com.github.kd_gaming1.skyblockenhancements.repo.item.ItemStackBuilder;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.SkyblockItemCategory;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.SkyblockRarity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import org.jetbrains.annotations.Nullable;

/**
 * Client-side reforge recipe card for one specific rarity.
 *
 * <p>Tall card showing the full list of stat boosts this reforge gives to an item of the
 * recipe's fixed rarity. Ability text and long stat lines wrap onto multiple lines instead of
 * being truncated.
 *
 * <p>{@link #redirectsAsResult} filters by rarity + item type, so clicking a reforgable item
 * (e.g. a sword) shows only matching reforge recipes.
 * <p>{@link #redirectsAsIngredient} filters by stone internal name, so clicking a reforge stone
 * (e.g. AMBER_MATERIAL) shows all rarity variants of the reforge it provides.
 */
public class SkyblockReforgeClientRecipe extends AbstractSkyblockClientRecipe {

    private static final int ICON_X = 4;
    private static final int ICON_Y = 4;

    private static final int NAME_X = 24;
    private static final int NAME_Y = 4;

    private static final int SUBTITLE_X = 24;
    private static final int SUBTITLE_Y = 16;

    private static final int STATS_START_Y = 30;
    private static final int LINE_HEIGHT = 9;
    private static final int TEXT_MARGIN_X = 4;
    private static final int BUTTON_ROW_Y = 130;

    private final String reforgeName;
    private final boolean isBlacksmith;
    private final String stoneInternalName;
    private final String itemType;
    private final String rarity;
    private final List<String> requiredRarities;
    private final Map<String, Double> stats;
    private final int cost;
    private final Optional<String> ability;
    private final List<String> specificInternalNames;
    private final List<String> specificItemIds;
    private final Optional<String> nbtModifier;

    @Nullable private List<SlotContent> cachedResults;

    public SkyblockReforgeClientRecipe(SkyblockReforgeServerRecipe src) {
        super(src.getWikiUrls());
        this.reforgeName = src.getReforgeName();
        this.isBlacksmith = src.isBlacksmith();
        this.stoneInternalName = src.getStoneInternalName();
        this.itemType = src.getItemType();
        this.rarity = src.getRarity();
        this.requiredRarities = src.getRequiredRarities();
        this.stats = src.getStats();
        this.cost = src.getCost();
        this.ability = src.getAbility();
        this.specificInternalNames = src.getSpecificInternalNames();
        this.specificItemIds = src.getSpecificItemIds();
        this.nbtModifier = src.getNbtModifier();
    }

    // ── ReliableClientRecipe core ──────────────────────────────────────────────

    @Override
    public ReliableClientRecipeType getViewType() {
        return SkyblockReforgeRecipeType.INSTANCE;
    }

    @Override
    public void bindSlots(RecipeViewMenu.SlotFillContext ctx) {
        if (!isBlacksmith) {
            SlotContent stone = SlotRefParser.parse(stoneInternalName);
            if (!stone.isEmpty()) {
                ctx.bindSlot(0, stone);
            }
        }
    }

    @Override
    public List<SlotContent> getIngredients() {
        if (isBlacksmith || stoneInternalName.isEmpty()) return List.of();
        SlotContent stone = SlotRefParser.parse(stoneInternalName);
        return stone.isEmpty() ? List.of() : List.of(stone);
    }

    @Override
    public List<SlotContent> getResults() {
        if (cachedResults == null) {
            cachedResults = buildResults();
        }
        return cachedResults;
    }

    @Override
    public boolean isVisualOnly() {
        return true;
    }

    @Override
    public int getPriority() {
        return SkyblockRecipePriority.REFORGE;
    }

    @Override
    public boolean redirectsAsResult(class_1799 stack) {
        String itemId = SkyblockRecipeUtil.extractSkyblockId(stack);
        if (itemId == null) return false;

        NeuItem item = NeuItemRegistry.get(itemId);
        if (item == null) return false;

        SkyblockRarity itemRarity = SkyblockItemCategory.extractRarity(item);
        if (itemRarity == null || !itemRarity.name().equals(rarity)) {
            return false;
        }

        if (!specificInternalNames.isEmpty() && specificInternalNames.contains(itemId)) {
            return true;
        }

        if (!specificItemIds.isEmpty()) {
            String mcId = item.itemId;
            String snbtId = item.snbtItemId;
            for (String target : specificItemIds) {
                if (target.equals(mcId) || target.equals(snbtId)) return true;
            }
        }

        if (!itemType.isEmpty()) {
            List<String> types = ReforgeTypeResolver.resolve(item);
            return types.contains(itemType);
        }

        return false;
    }

    @Override
    public boolean redirectsAsIngredient(class_1799 stack) {
        if (isBlacksmith || stoneInternalName.isEmpty()) return false;

        String itemId = SkyblockRecipeUtil.extractSkyblockId(stack);
        if (itemId == null) return false;

        return itemId.equals(stoneInternalName);
    }

    // ── Rendering ──────────────────────────────────────────────────────────────

    @Override
    public void renderRecipe(RecipeViewScreen screen, RecipePosition pos, class_332 gfx,
                             int mouseX, int mouseY, float partialTicks) {
        renderIconFallback(gfx);
        renderName(gfx, pos);
        renderSubtitle(gfx, pos);
        renderStats(gfx, pos);
        maintainButtons(screen, pos);
    }

    private void renderIconFallback(class_332 gfx) {
        if (isBlacksmith) {
            gfx.method_51427(new class_1799(class_1802.field_8782), ICON_X, ICON_Y);
        }
    }

    private void renderName(class_332 gfx, RecipePosition pos) {
        String rarityLabel = rarityColorCode() + rarity.replace("_", " ");
        String label = "§e" + reforgeName + " §7- " + rarityLabel;
        class_2561 line = SkyblockRecipeUtil.ellipsize(font(), label, pos.width() - NAME_X - TEXT_MARGIN_X);
        gfx.method_51439(font(), line, NAME_X, NAME_Y, RecipeColors.WHITE, true);
    }

    private void renderSubtitle(class_332 gfx, RecipePosition pos) {
        String label;
        if (isBlacksmith) {
            label = "§7Blacksmith";
        } else if (cost > 0) {
            label = "§7Cost: §6" + SkyblockRecipeUtil.formatNumber(cost) + " coins";
        } else {
            return;
        }
        class_2561 line = SkyblockRecipeUtil.ellipsize(font(), label, pos.width() - SUBTITLE_X - TEXT_MARGIN_X);
        gfx.method_51439(font(), line, SUBTITLE_X, SUBTITLE_Y, RecipeColors.COINS, true);
    }

    private void renderStats(class_332 gfx, RecipePosition pos) {
        if (stats.isEmpty() && ability.isEmpty()) {
            gfx.method_51433(font(), "§8No stats for " + rarity,
                    TEXT_MARGIN_X, STATS_START_Y, RecipeColors.PLACEHOLDER, true);
            return;
        }

        int maxWidth = pos.width() - TEXT_MARGIN_X * 2;
        int y = STATS_START_Y;

        if (ability.isPresent() && !ability.get().isBlank()) {
            String text = ability.get().replace("\n", " ").trim();
            for (String line : wrapText(font(), text, maxWidth)) {
                gfx.method_51433(font(), line, TEXT_MARGIN_X, y, RecipeColors.WHITE, true);
                y += LINE_HEIGHT;
            }
        }

        for (var entry : stats.entrySet()) {
            String text = "§7" + formatStatName(entry.getKey()) + ": " + formatStatValue(entry.getValue());
            for (String line : wrapText(font(), text, maxWidth)) {
                gfx.method_51433(font(), line, TEXT_MARGIN_X, y, RecipeColors.WHITE, true);
                y += LINE_HEIGHT;
            }
        }
    }

    // ── Text wrapping ──────────────────────────────────────────────────────────

    /**
     * Splits {@code text} into lines that each fit within {@code maxWidth} pixels.
     * Prefers splitting at word boundaries; falls back to splitting within a word.
     * Preserves Minecraft § colour/formatting codes across line breaks.
     */
    private static List<String> wrapText(class_327 font, String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text.isEmpty()) return lines;

        String remaining = text;

        while (!remaining.isEmpty()) {
            int fit = fitLength(font, remaining, maxWidth);
            if (fit <= 0) fit = 1;

            int splitAt = fit;
            if (fit < remaining.length()) {
                // Walk back to the last space for a clean word break
                while (splitAt > 0 && remaining.charAt(splitAt - 1) != ' ') {
                    splitAt--;
                }
                if (splitAt == 0) {
                    splitAt = fit; // No space found — split mid-word
                }
            }

            String line = remaining.substring(0, splitAt).stripTrailing();
            if (!line.isEmpty()) {
                lines.add(line);
            }
            remaining = remaining.substring(splitAt).stripLeading();
        }

        return lines;
    }

    /** Returns the number of leading characters of {@code text} that fit in {@code maxWidth}. */
    private static int fitLength(class_327 font, String text, int maxWidth) {
        if (font.method_1727(text) <= maxWidth) {
            return text.length();
        }

        int lo = 0;
        int hi = text.length();
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (font.method_1727(text.substring(0, mid)) <= maxWidth) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        return lo;
    }

    // ── Rarity colour codes ────────────────────────────────────────────────────

    private String rarityColorCode() {
        return switch (rarity) {
            case "COMMON"       -> "§f";
            case "UNCOMMON"     -> "§a";
            case "RARE"         -> "§9";
            case "EPIC"         -> "§5";
            case "LEGENDARY"    -> "§6";
            case "MYTHIC"       -> "§d";
            case "DIVINE"       -> "§b";
            case "SPECIAL"      -> "§c";
            case "VERY_SPECIAL" -> "§c";
            case "SUPREME"      -> "§4";
            default             -> "§7";
        };
    }

    // ── Result building ────────────────────────────────────────────────────────

    private List<SlotContent> buildResults() {
        Set<class_1792> seenItems = new HashSet<>();
        List<class_1799> stacks = new ArrayList<>();

        for (String id : specificInternalNames) {
            NeuItem item = NeuItemRegistry.get(id);
            if (item != null) {
                class_1799 stack = ItemStackBuilder.build(item);
                if (!stack.method_7960() && seenItems.add(stack.method_7909())) {
                    stacks.add(stack);
                }
            }
        }

        if (!specificItemIds.isEmpty()) {
            for (NeuItem item : NeuItemRegistry.getAll().values()) {
                for (String targetId : specificItemIds) {
                    if (targetId.equals(item.itemId) || targetId.equals(item.snbtItemId)) {
                        class_1799 stack = ItemStackBuilder.build(item);
                        if (!stack.method_7960() && seenItems.add(stack.method_7909())) {
                            stacks.add(stack);
                        }
                        break;
                    }
                }
            }
        }

        List<String> loreTypes = ReforgeTypeResolver.getLoreTypesForReforgeType(itemType);
        if (!loreTypes.isEmpty()) {
            for (NeuItem item : NeuItemRegistry.getAll().values()) {
                String loreType = SkyblockItemCategory.extractLoreType(item);
                if (loreTypes.contains(loreType)) {
                    class_1799 stack = ItemStackBuilder.build(item);
                    if (!stack.method_7960() && seenItems.add(stack.method_7909())) {
                        stacks.add(stack);
                    }
                }
            }
        }

        if (stacks.isEmpty()) return List.of();
        return List.of(SlotContent.of(stacks));
    }

    // ── Formatting ─────────────────────────────────────────────────────────────

    private static String formatStatName(String key) {
        String[] parts = key.split("_");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append(' ');
            String part = parts[i];
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) sb.append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }

    private static String formatStatValue(double value) {
        String prefix = value >= 0 ? "§a+" : "§c";
        if (value == (int) value) {
            return prefix + (int) value;
        }
        return prefix + value;
    }

    // ── Buttons ────────────────────────────────────────────────────────────────

    @Override
    @Nullable
    protected class_4185 placeButtons(RecipeViewScreen screen, RecipePosition pos) {
        int btnX = (SkyblockReforgeRecipeType.DISPLAY_WIDTH - RecipeLayoutConstants.WIKI_BUTTON_WIDTH) / 2;
        return placeWikiButton(screen, pos.left() + btnX, pos.top() + BUTTON_ROW_Y);
    }
}
