package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.trade;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/** 1 cost slot (0) → 1 result slot (1). */
public class SkyblockTradeRecipeType implements ReliableClientRecipeType {

    public static final SkyblockTradeRecipeType INSTANCE = new SkyblockTradeRecipeType();

    private final class_1799 icon = new class_1799(class_1802.field_8086);

    @Override public class_2561  getDisplayName()   { return class_2561.method_43470("SkyBlock Trade"); }
    @Override public int        getDisplayWidth()  { return 80; }
    @Override public int        getDisplayHeight() { return 50; }
    @Override public class_2960 getGuiTexture()    { return null; }
    @Override public int        getSlotCount()     { return 2; }
    @Override public class_1799  getIcon()          { return icon; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        def.addItemSlot(0, 0, 9);
        def.addItemSlot(1, 58, 9);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_trade");
    }
}