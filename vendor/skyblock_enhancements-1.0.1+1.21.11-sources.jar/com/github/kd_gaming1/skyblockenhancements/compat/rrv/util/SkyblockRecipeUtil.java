package com.github.kd_gaming1.skyblockenhancements.compat.rrv.util;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import java.net.URI;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4185;
import net.minecraft.class_5481;
import com.github.kd_gaming1.skyblockenhancements.mixin.rrv.accessor.RecipeViewMenuAccessor;

import static com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements.LOGGER;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.injection.FullStackListCache;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;

public final class SkyblockRecipeUtil {

    private SkyblockRecipeUtil() {}

    // ── Item matching ────────────────────────────────────────────────────────────

    public static String extractSkyblockId(class_1799 stack) {
        return FullStackListCache.getCachedId(stack);
    }

    // ── Tier extraction ─────────────────────────────────────────────────────────

    public static int extractTierFromId(String internalId) {
        if (internalId == null || internalId.isEmpty()) return 0;

        int lastUnderscore = internalId.lastIndexOf('_');
        if (lastUnderscore < 0 || lastUnderscore >= internalId.length() - 1) return 0;

        try {
            return Integer.parseInt(internalId.substring(lastUnderscore + 1));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static int extractTierFromResults(List<SlotContent> results) {
        if (results == null || results.isEmpty()) return 0;

        for (SlotContent slot : results) {
            for (class_1799 stack : slot.getValidContents()) {
                int tier = extractTierFromId(extractSkyblockId(stack));
                if (tier > 0) return tier;
            }
        }
        return 0;
    }

    // ── Number formatting ────────────────────────────────────────────────────────

    /**
     * Formats a number with k/M/B suffixes.
     * Exact multiples omit the decimal: 1000 → "1k", 2000000 → "2M".
     * Non-exact values use one decimal: 1500 → "1.5k", 1234 → "1.2k".
     */
    public static String formatNumber(long value) {
        if (value < 0) return "-" + formatNumber(-value);
        if (value >= 1_000_000_000L) return compact(value, 1_000_000_000L, "B");
        if (value >= 1_000_000L)     return compact(value, 1_000_000L,     "M");
        if (value >= 1_000L)         return compact(value, 1_000L,         "k");
        return Long.toString(value);
    }

    private static String compact(long value, long divisor, String suffix) {
        return ((value % divisor == 0)
                ? Long.toString(value / divisor)
                : String.format("%.1f", (double) value / divisor))
                + suffix;
    }

    // ── Duration formatting ─────────────────────────────────────────────────────

    /** Formats a second count as {@code "1h 30m"} / {@code "5m"} / {@code "45s"}. */
    public static String formatDuration(int seconds) {
        if (seconds >= 3600) {
            int h = seconds / 3600;
            int m = (seconds % 3600) / 60;
            return m > 0 ? h + "h " + m + "m" : h + "h";
        }
        if (seconds >= 60) return (seconds / 60) + "m";
        return seconds + "s";
    }

    // ── Text formatting ──────────────────────────────────────────────────────────

    /** Returns {@code Component.literal("§7" + text)}. */
    public static class_2561 gray(String text) {
        return class_2561.method_43470("§7" + text);
    }

    /** Returns {@code Component.literal("§6" + text)}. */
    public static class_2561 gold(String text) {
        return class_2561.method_43470("§6" + text);
    }

    /** Returns {@code Component.literal("§8" + text)}. */
    public static class_2561 darkGray(String text) {
        return class_2561.method_43470("§8" + text);
    }

    /** Convenience: {@code Minecraft.getInstance().font}. */
    public static class_327 font() {
        return class_310.method_1551().field_1772;
    }

    /**
     * Truncates {@code text} to {@code maxWidth} pixels, appending {@code "…"} when clipped.
     * Operates on plain strings; for formatted sequences see {@link #ellipsize(class_327, class_5481, int)}.
     */
    public static class_2561 ellipsize(class_327 font, String text, int maxWidth) {
        class_2561 full = class_2561.method_43470(text);
        if (font.method_27525(full) <= maxWidth) return full;

        String ellipsis = "…";
        int ellipsisWidth = font.method_1727(ellipsis);
        int available = Math.max(0, maxWidth - ellipsisWidth);
        String trimmed = font.method_1714(full, available).getString();
        return class_2561.method_43470(trimmed + ellipsis);
    }

    /**
     * Truncates a {@link class_5481} to {@code maxWidth}, appending {@code "…"}.
     */
    public static net.minecraft.class_5481 ellipsize(class_327 font, net.minecraft.class_5481 line, int maxWidth) {
        String ellipsis = "…";
        int ellipsisWidth = font.method_1727(ellipsis);
        int available = Math.max(0, maxWidth - ellipsisWidth);
        net.minecraft.class_5481 head = net.minecraft.class_5481.method_34906(
                (net.minecraft.class_5481) font.method_1714((net.minecraft.class_5348) line, available));
        return net.minecraft.class_5481.method_30742(head,
                net.minecraft.class_5481.method_30747(ellipsis, net.minecraft.class_2583.field_24360));
    }

    // ── Command helpers ──────────────────────────────────────────────────────────

    /** Sends a client-side command after null-checking the player and connection. */
    public static void sendCommand(String command) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.method_1562() != null) {
            mc.method_1562().method_45730(command);
        }
    }

    // ── Wiki button ──────────────────────────────────────────────────────────────

    /**
     * Adds a Wiki button to the screen. Returns the button, or {@code null} if
     * {@code wikiUrls} is empty — callers use this as the sentinel reference.
     */
    public static class_4185 addWikiButton(
            RecipeViewScreen screen, String[] wikiUrls, int btnX, int btnY) {
        if (wikiUrls == null || wikiUrls.length == 0) return null;

        String url = Arrays.stream(wikiUrls)
                .filter(wUrl -> wUrl != null && !wUrl.isEmpty())
                .findFirst()
                .orElse(null);
        if (url == null) return null;

        class_4185 btn = class_4185.method_46430(class_2561.method_43470("Wiki"), b -> openUri(url))
                .method_46433(btnX, btnY)
                .method_46437(RecipeLayoutConstants.WIKI_BUTTON_WIDTH, RecipeLayoutConstants.WIKI_BUTTON_HEIGHT)
                .method_46431();
        screen.addRecipeWidget(btn);
        return btn;
    }

    public static void openUri(String uri) {
        if (uri == null || uri.isEmpty()) return;
        try {
            class_156.method_668().method_673(URI.create(uri));
        } catch (Exception e) {
            LOGGER.warn("Failed to open URI: {}", uri);
        }
    }

    // ── NBT helpers for wiki URLs ────────────────────────────────────────────────

    public static void writeWikiUrls(class_2487 tag, String[] urls) {
        if (urls == null || urls.length == 0) return;
        class_2499 list = new class_2499();
        for (String url : urls) list.add(class_2519.method_23256(url));
        tag.method_10566(RecipeTagCodec.KEY_WIKI_URLS, list);
    }

    public static String[] readWikiUrls(class_2487 tag) {
        class_2499 list = tag.method_68569(RecipeTagCodec.KEY_WIKI_URLS);
        if (list.isEmpty()) return new String[0];
        String[] urls = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            urls[i] = String.valueOf(list.method_10608(i));
        }
        return urls;
    }

    public static String[] sanitizeWikiUrls(String[] urls) {
        if (urls == null) return new String[0];
        int validCount = 0;
        for (String url : urls) if (url != null && !url.isEmpty()) validCount++;
        if (validCount == urls.length) return urls;
        String[] clean = new String[validCount];
        int idx = 0;
        for (String url : urls) if (url != null && !url.isEmpty()) clean[idx++] = url;
        return clean;
    }

    // ── Page seek ────────────────────────────────────────────────────────────────

    public static void seekToMatchingPage(RecipeViewMenu menu, String targetId) {
        if (targetId == null || !menu.hasNextRecipe()) return;

        int maxPage = menu.getMaxPageIndex();
        for (int page = 0; page <= maxPage; page++) {
            List<ReliableClientRecipe> display =
                    ((RecipeViewMenuAccessor) menu).sbe$getCurrentDisplay();
            if (displayContainsResult(display, targetId)) return;
            if (page < maxPage) menu.nextPage();
        }

        while (menu.hasPrevRecipe()) menu.prevPage();
    }

    private static boolean displayContainsResult(
            List<ReliableClientRecipe> display, String targetId) {
        for (ReliableClientRecipe recipe : display) {
            for (SlotContent result : recipe.getResults()) {
                for (class_1799 candidate : result.getValidContents()) {
                    if (targetId.equals(extractSkyblockId(candidate))) return true;
                }
            }
        }
        return false;
    }
}