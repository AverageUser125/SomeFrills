package com.github.kd_gaming1.skyblockenhancements.compat.rrv.injection;

import static com.github.kd_gaming1.skyblockenhancements.SkyblockEnhancements.LOGGER;

import cc.cassian.rrv.api.recipe.ReliableServerRecipe;
import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import cc.cassian.rrv.common.recipe.ServerRecipeManager.ServerRecipeEntry;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.generator.SkyblockRecipeGenerator;
import com.github.kd_gaming1.skyblockenhancements.repo.hypixel.HypixelItemsRegistry;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

/**
 * Owns the cached SkyBlock item list and recipe map that gets injected into RRV.
 *
 * <p>This class manages state and orchestration only — item list construction lives in
 * {@link SkyblockItemListBuilder}, recipe grouping in {@link SkyblockRecipeGrouper}, and
 * RRV low-level cache writes in {@link RrvCacheInjector}.
 *
 * <p>{@link #buildCache()} is synchronised so concurrent callers (repo reload vs. RRV reload
 * callback) don't race to produce duplicate work. Published fields are volatile so unlocked
 * readers always see a fully-constructed cache.
 */
public final class SkyblockInjectionCache {

    @Nullable private static volatile List<class_1799> cachedItems;
    @Nullable private static volatile Map<ReliableServerRecipeType<?>, List<ServerRecipeEntry>> cachedGrouped;

    /** {@code true} once RRV has received the current cache, preventing double-injection. */
    private static volatile boolean injected;
    private static volatile boolean cacheIncludesHypixel = false;

    private SkyblockInjectionCache() {}

    // ── Accessors ────────────────────────────────────────────────────────────────

    @Nullable
    public static List<class_1799> getCachedItems() {
        return cachedItems;
    }

    @Nullable
    public static Map<ReliableServerRecipeType<?>, List<ServerRecipeEntry>> getCachedGrouped() {
        return cachedGrouped;
    }

    public static boolean isInjected() {
        return injected;
    }

    public static void markInjected() {
        injected = true;
    }

    /** Clears the injection flag without clearing data. Used by RRV reload callbacks. */
    public static void markNotInjected() {
        injected = false;
    }

    // ── Invalidation ─────────────────────────────────────────────────────────────

    public static void invalidate() {
        cachedItems = null;
        cachedGrouped = null;
        injected = false;
        cacheIncludesHypixel = false;
        FullStackListCache.invalidate();
    }

    // ── Build ────────────────────────────────────────────────────────────────────

    /**
     * Builds the full item list and recipe map from the current registries. No-op if the cache
     * is already built, or if the NEU registry hasn't been populated yet.
     */
    public static synchronized void buildCache() {
        if (cachedItems != null && cachedGrouped != null) {
            if (!cacheIncludesHypixel && HypixelItemsRegistry.isLoaded()) {
                // fall through to rebuild
            } else {
                return;
            }
        }

        if (NeuItemRegistry.getAll().isEmpty()) {
            LOGGER.warn("buildCache called with empty registry — skipping.");
            return;
        }

        try {
            List<class_1799> items = SkyblockItemListBuilder.build();
            Map<ReliableServerRecipeType<?>, List<ServerRecipeEntry>> grouped =
                    SkyblockRecipeGrouper.group(SkyblockRecipeGenerator.generateAll());

            FullStackListCache.populateFromInjected(items);

            cachedGrouped = Collections.unmodifiableMap(new HashMap<>(grouped));
            cachedItems = Collections.unmodifiableList(items);
            cacheIncludesHypixel = HypixelItemsRegistry.isLoaded();

            // Raw recipe JSON is no longer needed after generation — free the memory.
            NeuItemRegistry.trimRecipes();

            LOGGER.info("Built injection cache: {} items, {} recipes.",
                    items.size(), countRecipes(grouped));
        } catch (Exception e) {
            LOGGER.error("Failed to build injection cache", e);
            cachedItems = null;
            cachedGrouped = null;
            cacheIncludesHypixel = false;
        }
    }

    /**
     * Regenerates only essence upgrade recipes and injects them into RRV. Used when Hypixel
     * API data arrives after the initial injection (delta path).
     */
    public static synchronized void buildEssenceRecipesOnly() {
        if (cachedItems == null || cachedGrouped == null) {
            LOGGER.warn("buildEssenceRecipesOnly called before main cache is built — skipping.");
            return;
        }
        if (!HypixelItemsRegistry.isLoaded()) {
            LOGGER.warn("buildEssenceRecipesOnly: Hypixel registry not loaded — skipping.");
            return;
        }

        try {
            List<ReliableServerRecipe> essenceRecipes = SkyblockRecipeGenerator.generateEssenceOnly();
            if (essenceRecipes.isEmpty()) {
                LOGGER.warn("buildEssenceRecipesOnly: no essence recipes generated.");
                return;
            }

            Map<ReliableServerRecipeType<?>, List<ServerRecipeEntry>> essenceGrouped =
                    SkyblockRecipeGrouper.group(essenceRecipes);

            cachedGrouped = mergeMaps(cachedGrouped, essenceGrouped);
            cacheIncludesHypixel = true;

            LOGGER.info("Delta-injecting {} essence upgrade recipes into RRV.", essenceRecipes.size());
            RrvCacheInjector.inject(cachedItems, cachedGrouped);
        } catch (Exception e) {
            LOGGER.error("Failed to build essence recipes", e);
        }
    }

    private static int countRecipes(Map<?, ? extends List<?>> grouped) {
        return grouped.values().stream().mapToInt(List::size).sum();
    }

    private static <K, V> Map<K, V> mergeMaps(Map<K, V> base, Map<K, V> delta) {
        Map<K, V> merged = new HashMap<>(base);
        merged.putAll(delta);
        return Collections.unmodifiableMap(merged);
    }
}
