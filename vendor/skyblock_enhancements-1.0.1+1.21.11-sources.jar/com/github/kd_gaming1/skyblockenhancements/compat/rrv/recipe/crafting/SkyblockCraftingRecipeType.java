package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.crafting;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;

/** 3×3 SkyBlock crafting grid: 9 input slots + 1 output slot. */
public class SkyblockCraftingRecipeType implements ReliableClientRecipeType {

    public static final SkyblockCraftingRecipeType INSTANCE = new SkyblockCraftingRecipeType();

    
    private static final int OUTPUT_X = 94;
    private static final int OUTPUT_Y = 18;

    private final class_1799 icon = new class_1799(class_1802.field_8465);
    private final List<class_1799> craftReferences = List.of(icon);

    @Override public class_2561   getDisplayName() { return class_2561.method_43470("SkyBlock Crafting"); }
    @Override public int         getDisplayWidth()  { return 118; }
    @Override public int         getDisplayHeight() { return 66; }
    @Override public class_2960  getGuiTexture()    { return null; }
    @Override public int         getSlotCount()     { return 10; }
    @Override public class_1799   getIcon()          { return icon; }
    @Override public List<class_1799> getCraftReferences() { return craftReferences; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                def.addItemSlot(row * 3 + col, col * RecipeLayoutConstants.SLOT_SIZE, row * RecipeLayoutConstants.SLOT_SIZE);
            }
        }
        def.addItemSlot(9, OUTPUT_X, OUTPUT_Y);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_crafting");
    }
}