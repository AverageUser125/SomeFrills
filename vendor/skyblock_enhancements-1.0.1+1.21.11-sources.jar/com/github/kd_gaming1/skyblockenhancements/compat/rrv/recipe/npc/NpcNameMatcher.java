package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import com.github.kd_gaming1.skyblockenhancements.repo.item.ItemStackBuilder;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItemRegistry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9334;
import java.util.Map;

/**
 * Matches a clicked NPC head stack to recipes belonging to a specific NPC by comparing the
 * stack's {@code CUSTOM_NAME} against the registered NPC item's display name.
 *
 * <p>NPC heads all share the same Minecraft item type, so the display name is the only reliable
 * discriminator when looking up craft references in the recipe viewer sidebar.
 *
 * <p>To avoid rebuilding {@link class_1799}s on every match call, the registered display name
 * {@link class_2561} is cached per NPC id and invalidated on repo reload.
 */
final class NpcNameMatcher {

    private NpcNameMatcher() {}

    /** npcId → registered display name Component. Cleared on repo reload. */
    private static final Map<String, class_2561> DISPLAY_NAME_CACHE = new ConcurrentHashMap<>();

    static boolean matches(class_1799 clickedStack, String npcId) {
        if (npcId.isEmpty()) return false;

        class_2561 registeredName = DISPLAY_NAME_CACHE.get(npcId);
        if (registeredName == null) {
            NeuItem npcItem = NeuItemRegistry.get(npcId);
            if (npcItem == null) return false;

            registeredName = ItemStackBuilder.build(npcItem).method_58694(class_9334.field_49631);
            if (registeredName == null) return false;

            DISPLAY_NAME_CACHE.put(npcId, registeredName);
        }

        class_2561 clickedName = clickedStack.method_58694(class_9334.field_49631);
        return clickedName != null && clickedName.equals(registeredName);
    }

    /** Clears the display-name cache. Must be called on every repo reload. */
    static void clearCache() {
        DISPLAY_NAME_CACHE.clear();
    }
}
