package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.trade;

import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockServerRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

/** Single-cost → single-result trade. */
public class SkyblockTradeServerRecipe extends AbstractSkyblockServerRecipe {

    public static final ReliableServerRecipeType<SkyblockTradeServerRecipe> TYPE =
            ReliableServerRecipeType.register(
                    class_2960.method_60655("skyblock_enhancements", "skyblock_trade"),
                    () -> new SkyblockTradeServerRecipe(null, null, new String[0]));

    private SlotContent cost;
    private SlotContent result;

    public SkyblockTradeServerRecipe(SlotContent cost, SlotContent result, String[] wikiUrls) {
        super(wikiUrls);
        this.cost = cost;
        this.result = result;
    }

    @Override
    protected ReliableServerRecipeType<?> getType() {
        return TYPE;
    }

    @Override
    protected void writeFields(class_2487 tag) {
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_COST, cost);
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_OUTPUT, result);
    }

    @Override
    protected void readFields(class_2487 tag) {
        cost     = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_COST);
        result   = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_OUTPUT);
    }

    public SlotContent getCost()     { return cost; }
    public SlotContent getResult()   { return result; }
}
