package com.github.kd_gaming1.skyblockenhancements.compat.rrv.category;

import net.minecraft.class_10799;
import net.minecraft.class_11907;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;
import net.minecraft.class_9848;
import org.jspecify.annotations.NonNull;

/**
 * A square icon button that renders one of four category-filter sprites depending on its
 * toggled and hovered state. No text is drawn; the icon communicates the category.
 *
 * <p>Sprite names follow the pattern (all under
 * {@code skyblock_enhancements:gui/sprites/item_list/}):
 * <ul>
 *   <li>{@code <base>.png} — normal</li>
 *   <li>{@code <base>_highlighted.png} — hovered</li>
 *   <li>{@code <base>_toggled.png} — active filter</li>
 *   <li>{@code <base>_toggled_highlighted.png} — active filter + hovered</li>
 * </ul>
 */
public final class CategoryIconButton extends class_4264 {

    private static final String NAMESPACE = "skyblock_enhancements";
    private static final String SPRITE_BASE = "item_list/";

    /** Called when the button is pressed; receives the owning button instance. */
    public interface PressHandler {
        void onPress(CategoryIconButton button);
    }

    private final class_2960 spriteNormal;
    private final class_2960 spriteHighlighted;
    private final class_2960 spriteToggled;
    private final class_2960 spriteToggledHighlighted;

    private final PressHandler pressHandler;
    private boolean toggled;

    /**
     * @param x            left position in screen pixels
     * @param y            top position in screen pixels
     * @param size         width and height in pixels (buttons are square)
     * @param spriteName   base sprite name without suffix, e.g. {@code "armour"}
     * @param toggled      initial toggled (active filter) state
     * @param pressHandler called when the button is pressed
     */
    public CategoryIconButton(
            int x,
            int y,
            int size,
            String spriteName,
            boolean toggled,
            PressHandler pressHandler) {
        super(x, y, size, size, class_2561.method_43473());
        this.toggled = toggled;
        this.pressHandler = pressHandler;

        spriteNormal             = sprite(spriteName);
        spriteHighlighted        = sprite(spriteName + "_highlighted");
        spriteToggled            = sprite(spriteName + "_toggled");
        spriteToggledHighlighted = sprite(spriteName + "_toggled_highlighted");
    }

    // ── State ─────────────────────────────────────────────────────────────────────

    public void setToggled(boolean toggled) {
        this.toggled = toggled;
    }

    public boolean isToggled() {
        return toggled;
    }

    // ── AbstractButton contract ───────────────────────────────────────────────────

    @Override
    public void method_25306(@NonNull class_11907 input) {
        pressHandler.onPress(this);
    }

    @Override
    protected void method_75752(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_2960 sprite = resolveSprite(method_25367());
        graphics.method_52707(class_10799.field_56883, sprite, method_46426(), method_46427(), field_22758, field_22759,
                class_9848.method_61317(field_22765));
    }

    @Override
    protected void method_47399(@NonNull class_6382 output) {
        method_37021(output);
    }

    // ── Private helpers ───────────────────────────────────────────────────────────

    private class_2960 resolveSprite(boolean hovered) {
        if (toggled) return hovered ? spriteToggledHighlighted : spriteToggled;
        return hovered ? spriteHighlighted : spriteNormal;
    }

    private static class_2960 sprite(String name) {
        return class_2960.method_60655(NAMESPACE, SPRITE_BASE + name);
    }
}