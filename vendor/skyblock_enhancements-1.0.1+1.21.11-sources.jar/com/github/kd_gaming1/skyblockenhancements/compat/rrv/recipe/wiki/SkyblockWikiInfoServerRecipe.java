package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.wiki;

import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockServerRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

/** Visual-only wiki card for items that have wiki URLs but no other recipe data. */
public class SkyblockWikiInfoServerRecipe extends AbstractSkyblockServerRecipe {

    public static final ReliableServerRecipeType<SkyblockWikiInfoServerRecipe> TYPE =
            ReliableServerRecipeType.register(
                    class_2960.method_60655("skyblock_enhancements", "skyblock_wiki_info"),
                    () -> new SkyblockWikiInfoServerRecipe(class_1799.field_8037, "", new String[0]));

    private class_1799 displayItem;
    private String displayName;

    public SkyblockWikiInfoServerRecipe(class_1799 displayItem, String displayName, String[] wikiUrls) {
        super(wikiUrls);
        this.displayItem = displayItem != null ? displayItem : class_1799.field_8037;
        this.displayName = displayName != null ? displayName : "";
    }

    @Override
    protected ReliableServerRecipeType<?> getType() {
        return TYPE;
    }

    @Override
    protected void writeFields(class_2487 tag) {
        RecipeTagCodec.writeStack(tag, RecipeTagCodec.KEY_ITEM, displayItem);
        tag.method_10582(RecipeTagCodec.KEY_NAME, displayName);
    }

    @Override
    protected void readFields(class_2487 tag) {
        displayItem = RecipeTagCodec.readStack(tag, RecipeTagCodec.KEY_ITEM);
        displayName = tag.method_68564(RecipeTagCodec.KEY_NAME, "");
    }

    public class_1799 getDisplayItem()  { return displayItem; }
    public String    getDisplayName()  { return displayName; }
}
