package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import com.github.kd_gaming1.skyblockenhancements.repo.neu.NeuItem;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;

/** 2×5 cost grid + 1 result; craft-references are NPCs with at least one shop recipe. */
public class SkyblockNpcShopRecipeType implements ReliableClientRecipeType {

    public static final SkyblockNpcShopRecipeType INSTANCE = new SkyblockNpcShopRecipeType();

    
    private static final int COST_COLS = 5;
    private static final int COST_ROWS = 2;
    /** Top of cost grid — leaves 12px header row for the NPC display name. */
    private static final int GRID_TOP = 12;
    /** Result slot index (costs fill 0..9). */
    private static final int RESULT_INDEX = COST_COLS * COST_ROWS;
    /** Result sits to the right of the cost grid, vertically centered across the two rows. */
    private static final int RESULT_X = COST_COLS * RecipeLayoutConstants.SLOT_SIZE + 6;
    private static final int RESULT_Y = GRID_TOP + RecipeLayoutConstants.SLOT_SIZE / 2;

    private final class_1799 icon = new class_1799(class_1802.field_8687);

    /** Lazily populated on first access — rebuilt when {@link #clearCache()} fires on repo reload. */
    private List<class_1799> cachedNpcReferences = null;

    @Override public class_2561  getDisplayName()   { return class_2561.method_43470("SkyBlock NPC Shop"); }
    @Override public int        getDisplayWidth()  { return RESULT_X + RecipeLayoutConstants.SLOT_SIZE; }
    @Override public int        getDisplayHeight() { return GRID_TOP + COST_ROWS * RecipeLayoutConstants.SLOT_SIZE + 18; }
    @Override public class_2960 getGuiTexture()    { return null; }
    @Override public int        getSlotCount()     { return RESULT_INDEX + 1; }
    @Override public class_1799  getIcon()          { return icon; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        for (int row = 0; row < COST_ROWS; row++) {
            for (int col = 0; col < COST_COLS; col++) {
                def.addItemSlot(row * COST_COLS + col, col * RecipeLayoutConstants.SLOT_SIZE, GRID_TOP + row * RecipeLayoutConstants.SLOT_SIZE);
            }
        }
        def.addItemSlot(RESULT_INDEX, RESULT_X, RESULT_Y);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_npc_shop");
    }

    public void clearCache() {
        cachedNpcReferences = null;
        NpcNameMatcher.clearCache();
    }

    @Override
    public List<class_1799> getCraftReferences() {
        if (cachedNpcReferences != null) return cachedNpcReferences;
        cachedNpcReferences = NpcReferenceCollector.collect(NeuItem::hasNpcShopRecipes);
        return cachedNpcReferences;
    }

    @Override
    public ReferenceCondition getCraftReferenceCondition() {
        return (npcStack, recipe) -> {
            if (!(recipe instanceof SkyblockNpcShopClientRecipe shopRecipe)) return false;
            return NpcNameMatcher.matches(npcStack, shopRecipe.getNpcId());
        };
    }
}
