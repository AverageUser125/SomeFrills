package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.ActionType;
import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_746;

/**
 * Opens a new {@link RecipeViewScreen} while preserving parent-screen and view-history state.
 *
 * <p>Shared by NPC shop/info navigation so the "back" navigation works regardless of which recipe
 * opened which. If we're already inside a recipe view, reuse its parent + history; otherwise the
 * current screen becomes the parent.
 */
final class RecipeViewOpener {

    private RecipeViewOpener() {}

    static void open(ReliableClientRecipe recipe) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) return;

        class_437 current = class_310.method_1551().field_1755;
        class_437 parent = current;
        ArrayList<RecipeViewScreen> viewHistory = new ArrayList<>();

        if (current instanceof RecipeViewScreen existing) {
            parent = existing.method_17577().getParentScreen();
            viewHistory = existing.method_17577().getViewHistory();
        }

        int containerId = parent instanceof class_465<?> cs
                ? cs.method_17577().field_7763 : 0;

        class_310.method_1551().method_1507(new RecipeViewScreen(
                new RecipeViewMenu(
                        parent, containerId, player.method_31548(),
                        List.<ReliableClientRecipe>of(recipe),
                        class_1799.field_8037, ActionType.ANY, viewHistory),
                player.method_31548(),
                class_2561.method_43473()));
    }
}