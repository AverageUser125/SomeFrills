package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.essence;

import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockServerRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

/**
 * Item + essence (+ optional companions) → starred item. One recipe per star level per item.
 */
public class SkyblockEssenceUpgradeServerRecipe extends AbstractSkyblockServerRecipe {

    public static final ReliableServerRecipeType<SkyblockEssenceUpgradeServerRecipe> TYPE =
            ReliableServerRecipeType.register(
                    class_2960.method_60655("skyblock_enhancements", "skyblock_essence_upgrade"),
                    () -> new SkyblockEssenceUpgradeServerRecipe(
                            null, null, null, new SlotContent[0], 0, "", new String[0]));

    /** Coins, souls, mats, etc. — capped defensively at decode time. */
    private static final int MAX_COMPANIONS = 4;

    private SlotContent input;
    private SlotContent output;
    private SlotContent essence;
    private SlotContent[] companions;
    private int starLevel;
    private String essenceType;

    public SkyblockEssenceUpgradeServerRecipe(
            SlotContent input, SlotContent output, SlotContent essence,
            SlotContent[] companions, int starLevel, String essenceType, String[] wikiUrls) {
        super(wikiUrls);
        this.input = input;
        this.output = output;
        this.essence = essence;
        this.companions = companions;
        this.starLevel = starLevel;
        this.essenceType = essenceType != null ? essenceType : "";
    }

    @Override
    protected ReliableServerRecipeType<?> getType() {
        return TYPE;
    }

    @Override
    protected void writeFields(class_2487 tag) {
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_INPUTS, input);
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_OUTPUT, output);
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_ESSENCE, essence);
        RecipeTagCodec.writeSlotArray(tag, RecipeTagCodec.KEY_COMPANIONS_COUNT, RecipeTagCodec.KEY_COMPANIONS_PREFIX, companions);
        tag.method_10569(RecipeTagCodec.KEY_STAR, starLevel);
        tag.method_10582(RecipeTagCodec.KEY_ESSENCE_TYPE, essenceType);
    }

    @Override
    protected void readFields(class_2487 tag) {
        input       = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_INPUTS);
        output      = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_OUTPUT);
        essence     = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_ESSENCE);
        companions  = RecipeTagCodec.readSlotArray(tag, RecipeTagCodec.KEY_COMPANIONS_COUNT, RecipeTagCodec.KEY_COMPANIONS_PREFIX, MAX_COMPANIONS);
        starLevel   = tag.method_68083(RecipeTagCodec.KEY_STAR, 0);
        essenceType = tag.method_68564(RecipeTagCodec.KEY_ESSENCE_TYPE, "");
    }

    public SlotContent   getInput()       { return input; }
    public SlotContent   getOutput()      { return output; }
    public SlotContent   getEssence()     { return essence; }
    public SlotContent[] getCompanions()  { return companions; }
    public int           getStarLevel()   { return starLevel; }
    public String        getEssenceType() { return essenceType; }
}
