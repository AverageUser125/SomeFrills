package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.kat;

import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockServerRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

/** Kat pet upgrade: input pet + up to 4 materials + coins → output pet, with a duration. */
public class SkyblockKatUpgradeServerRecipe extends AbstractSkyblockServerRecipe {

    public static final ReliableServerRecipeType<SkyblockKatUpgradeServerRecipe> TYPE =
            ReliableServerRecipeType.register(
                    class_2960.method_60655("skyblock_enhancements", "skyblock_katgrade"),
                    () -> new SkyblockKatUpgradeServerRecipe(
                            null, null, new SlotContent[0], 0, 0, new String[0]));

    private static final int MAX_MATERIALS = 4;

    private SlotContent input;
    private SlotContent output;
    private SlotContent[] materials;
    private long coins;
    private int timeSeconds;

    public SkyblockKatUpgradeServerRecipe(
            SlotContent input, SlotContent output, SlotContent[] materials,
            long coins, int timeSeconds, String[] wikiUrls) {
        super(wikiUrls);
        this.input = input;
        this.output = output;
        this.materials = materials;
        this.coins = coins;
        this.timeSeconds = timeSeconds;
    }

    @Override
    protected ReliableServerRecipeType<?> getType() {
        return TYPE;
    }

    @Override
    protected void writeFields(class_2487 tag) {
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_INPUTS, input);
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_OUTPUT, output);
        RecipeTagCodec.writeSlotArray(tag, RecipeTagCodec.KEY_MATERIALS_COUNT, RecipeTagCodec.KEY_MATERIALS_PREFIX, materials);
        tag.method_10544(RecipeTagCodec.KEY_COINS, coins);
        tag.method_10569(RecipeTagCodec.KEY_TIME, timeSeconds);
    }

    @Override
    protected void readFields(class_2487 tag) {
        input       = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_INPUTS);
        output      = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_OUTPUT);
        materials   = RecipeTagCodec.readSlotArray(tag, RecipeTagCodec.KEY_MATERIALS_COUNT, RecipeTagCodec.KEY_MATERIALS_PREFIX, MAX_MATERIALS);
        coins       = tag.method_68080(RecipeTagCodec.KEY_COINS, 0);
        timeSeconds = tag.method_68083(RecipeTagCodec.KEY_TIME, 0);
    }

    public SlotContent   getInput()       { return input; }
    public SlotContent   getOutput()      { return output; }
    public SlotContent[] getMaterials()   { return materials; }
    public long          getCoins()       { return coins; }
    public int           getTimeSeconds() { return timeSeconds; }
}
