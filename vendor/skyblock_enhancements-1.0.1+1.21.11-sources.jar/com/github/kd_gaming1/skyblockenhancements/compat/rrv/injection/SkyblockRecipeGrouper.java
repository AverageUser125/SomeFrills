package com.github.kd_gaming1.skyblockenhancements.compat.rrv.injection;

import cc.cassian.rrv.api.recipe.ReliableServerRecipe;
import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import cc.cassian.rrv.common.recipe.ServerRecipeManager.ServerRecipeEntry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;

/**
 * Groups a flat list of {@link ReliableServerRecipe} instances by their
 * {@link ReliableServerRecipeType} and assigns synthetic resource identifiers.
 *
 * <p>Extracted from {@link SkyblockInjectionCache} to keep the cache class focused
 * on state management only.
 */
public final class SkyblockRecipeGrouper {

    private static final String ID_PREFIX = "skyblock_enhancements:recipe_";

    private SkyblockRecipeGrouper() {}

    /**
     * Groups recipes by type and assigns a unique {@link class_2960} to each entry.
     *
     * @param allRecipes flat list of all generated recipes
     * @return map from recipe type to list of entries with synthetic IDs
     */
    public static Map<ReliableServerRecipeType<?>, List<ServerRecipeEntry>> group(
            List<ReliableServerRecipe> allRecipes) {

        Map<ReliableServerRecipeType<?>, List<ServerRecipeEntry>> grouped = new HashMap<>();

        int idCounter = 0;
        for (ReliableServerRecipe recipe : allRecipes) {
            grouped.computeIfAbsent(recipe.getRecipeType(), k -> new ArrayList<>())
                    .add(new ServerRecipeEntry(
                            class_2960.method_12829(ID_PREFIX + (idCounter++)),
                            recipe));
        }
        return grouped;
    }
}
