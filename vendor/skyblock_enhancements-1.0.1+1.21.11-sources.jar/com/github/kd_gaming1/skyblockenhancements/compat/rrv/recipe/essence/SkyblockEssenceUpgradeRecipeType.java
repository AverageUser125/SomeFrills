package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.essence;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;

/**
 * Essence upgrade layout:
 * <ul>
 *   <li>Slot 0 — input item (left)</li>
 *   <li>Slot 1 — essence (center-top)</li>
 *   <li>Slots 2–5 — companion items (2×2 grid below essence)</li>
 *   <li>Slot 6 — output item (right)</li>
 * </ul>
 */
public class SkyblockEssenceUpgradeRecipeType implements ReliableClientRecipeType {

    public static final SkyblockEssenceUpgradeRecipeType INSTANCE = new SkyblockEssenceUpgradeRecipeType();

    

    private final class_1799 icon = new class_1799(class_1802.field_8287);
    private final List<class_1799> craftReferences = List.of(icon);

    @Override public class_2561  getDisplayName()   { return class_2561.method_43470("Essence Upgrade"); }
    @Override public int        getDisplayWidth()  { return 130; }
    @Override public int        getDisplayHeight() { return 64; }
    @Override public class_2960 getGuiTexture()    { return null; }
    @Override public int        getSlotCount()     { return 7; }
    @Override public class_1799  getIcon()          { return icon; }
    @Override public List<class_1799> getCraftReferences() { return craftReferences; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        def.addItemSlot(0, 0, 18);
        def.addItemSlot(1, 30, 0);
        def.addItemSlot(2, 24, RecipeLayoutConstants.SLOT_SIZE + 4);
        def.addItemSlot(3, 24 + RecipeLayoutConstants.SLOT_SIZE, RecipeLayoutConstants.SLOT_SIZE + 4);
        def.addItemSlot(4, 24, RecipeLayoutConstants.SLOT_SIZE * 2 + 4);
        def.addItemSlot(5, 24 + RecipeLayoutConstants.SLOT_SIZE, RecipeLayoutConstants.SLOT_SIZE * 2 + 4);
        def.addItemSlot(6, 106, 18);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_essence_upgrade");
    }
}