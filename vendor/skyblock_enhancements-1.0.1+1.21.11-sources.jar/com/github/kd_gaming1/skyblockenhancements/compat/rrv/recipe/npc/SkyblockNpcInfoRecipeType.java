package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/**
 * NPC info layout: 100px tall — location header, up to ~6 lore lines, then a button row.
 *
 * <p>Craft references are only the NPCs without shop recipes; shop NPCs are reached via the
 * shop page's "NPC Info" button, so surfacing them here would create duplicates in the sidebar.
 */
public class SkyblockNpcInfoRecipeType implements ReliableClientRecipeType {

    public static final SkyblockNpcInfoRecipeType INSTANCE = new SkyblockNpcInfoRecipeType();

    private final class_1799 icon = new class_1799(class_1802.field_8575);

    private List<class_1799> cachedReferences = null;

    @Override public class_2561  getDisplayName()   { return class_2561.method_43470("SkyBlock NPC"); }
    @Override public int        getDisplayWidth()  { return 130; }
    @Override public int        getDisplayHeight() { return 100; }
    @Override public class_2960 getGuiTexture()    { return null; }
    @Override public int        getSlotCount()     { return 1; }
    @Override public class_1799  getIcon()          { return icon; }

    @Override
    public void placeSlots(RecipeViewMenu.SlotDefinition def) {
        def.addItemSlot(0, 2, 2);
    }

    @Override
    public class_2960 getId() {
        return class_2960.method_60655("skyblock_enhancements", "skyblock_npc_info");
    }

    public void clearCache() {
        cachedReferences = null;
        NpcNameMatcher.clearCache();
    }

    @Override
    public List<class_1799> getCraftReferences() {
        if (cachedReferences != null) return cachedReferences;
        cachedReferences = NpcReferenceCollector.collect(item -> !item.hasNpcShopRecipes());
        return cachedReferences;
    }

    @Override
    public ReferenceCondition getCraftReferenceCondition() {
        return (npcStack, recipe) -> {
            if (!(recipe instanceof SkyblockNpcInfoClientRecipe infoRecipe)) return false;
            return NpcNameMatcher.matches(npcStack, infoRecipe.getNpcId());
        };
    }
}
