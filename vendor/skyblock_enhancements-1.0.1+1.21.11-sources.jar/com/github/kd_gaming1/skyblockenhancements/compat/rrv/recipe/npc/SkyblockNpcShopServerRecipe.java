package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.npc;

import cc.cassian.rrv.api.recipe.ReliableServerRecipeType;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.AbstractSkyblockServerRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.RecipeTagCodec;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

/** NPC shop purchase: up to {@link #MAX_COSTS} cost slots → 1 result. Tagged with the owning NPC's ID. */
public class SkyblockNpcShopServerRecipe extends AbstractSkyblockServerRecipe {

    public static final ReliableServerRecipeType<SkyblockNpcShopServerRecipe> TYPE =
            ReliableServerRecipeType.register(
                    class_2960.method_60655("skyblock_enhancements", "skyblock_npc_shop"),
                    () -> new SkyblockNpcShopServerRecipe(new SlotContent[0], null, "", "", new String[0]));

    static final int MAX_COSTS = 10;

    private SlotContent[] costs;
    private SlotContent result;
    private String npcId;
    private String npcDisplayName;

    public SkyblockNpcShopServerRecipe(SlotContent[] costs, SlotContent result,
                                       String npcId, String npcDisplayName, String[] wikiUrls) {
        super(wikiUrls);
        this.costs = costs;
        this.result = result;
        this.npcId = npcId != null ? npcId : "";
        this.npcDisplayName = npcDisplayName != null ? npcDisplayName : "";
    }

    @Override
    protected ReliableServerRecipeType<?> getType() {
        return TYPE;
    }

    @Override
    protected void writeFields(class_2487 tag) {
        RecipeTagCodec.writeSlotArray(tag, RecipeTagCodec.KEY_COUNT, RecipeTagCodec.KEY_COSTS_PREFIX, costs);
        RecipeTagCodec.writeSlot(tag, RecipeTagCodec.KEY_OUTPUT, result);
        tag.method_10582(RecipeTagCodec.KEY_NPC, npcId);
        tag.method_10582(RecipeTagCodec.KEY_DISPLAY_NAME, npcDisplayName);
    }

    @Override
    protected void readFields(class_2487 tag) {
        costs          = RecipeTagCodec.readSlotArray(tag, RecipeTagCodec.KEY_COUNT, RecipeTagCodec.KEY_COSTS_PREFIX, MAX_COSTS);
        result         = RecipeTagCodec.readSlot(tag, RecipeTagCodec.KEY_OUTPUT);
        npcId          = tag.method_68564(RecipeTagCodec.KEY_NPC, "");
        npcDisplayName = tag.method_68564(RecipeTagCodec.KEY_DISPLAY_NAME, "");
    }

    public SlotContent[] getCosts()          { return costs; }
    public SlotContent   getResult()         { return result; }
    public String        getNpcId()          { return npcId; }
    public String        getNpcDisplayName() { return npcDisplayName; }
}
