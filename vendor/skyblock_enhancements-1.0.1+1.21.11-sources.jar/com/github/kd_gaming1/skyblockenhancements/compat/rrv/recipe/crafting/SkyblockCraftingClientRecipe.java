package com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.crafting;

import cc.cassian.rrv.api.recipe.ReliableClientRecipe;
import cc.cassian.rrv.api.recipe.ReliableClientRecipeType;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewMenu;
import cc.cassian.rrv.common.recipe.inventory.RecipeViewScreen;
import cc.cassian.rrv.common.recipe.inventory.SlotContent;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipePriority;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.util.SkyblockRecipeUtil;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.recipe.base.ArraySlotRecipe;
import com.github.kd_gaming1.skyblockenhancements.compat.rrv.render.RecipeLayoutConstants;
import com.github.kd_gaming1.skyblockenhancements.util.HypixelLocationState;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import org.jetbrains.annotations.Nullable;

public class SkyblockCraftingClientRecipe extends ArraySlotRecipe
        implements ReliableClientRecipe {

    private static final int ARROW_X   = 62;
    private static final int ARROW_Y   = 22;
    private static final int BUTTON_ROW_Y_OFFSET = 56;


    private final SlotContent[] inputs;
    private final SlotContent output;
    private final int tierOffset;

    public SkyblockCraftingClientRecipe(SlotContent[] inputs, SlotContent output, String[] wikiUrls) {
        super(wikiUrls);
        this.inputs = inputs;
        this.output = output;
        this.tierOffset = SkyblockRecipeUtil.extractTierFromResults(getResults());
    }

    @Override
    public ReliableClientRecipeType getViewType() {
        return SkyblockCraftingRecipeType.INSTANCE;
    }

    @Override
    public void bindSlots(RecipeViewMenu.SlotFillContext ctx) {
        for (int i = 0; i < 9; i++) {
            if (inputs[i] != null) ctx.bindSlot(i, inputs[i]);
        }
        if (output != null) ctx.bindSlot(9, output);
    }

    @Override
    protected SlotContent[] getInputSlots() {
        return inputs;
    }

    @Override
    public List<SlotContent> getResults() {
        return output != null ? List.of(output) : List.of();
    }

    @Override
    public void renderRecipe(RecipeViewScreen screen, RecipePosition pos, class_332 gfx,
                             int mouseX, int mouseY, float partialTicks) {
        renderArrow(gfx, ARROW_X, ARROW_Y);
        maintainButtons(screen, pos);
    }

    @Override
    @Nullable
    protected class_4185 placeButtons(RecipeViewScreen screen, RecipePosition pos) {
        int btnY = pos.top() + BUTTON_ROW_Y_OFFSET;
        class_4185 sentinel = placeWikiButton(screen, pos.left(), btnY);

        if (HypixelLocationState.isOnSkyblock()) {
            String itemId = resolveOutputId();
            if (itemId != null) {
                int craftX = (sentinel != null) ? pos.left() + RecipeLayoutConstants.WIKI_BUTTON_WIDTH + RecipeLayoutConstants.BUTTON_GAP + 2 : pos.left();
                class_4185 craftBtn = class_4185.method_46430(
                                class_2561.method_43470("Craft"),
                                b -> sendViewRecipeCommand(itemId))
                        .method_46433(craftX, btnY)
                        .method_46437(RecipeLayoutConstants.WIKI_BUTTON_WIDTH, RecipeLayoutConstants.WIKI_BUTTON_HEIGHT)
                        .method_46431();
                screen.addRecipeWidget(craftBtn);
                if (sentinel == null) sentinel = craftBtn;
            }
        }
        return sentinel;
    }

    @Nullable
    private String resolveOutputId() {
        if (output == null || output.isEmpty()) return null;
        List<class_1799> contents = output.getValidContents();
        if (contents.isEmpty()) return null;
        return SkyblockRecipeUtil.extractSkyblockId(contents.getFirst());
    }

    private static void sendViewRecipeCommand(String itemId) {
        SkyblockRecipeUtil.sendCommand("viewrecipe " + itemId);
    }

    @Override
    public int getPriority() {
        return SkyblockRecipePriority.CRAFTING + tierOffset;
    }
}