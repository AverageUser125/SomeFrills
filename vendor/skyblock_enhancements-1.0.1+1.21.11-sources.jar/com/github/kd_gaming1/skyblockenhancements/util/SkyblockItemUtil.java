package com.github.kd_gaming1.skyblockenhancements.util;

import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * General SkyBlock item utilities that do not depend on RRV.
 */
public final class SkyblockItemUtil {
    private SkyblockItemUtil() {}

    /**
     * Extracts the SkyBlock internal ID from a stack's {@code CUSTOM_DATA} component.
     *
     * @param stack the item stack to inspect
     * @return the {@code id} string from NBT, or {@code null} if absent or empty
     */
    @Nullable
    public static String extractSkyblockId(class_1799 stack) {
        if (stack.method_7960()) return null;
        class_9279 data = stack.method_58694(class_9334.field_49628);
        if (data == null) return null;
        String id = data.method_57461().method_68564("id", "");
        return id.isEmpty() ? null : id;
    }

    /**
     * Returns the price-lookup ID for a stack.
     *
     * <p>For enchanted books this resolves the stored enchantment to the API key
     * (e.g. {@code ENCHANTMENT_ULTIMATE_FLOWSTATE_3}). For all other items it
     * falls back to {@link #extractSkyblockId}.
     */
    @Nullable
    public static String getPriceLookupId(class_1799 stack) {
        String baseId = extractSkyblockId(stack);
        if (!"ENCHANTED_BOOK".equals(baseId)) return baseId;

        class_9279 data = stack.method_58694(class_9334.field_49628);
        if (data == null) return null;
        class_2487 tag = data.method_57461();

        // SkyBlock stores enchantments in tag.enchantments.{name} = level
        // getCompound() returns Optional<CompoundTag> in this MC version
        var enchantsOpt = tag.method_10562("enchantments");
        if (enchantsOpt.isEmpty()) return null;
        class_2487 enchants = enchantsOpt.get();
        if (enchants.method_33133()) return null;

        // Enchanted books have exactly one enchantment
        Set<String> keys = enchants.method_10541();
        String enchantName = keys.iterator().next();
        int level = enchants.method_68083(enchantName, 1);
        return "ENCHANTMENT_" + enchantName.toUpperCase() + "_" + level;
    }
}
