package com.github.kd_gaming1.skyblockenhancements.util;

import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Debug utility that dumps the complete NBT and component data of an ItemStack
 * so you can see exactly what SkyBlock puts on items (especially enchanted books).
 *
 * <p>Output is sent as chat lines so you can scroll through it in-game.
 * Call {@link #dumpToChat(class_1799)} from a command handler.
 */
public final class ItemDebugHelper {

    private static final String HEADER = "§7[§bSBE Debug§7] §e§l--- Item Debug Dump ---";
    private static final String FOOTER = "§7[§bSBE Debug§7] §e§l--- End Dump ---";

    private ItemDebugHelper() {}

    /**
     * Dumps everything about the given stack to the player's chat.
     * If stack is empty, prints an error message.
     */
    public static void dumpToChat(@Nullable class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            chat("§cHold an item and try again.");
            return;
        }

        chat(HEADER);

        // 1. Basic item info
        chat("§6Item: §f" + stack.method_7909().method_7876());
        chat("§6Count: §f" + stack.method_7947());
        chat("§6Max Stack: §f" + stack.method_7914());
        chat("§6Damage: §f" + stack.method_7919());

        // 2. DataComponents (Minecraft 1.20.5+)
        chat("");
        chat("§6§lDataComponents:");
        var components = stack.method_57353();
        if (components != null) {
            for (var component : components) {
                String key = component.comp_2443().toString();
                Object value = stack.method_58694(component.comp_2443());
                chat("  §7- §e" + key + "§7 = §f" + String.valueOf(value));
            }
        } else {
            chat("  §7(none)");
        }

        // 3. CUSTOM_DATA (the NBT tag SkyBlock uses)
        chat("");
        chat("§6§lCUSTOM_DATA NBT:");
        class_9279 customData = stack.method_58694(class_9334.field_49628);
        if (customData != null) {
            class_2487 tag = customData.method_57461();
            // Pretty-print the full NBT
            String prettyNbt = prettyPrintNbt(tag, 0);
            for (String line : prettyNbt.split("\n")) {
                chat("  " + line);
            }

            // 4. SkyBlock-specific extractions
            chat("");
            chat("§6§lSkyBlock Extraction:");

            // Raw ID
            String rawId = tag.method_68564("id", "");
            chat("  §7extractSkyblockId() = §f" + (rawId.isEmpty() ? "§cnull" : "§a" + rawId));

            // Price lookup ID (the enchantment key logic)
            String priceId = SkyblockItemUtil.getPriceLookupId(stack);
            chat("  §7getPriceLookupId()  = §f" + (priceId == null ? "§cnull" : "§a" + priceId));

            // Enchantment details for books
            var enchantsOpt = tag.method_10562("enchantments");
            if (enchantsOpt.isPresent()) {
                class_2487 enchants = enchantsOpt.get();
                chat("");
                chat("  §6§lEnchantments map:");
                Set<String> keys = enchants.method_10541();
                for (String enchantName : keys) {
                    int level = enchants.method_68083(enchantName, -1);
                    String apiKey = "ENCHANTMENT_" + enchantName.toUpperCase() + "_" + level;
                    chat("    §7- §e" + enchantName + " §7level=§f" + level);
                    chat("      §7API key: §a" + apiKey);
                }
            }

            // Other common SkyBlock NBT keys
            String[] commonKeys = {"uuid", "timestamp", "generator", "originTag"};
            boolean foundAny = false;
            for (String key : commonKeys) {
                if (tag.method_10545(key)) {
                    if (!foundAny) {
                        chat("");
                        chat("  §6§lOther SkyBlock tags:");
                        foundAny = true;
                    }
                    class_2520 valueTag = tag.method_10580(key);
                    chat("    §7- §e" + key + "§7 = §f" + String.valueOf(valueTag));
                }
            }

        } else {
            chat("  §7(no CUSTOM_DATA component)");
            chat("");
            chat("  §c§lNote: This item has no SkyBlock NBT data.");
        }

        chat(FOOTER);
    }

    // ── Pretty-printing ──────────────────────────────────────────────────────────

    private static String prettyPrintNbt(class_2487 tag, int indent) {
        if (tag.method_33133()) return "{}";
        StringBuilder sb = new StringBuilder();
        String pad = "  ".repeat(indent);
        Set<String> keys = tag.method_10541();
        for (String key : keys) {
            class_2520 value = tag.method_10580(key);
            if (value instanceof class_2487 compound) {
                sb.append(pad).append("§e").append(key).append("§7: {\n");
                sb.append(prettyPrintNbt(compound, indent + 1));
                sb.append(pad).append("§7}");
            } else if (value != null) {
                String valueStr = String.valueOf(value);
                // Truncate very long strings (e.g. base64 textures)
                if (valueStr.length() > 80) {
                    valueStr = valueStr.substring(0, 77) + "...§7 (" + (valueStr.length() - 77) + " more chars)";
                }
                sb.append(pad).append("§e").append(key).append("§7 = §f").append(valueStr);
            }
            sb.append("\n");
        }
        return sb.toString().trim();
    }

    /** Sends a message to the local player's chat. boolean=false means regular chat (not action bar). */
    private static void chat(String message) {
        var mc = net.minecraft.class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470(message), false);
        }
    }
}
