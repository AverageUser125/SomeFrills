package at.hannibal2.skyhanni.config.commands

import at.hannibal2.skyhanni.api.event.HandleEvent
import at.hannibal2.skyhanni.config.commands.brigadier.BaseBrigadierBuilder
import at.hannibal2.skyhanni.config.commands.brigadier.CommandData
import at.hannibal2.skyhanni.events.utils.PreInitFinishedEvent
import at.hannibal2.skyhanni.skyhannimodule.SkyHanniModule
import at.hannibal2.skyhanni.test.command.requireDevEnv
import at.hannibal2.skyhanni.utils.collection.CollectionUtils.addOrInsert
import com.mojang.brigadier.CommandDispatcher
import com.mojang.brigadier.builder.LiteralArgumentBuilder
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource

@SkyHanniModule
object CommandsRegistry {

    @HandleEvent(PreInitFinishedEvent::class)
    fun onPreInitFinished() {
        ClientCommandRegistrationCallback.EVENT.register { dispatcher, _ ->
            CommandRegistrationEvent(dispatcher).post()
        }
    }

    private fun String.isUnique(builders: List<CommandData>) {
        requireDevEnv(builders.all { this !in it.getAllNames() }) {
            "The command $this is already registered!"
        }
    }

    fun CommandData.hasUniqueName(builders: List<CommandData>) {
        name.isUnique(builders)
        aliases.forEach { it.isUnique(builders) }
    }

    fun BaseBrigadierBuilder.addToRegister(dispatcher: CommandDispatcher<FabricClientCommandSource>, builders: MutableList<CommandData>) {
        val original = dispatcher.register(builder as LiteralArgumentBuilder<FabricClientCommandSource>)
        this.node = original
        aliases.forEach {
            dispatcher.register(LiteralArgumentBuilder.literal<FabricClientCommandSource>(it).redirect(original).executes(original.command))
        }
        addBuilder(builders)
    }

    fun <T : CommandBuilderBase> T.addToRegister(
        dispatcher: CommandDispatcher<FabricClientCommandSource>,
        builders: MutableList<CommandData>,
    ) {
        if (this !is CommandBuilder) return // complex commands are not supported in 1.21+ right now
        val builder = BaseBrigadierBuilder(name).apply {
            this.description = this@addToRegister.descriptor
            this.aliases = this@addToRegister.aliases
            this.category = this@addToRegister.category

            legacyCallbackArgs(this@addToRegister.getCallback())
        }
        builder.addToRegister(dispatcher, builders)
    }

    // Adds the command to the builders list in a way that all commands are ordered depending on their category and name.
    private fun CommandData.addBuilder(builders: MutableList<CommandData>) {
        val comparator = compareBy(CommandData::category, CommandData::name)
        for ((i, command) in builders.withIndex()) {
            val comparison = comparator.compare(this, command)
            if (comparison < 0) {
                builders.addOrInsert(i, this)
                return
            }
        }
        builders.add(this)
    }
}
