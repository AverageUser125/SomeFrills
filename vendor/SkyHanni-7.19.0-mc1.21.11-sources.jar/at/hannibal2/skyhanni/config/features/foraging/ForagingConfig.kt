package at.hannibal2.skyhanni.config.features.foraging

import at.hannibal2.skyhanni.config.FeatureToggle
import com.google.gson.annotations.Expose
import io.github.notenoughupdates.moulconfig.annotations.Accordion
import io.github.notenoughupdates.moulconfig.annotations.Category
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorBoolean
import io.github.notenoughupdates.moulconfig.annotations.ConfigOption
import io.github.notenoughupdates.moulconfig.annotations.SearchTag

class ForagingConfig {

    @Expose
    @Category(name = "HotF", desc = "Settings for Heart of the Forest.")
    val hotf: HotfConfig = HotfConfig()

    @Expose
    @Category(name = "Trees", desc = "Settings for big trees found on the foraging islands.")
    val trees: TreesConfig = TreesConfig()

    @Expose
    @ConfigOption(name = "Starlyn Contests", desc = "")
    @SearchTag("Agatha")
    @Accordion
    val starlynContest: StarlynContestsConfig = StarlynContestsConfig()

    @Expose
    @ConfigOption(name = "Foraging Tutorial Quest", desc = "")
    @Accordion
    val tutorialQuest: ForagingTutorialQuestConfig = ForagingTutorialQuestConfig()

    @Expose
    @ConfigOption(name = "Moonglade Beacon", desc = "Settings for the moonglade beacon.")
    @Accordion
    var moongladeBeacon = MoongladeBeaconConfig()

    @Expose
    @ConfigOption(name = "Foraging Tracker", desc = "")
    @Accordion
    val tracker = ForagingTrackerConfig()

    @Expose
    @ConfigOption(name = "Mute Phantoms", desc = "Silences Phantoms in Galatea.")
    @ConfigEditorBoolean
    @FeatureToggle
    var mutePhantoms = true

    @Expose
    @ConfigOption(name = "Mute Fusion Machine", desc = "Silences Fusion Machine sounds in Galatea.")
    @ConfigEditorBoolean
    @FeatureToggle
    @SearchTag("box firework")
    var muteFusionMachine = true

}
